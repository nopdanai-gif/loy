import {WorkGate,GateBusyError} from '../../work-gate';
import {uploadMedia,serveMedia,attachMedia,receiptMedia,mediaFields} from '../../media-server';
import {MediaProblem} from '../../media';
import type {Wish} from '../../types';
const uploads=new WorkGate(4,120,12000);
const submissions=new WorkGate();
import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../../chatgpt-auth';
import QRCode from 'qrcode';
import type { EventInfo } from '../../types';
import {FEED_BYTES} from '../../display-queue';
import {defaultDesign,readDesign,validateDesign,readScene,validateScene,LIMITS} from '../../design';
import {readLed,validateLed,readCeremony,publicCeremony,ceremonyPhase,type StoredCeremony} from '../../event-options';
type EventRow=EventInfo&{scene_json?:string;led_json?:string;ceremony_json?:string|null};
export const dynamic = 'force-dynamic';
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
class Problem extends Error { constructor(public status:number,message:string){super(message);} }
const clean=(v:unknown)=>typeof v==='string'?v.normalize('NFC').replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g,'').replace(/\s+/g,' ').trim():'';
const validText=(v:unknown,max:number)=>{const s=clean(v);if(!s||Array.from(s).length>max)throw new Problem(400,`กรุณากรอกข้อความไม่เกิน ${max} ตัวอักษร`);return s;};
const uuid=(v:unknown)=>typeof v==='string'&&/^[a-f0-9-]{36}$/i.test(v);
async function body(req:Request){
  if(req.headers.get('origin')!==new URL(req.url).origin)throw new Problem(403,'คำขอนี้ไม่ถูกต้อง กรุณาเปิดหน้าเว็บใหม่');
  if(!req.headers.get('content-type')?.includes('application/json'))throw new Problem(415,'รูปแบบข้อมูลไม่ถูกต้อง');
  if(Number(req.headers.get('content-length'))>LIMITS.body)throw new Problem(413,'ข้อมูลยาวเกินไป');
  const reader=req.body?.getReader();if(!reader)throw new Problem(400,'ข้อมูลไม่ถูกต้อง');
  let size=0,raw='';const decoder=new TextDecoder();
  try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>LIMITS.body){await reader.cancel();throw new Problem(413,'ข้อมูลยาวเกินไป');}raw+=decoder.decode(value,{stream:true});}raw+=decoder.decode();}finally{reader.releaseLock();}
  try{const result=JSON.parse(raw);if(!result||typeof result!=='object'||Array.isArray(result))throw new Error();return result;}catch{throw new Problem(400,'ข้อมูลไม่ถูกต้อง');}
}
const publicWish=(row:Record<string,unknown>)=>{const {design_json,device,event_id,photo_id,voice_id,voice_duration_ms,...rest}=row;return {...rest,...mediaFields(row),design:readDesign(design_json,Number(row.style)||0)};};

async function run(req:Request){
  const db=env.DB;if(!db)throw new Problem(503,'ระบบกำลังเตรียมพร้อม กรุณาลองอีกครั้ง');
  const u=new URL(req.url);const path=u.pathname.split('/').filter(Boolean).slice(1);const method=req.method;
  const signed=async()=>{const user=await getChatGPTUser();if(!user)throw new Problem(401,'กรุณาเข้าสู่ระบบสำหรับผู้จัดงาน');return user.userId;};
  const event=async(id:string)=>{if(!/^[a-f0-9]{20}$/.test(id))throw new Problem(404,'ไม่พบห้องงานนี้');const e=await db.prepare('SELECT * FROM events WHERE id=?').bind(id).first<EventRow>();if(!e)throw new Problem(404,'ไม่พบห้องงานนี้');return e;};
  const owned=async(id:string)=>{const owner=await signed();const e=await event(id);if(e.owner!==owner)throw new Problem(403,'เฉพาะเจ้าของห้องงานเท่านั้น');return e;};
  const pub=(e:EventRow)=>{const {owner,scene_json,led_json,ceremony_json,...rest}=e;return {...rest,scene:readScene(scene_json),led:readLed(led_json),ceremony:publicCeremony(readCeremony(ceremony_json))};};
  const rate=async(key:string,max:number,window:number)=>{const now=Date.now();const r=await db.prepare('INSERT INTO rate_limits (key,count,expires) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN expires<=? THEN 1 ELSE count+1 END, expires=CASE WHEN expires<=? THEN excluded.expires ELSE expires END RETURNING count').bind(key,now+window,now,now).first<{count:number}>();if(!r||r.count>max)throw new Problem(429,'ส่งเร็วเกินไป กรุณารอสักครู่แล้วลองอีกครั้ง');};
  if(path[0]==='media'&&path.length===2&&method==='GET')return serveMedia(req,db,env.BUCKET,path[1]);
  if(path[0]==='events'&&path.length===1){
    const owner=await signed();
    if(method==='GET'){const r=await db.prepare('SELECT * FROM events WHERE owner=? ORDER BY created_at DESC').bind(owner).all<EventRow>();return json({events:r.results.map(pub)});}
    if(method==='POST'){const b=await body(req);const title=validText(b.title,80),place=validText(b.place,100);await rate('create:'+owner,5,3600000);const id=crypto.randomUUID().replaceAll('-','').slice(0,20);await db.prepare('INSERT INTO events (id,owner,title,place,created_at) VALUES (?,?,?,?,?)').bind(id,owner,title,place,Date.now()).run();return json({event:pub(await event(id))},201);}
  }
  if(path[0]==='events'&&path[1]){
    const id=path[1];
    if(path[2]==='media'&&path[3]==='voice'&&method==='POST')throw new Problem(410,'ยกเลิกการแนบเสียงแล้ว กรุณารีเฟรชหน้าเว็บ');
    if(path[2]==='media'&&path.length===4&&method==='POST'&&path[3]==='photo')return json({media:await uploadMedia(req,db,env.BUCKET,await event(id),'photo',rate)},201);
    if(path.length===2&&method==='GET'){const e=await event(id);if(u.searchParams.get('compact')==='1')return json({event:pub(e),serverTime:Date.now()});const c=await db.prepare("SELECT COUNT(*) AS n FROM wishes WHERE event_id=? AND status='approved'").bind(id).first<{n:number}>();return json({event:{...pub(e),count:c?.n??0},serverTime:Date.now()});}
    if(path.length===2&&method==='PATCH'){
      const old=await owned(id),b=await body(req),title=validText(b.title,80),place=validText(b.place,100);
      const led=b.led===undefined?readLed(old.led_json):validateLed(b.led);
      const float_ms=b.float_ms??old.float_ms??24000,scene=b.scene===undefined?readScene((old as EventInfo&{scene_json?:string}).scene_json):validateScene(b.scene);
      if(!Number.isInteger(b.interval_ms)||b.interval_ms<600||b.interval_ms>6000||!Number.isInteger(float_ms)||float_ms<12000||float_ms>48000||!scene||!led||![true,false].includes(b.accepting)||![true,false].includes(b.moderation)||![true,false].includes(b.paused))throw new Problem(400,'การตั้งค่าไม่ถูกต้อง');
      await db.prepare('UPDATE events SET title=?,place=?,accepting=?,moderation=?,paused=?,interval_ms=?,float_ms=?,scene_json=?,led_json=? WHERE id=?').bind(title,place,Number(b.accepting),Number(b.moderation),Number(b.paused),b.interval_ms,float_ms,JSON.stringify(scene),JSON.stringify(led),id).run();
      return json({event:pub(await event(id))});
    }
    if(path[2]==='ceremony'&&method==='POST'){
      const e=await owned(id),b=await body(req),old=readCeremony(e.ceremony_json),now=Date.now();
      if(!uuid(b.id)||!['start','cancel'].includes(b.action))throw new Problem(400,'คำสั่งช่วงพิเศษไม่ถูกต้อง');
      if(b.action==='cancel'){
        if(!old||old.id!==b.id)throw new Problem(409,'ช่วงพิเศษนี้เปลี่ยนไปแล้ว กรุณารีเฟรช');
        const cancelled={...old,status:'cancelled'};
        const result=await db.prepare('UPDATE events SET ceremony_json=? WHERE id=? AND ceremony_json IS ?').bind(JSON.stringify(cancelled),id,e.ceremony_json??null).run();
        if(!result.meta.changes)throw new Problem(409,'มีการเปลี่ยนแปลงจากอีกหน้าจอ กรุณาลองใหม่');
        return json({ceremony:publicCeremony(cancelled as StoredCeremony),serverTime:now});
      }
      if(![10,15,30].includes(b.seconds)||!Number.isInteger(b.count)||b.count<1||b.count>12)throw new Problem(400,'เลือกเวลานับถอยหลังและจำนวนกระทงให้ถูกต้อง');
      if(old?.id===b.id)return json({ceremony:publicCeremony(old),serverTime:now});
      if(ceremonyPhase(old,now)!=='idle')throw new Problem(409,'มีช่วงพิเศษกำลังทำงานอยู่ ยกเลิกหรือรอให้จบก่อน');
      const rows=await db.prepare("SELECT id FROM wishes WHERE event_id=? AND status='approved' ORDER BY created_at DESC,id DESC LIMIT ?").bind(id,b.count).all<{id:string}>();
      if(!rows.results.length)throw new Problem(409,'ยังไม่มีกระทงที่อนุมัติสำหรับช่วงพิเศษ');
      const wishIds=rows.results.map(w=>w.id).reverse(),startsAt=now+3500,releaseAt=startsAt+b.seconds*1000;
      const ceremony:StoredCeremony={id:b.id,startsAt,releaseAt,endsAt:releaseAt+18000,count:wishIds.length,status:'scheduled',wishIds};
      const result=await db.prepare('UPDATE events SET ceremony_json=? WHERE id=? AND ceremony_json IS ?').bind(JSON.stringify(ceremony),id,e.ceremony_json??null).run();
      if(!result.meta.changes)throw new Problem(409,'มีการเริ่มช่วงพิเศษจากอีกหน้าจอแล้ว');
      return json({ceremony:publicCeremony(ceremony),serverTime:now},201);
    }
    if(path[2]==='archive'&&method==='GET'){
      await owned(id);
      const status=u.searchParams.get('status')??'all',q=clean(u.searchParams.get('q')??'');
      if(!['all','pending','approved','hidden'].includes(status)||Array.from(q).length>80)throw new Problem(400,'ตัวกรองไม่ถูกต้อง');
      const after=Number(u.searchParams.get('after')??0),provided=u.searchParams.get('snapshot');
      const snapshot=provided===null?((await db.prepare('SELECT COALESCE(MAX(rowid),0) AS n FROM wishes WHERE event_id=?').bind(id).first<{n:number}>())?.n??0):Number(provided);
      if(!Number.isSafeInteger(after)||after<0||!Number.isSafeInteger(snapshot)||snapshot<0)throw new Problem(400,'หน้ารายการไม่ถูกต้อง');
      const where="event_id=? AND rowid<=? AND (?='all' OR status=?) AND (?='' OR instr(lower(name||' '||message),lower(?))>0)";
      const rows=await db.prepare("SELECT rowid AS position,id,name,message,style,status,created_at,photo_id,voice_id,voice_duration_ms,CASE WHEN json_extract(design_json,'$.realism.shape')=1 THEN 'real:' || json_extract(design_json,'$.realism.base') ELSE COALESCE(json_extract(design_json,'$.shape'),'lotus') END AS shape FROM wishes WHERE "+where+" AND rowid>? ORDER BY rowid LIMIT 201").bind(id,snapshot,status,status,q,q,after).all<Record<string,unknown>>();
      const total=await db.prepare('SELECT COUNT(*) AS n FROM wishes WHERE '+where).bind(id,snapshot,status,status,q,q).first<{n:number}>();
      const page=rows.results.slice(0,200);
      return json({rows:page.map(({photo_id,voice_id,voice_duration_ms,...row})=>({...row,...mediaFields({photo_id,voice_id,voice_duration_ms})})),snapshot,total:total?.n??0,cursor:page.at(-1)?.position??after,hasMore:rows.results.length>200});
    }
    if(path[2]==='qr'&&method==='GET'){await event(id);const svg=await QRCode.toString(u.origin+'/join/'+id,{type:'svg',errorCorrectionLevel:'M',margin:4,width:400,color:{dark:'#091629',light:'#ffffff'}});return new Response(svg,{headers:{'Content-Type':'image/svg+xml','Cache-Control':'public,max-age=300','Content-Disposition':`inline; filename="loy-krathong-${id}.svg"`}});}
    if(path[2]==='feed'&&method==='GET'){
      const e=await event(id),cursor=Number(u.searchParams.get('after')??0),hiddenAfter=Number(u.searchParams.get('hiddenAfter')??0),requested=Number(u.searchParams.get('limit')??100);
      if(!Number.isSafeInteger(cursor)||cursor<0||!Number.isSafeInteger(hiddenAfter)||hiddenAfter<0||!Number.isSafeInteger(requested)||requested<0)throw new Problem(400,'ตำแหน่งคิวไม่ถูกต้อง');
      const limit=Math.min(100,requested);
      // Inspect small metadata first; never load 100 maximum-size drawings at once.
      const [candidateResult,hiddenResult]=await db.batch([
        db.prepare("SELECT f.seq,length(CAST(COALESCE(w.design_json,'') AS BLOB))+1400 AS bytes FROM feed f JOIN wishes w ON w.id=f.wish_id WHERE f.event_id=? AND f.seq>? AND f.action='add' AND w.status='approved' ORDER BY f.seq LIMIT ?").bind(id,cursor,limit?limit+1:0),
        db.prepare("SELECT seq,wish_id AS id FROM feed WHERE event_id=? AND seq>? AND action='hide' ORDER BY seq LIMIT 100").bind(id,hiddenAfter),
      ]);
      const candidates=candidateResult.results as {seq:number;bytes:number}[],hidden={results:hiddenResult.results as {seq:number;id:string}[]};
      const chosen:number[]=[];let bytes=0;
      for(const row of candidates){if(chosen.length>=limit||(chosen.length>0&&bytes+row.bytes>FEED_BYTES))break;chosen.push(row.seq);bytes+=row.bytes;}
      const rows=chosen.length?await db.prepare("SELECT f.seq,w.id,w.name,w.message,w.style,w.design_json,w.photo_id,w.voice_id,w.voice_duration_ms FROM feed f JOIN wishes w ON w.id=f.wish_id WHERE f.event_id=? AND f.seq>? AND f.seq<=? AND f.action='add' AND w.status='approved' ORDER BY f.seq").bind(id,cursor,chosen.at(-1)!).all<Record<string,unknown>>():{results:[]};
      const ceremony=readCeremony(e.ceremony_json);let ceremonyWishes:ReturnType<typeof publicWish>[]|undefined;
      if(ceremony&&ceremonyPhase(ceremony,Date.now())!=='idle'&&u.searchParams.get('ceremonySeen')!==ceremony.id){
        const batch=await db.prepare("SELECT w.id,w.name,w.message,w.style,w.design_json,w.photo_id,w.voice_id,w.voice_duration_ms,f.seq FROM wishes w LEFT JOIN feed f ON f.wish_id=w.id AND f.action='add' WHERE w.event_id=? AND w.status='approved' AND w.id IN ("+ceremony.wishIds.map(()=>'?').join(',')+")").bind(id,...ceremony.wishIds).all<Record<string,unknown>>();
        const map=new Map(batch.results.map(w=>[String(w.id),publicWish(w)]));ceremonyWishes=ceremony.wishIds.map(w=>map.get(w)).filter((w):w is ReturnType<typeof publicWish>=>!!w);
      }
      return json({event:pub(e),serverTime:Date.now(),ceremonyWishes,wishes:rows.results.map(publicWish),cursor:chosen.at(-1)??cursor,hasMore:candidates.length>chosen.length,hidden:hidden.results,hiddenCursor:hidden.results.at(-1)?.seq??hiddenAfter});
    }
    if(path[2]==='manage'){
      await owned(id);
      if(method==='GET'){const status=u.searchParams.get('status')??'all';if(!['all','pending','approved','hidden'].includes(status))throw new Problem(400,'ตัวกรองไม่ถูกต้อง');const offset=Math.max(0,Math.floor(Number(u.searchParams.get('offset'))||0)),pageLimit=Math.min(100,Math.max(1,Math.floor(Number(u.searchParams.get('limit')??100)||100)));const rows=await db.prepare('SELECT id,name,message,style,status,created_at,design_json,photo_id,voice_id,voice_duration_ms FROM wishes WHERE event_id=? AND (?=\'all\' OR status=?) ORDER BY created_at DESC,id LIMIT ? OFFSET ?').bind(id,status,status,pageLimit,offset).all();const counts=await db.prepare('SELECT status,COUNT(*) AS n FROM wishes WHERE event_id=? GROUP BY status').bind(id).all();return json({wishes:rows.results.map(publicWish),counts:counts.results});}
      if(method==='PATCH'){const b=await body(req);if(!uuid(b.id)||!['approved','hidden'].includes(b.status))throw new Problem(400,'รายการไม่ถูกต้อง');const w=await db.prepare('SELECT status FROM wishes WHERE id=? AND event_id=?').bind(b.id,id).first<{status:string}>();if(!w)throw new Problem(404,'ไม่พบคำอวยพร');if(w.status==='hidden'&&b.status==='approved')throw new Problem(409,'รายการที่ซ่อนไว้จะไม่ถูกนำกลับขึ้นจอ');const action=b.status==='approved'?'add':'hide';await db.batch([db.prepare('UPDATE wishes SET status=? WHERE id=? AND event_id=?').bind(b.status,b.id,id),db.prepare('INSERT OR IGNORE INTO feed (event_id,wish_id,action,created_at) VALUES (?,?,?,?)').bind(id,b.id,action,Date.now())]);return json({ok:true});}
    }
  }
  if(path[0]==='wishes'&&method==='POST'){
    const b=await body(req);if(b.website)throw new Problem(400,'ไม่สามารถส่งได้');if(!uuid(b.id)||!uuid(b.device)||b.consent!==true)throw new Problem(400,'กรุณายืนยันการแสดงชื่อและคำอวยพรบนจอ');
    const name=validText(b.name,40),message=validText(b.message,140);if(![0,1,2,3].includes(b.style))throw new Problem(400,'กรุณาเลือกกระทง');if(/https?:\/\/|www\./i.test(name+' '+message))throw new Problem(400,'กรุณาใช้คำอวยพรที่ไม่มีลิงก์');
    const design=b.design===undefined?defaultDesign(b.style):validateDesign(b.design);if(!design)throw new Problem(400,'แบบกระทงไม่ถูกต้อง กรุณาตรวจจำนวนของประดับและลายวาด');
    const e=await event(b.event_id);const old=await db.prepare('SELECT id,name,message,style,status,device,event_id,design_json,photo_id,voice_id,voice_duration_ms FROM wishes WHERE id=?').bind(b.id).first<Record<string,unknown>>();if(old){if(old.device!==b.device||old.event_id!==b.event_id)throw new Problem(409,'กรุณาส่งคำอวยพรใหม่');return json({wish:await receiptMedia(db,publicWish(old) as Wish)});}
    const attached=await attachMedia(db,b);
    if(!e.accepting)throw new Problem(409,'ห้องงานนี้ปิดรับกระทงแล้ว');await rate('device:'+e.id+':'+b.device,1,10000);const ip=req.headers.get('cf-connecting-ip');if(ip)await rate('ip:'+e.id+':'+ip,1500,60000);
    const status=e.moderation?'pending':'approved',now=Date.now();const statements=[db.prepare('INSERT INTO wishes (id,event_id,device,name,message,style,status,created_at,design_json,photo_id,voice_id,voice_duration_ms) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)').bind(b.id,e.id,b.device,name,message,b.style,status,now,JSON.stringify(design),attached.photoId,attached.voiceId,attached.durationMs)];if(status==='approved')statements.push(db.prepare("INSERT INTO feed (event_id,wish_id,action,created_at) VALUES (?,?,'add',?)").bind(e.id,b.id,now));await db.batch(statements);return json({wish:await receiptMedia(db,{id:b.id,name,message,style:b.style,status,design,...mediaFields({photo_id:attached.photoId,voice_id:attached.voiceId,voice_duration_ms:attached.durationMs})})},201);
  }
  return json({error:'ไม่พบหน้าที่ต้องการ'},404);
}
async function handle(req:Request){try{return await (req.method==='POST'&&new URL(req.url).pathname==='/api/wishes'?submissions.run(()=>run(req),req.signal):req.method==='POST'&&/\/media\/photo$/.test(new URL(req.url).pathname)?uploads.run(()=>run(req),req.signal):run(req));}catch(e){if(e instanceof GateBusyError)return Response.json({error:'มีผู้ส่งกระทงพร้อมกันจำนวนมาก กำลังทยอยรับ กรุณาลองอีกครั้ง'},{status:503,headers:{'Cache-Control':'no-store','Retry-After':'1'}});if(e instanceof Problem||e instanceof MediaProblem)return json({error:e.message},e.status);console.error('Request failed',e instanceof Error?e.message:'unknown');return json({error:'ระบบขัดข้องชั่วคราว กรุณาลองอีกครั้ง'},500);}}
export const GET=handle;export const POST=handle;export const PATCH=handle;
