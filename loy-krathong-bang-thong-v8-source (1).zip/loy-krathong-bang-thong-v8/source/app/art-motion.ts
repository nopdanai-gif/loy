import type {Design} from './design';
import {realOptions,realDecorationFor} from './realism';
export function candleHeight(d:Design){const r=realOptions(d.realism);return r.shape?({banana:86,lotus:90,marigold:91,orchid:87,coconut:86,swan:128}[r.base]):d.shape==='palace'?108:122;}
export function lightSources(d:Design){
 const r=realOptions(d.realism);
 const sources=Array.from({length:d.candles},(_,i)=>({x:160+(i-(d.candles-1)/2)*24,y:candleHeight(d)-(r.shape||r.light?23:17),rotation:0,scale:r.light?r.flameSize:r.shape?1:.82,smoke:r.light&&r.smoke}));
 for(const decoration of d.decorations){
  if(decoration.kind!=='candle')continue;
  const real=r.decor&&(decoration.realAsset??realDecorationFor(decoration.kind))==='candle';
  const angle=decoration.rotation*Math.PI/180,offset=(real?-15:-12)*decoration.scale;
  sources.push({x:decoration.x-Math.sin(angle)*offset,y:decoration.y+Math.cos(angle)*offset,rotation:decoration.rotation,scale:decoration.scale*(real?1:.78),smoke:r.light&&r.smoke});
 }
 return sources;
}
