import {readFlair,type Flair} from './flair';

function round(ctx:CanvasRenderingContext2D,x:number,y:number,w:number,h:number,r:number|number[]){ctx.beginPath();ctx.roundRect(x,y,w,h,r);}
function flower(ctx:CanvasRenderingContext2D,x:number,y:number,color:string){
 ctx.save();ctx.translate(x,y);ctx.fillStyle=color;
 for(let i=0;i<6;i++){ctx.rotate(Math.PI/3);ctx.beginPath();ctx.ellipse(0,-13,7,13,0,0,Math.PI*2);ctx.fill();}
 ctx.fillStyle='#ffebba';ctx.beginPath();ctx.arc(0,0,6,0,Math.PI*2);ctx.fill();ctx.restore();
}
export function drawPhotoFrame(ctx:CanvasRenderingContext2D,photo:HTMLImageElement,flair:Flair|undefined,x:number,y:number,w:number,h:number){
 const f=readFlair(flair),polar=f.frame==='polaroid',r=f.frame==='moon'?[w*.42,w*.42,12,12]:f.frame==='bloom'?[30,8,30,8]:polar?2:16;
 ctx.save();ctx.translate(x+w/2,y+h/2);if(polar)ctx.rotate(-Math.PI/90);ctx.translate(-w/2,-h/2);
 ctx.fillStyle=polar?'#f7f0e1':'#091c2fee';round(ctx,0,0,w,h,r);ctx.fill();
 const pad=polar?9:12,innerW=w-pad*2,innerH=h-pad*2-(polar?25:0);
 ctx.save();round(ctx,pad,pad,innerW,innerH,polar?0:8);ctx.clip();
 const scale=Math.min(innerW/photo.naturalWidth,innerH/photo.naturalHeight),iw=photo.naturalWidth*scale,ih=photo.naturalHeight*scale;
 ctx.drawImage(photo,pad+(innerW-iw)/2,pad+(innerH-ih)/2,iw,ih);ctx.restore();
 ctx.lineWidth=3;ctx.strokeStyle=f.frame==='moon'?'#c1d5f2':f.color;
 if(f.frame==='aurora'){const g=ctx.createLinearGradient(0,0,w,h);g.addColorStop(0,'#74e6d8');g.addColorStop(.5,'#a593ff');g.addColorStop(1,'#f4b7cc');ctx.strokeStyle=g;ctx.lineWidth=6;}
 if(f.frame==='pearl'){ctx.strokeStyle='#f2e5cd';ctx.lineWidth=6;ctx.lineCap='round';ctx.setLineDash([.1,12]);}
 if(!polar){round(ctx,2,2,w-4,h-4,r);ctx.stroke();ctx.setLineDash([]);}
 if(f.frame==='gold'){ctx.lineWidth=1;round(ctx,7,7,w-14,h-14,11);ctx.stroke();}
 if(f.frame==='bloom'){flower(ctx,w-6,h-6,f.color);flower(ctx,9,10,f.color);}
 if(f.frame==='moon'){ctx.fillStyle='#f4dfaa';ctx.beginPath();ctx.arc(18,17,23,.3*Math.PI,1.8*Math.PI);ctx.bezierCurveTo(2,4,2,27,31,35);ctx.fill();}
 if(polar){ctx.font='23px Georgia, serif';ctx.fillStyle='#9a6f65';ctx.textAlign='right';ctx.fillText('♡',w-13,h-10);}
 ctx.restore();
}
export function drawNameplate(ctx:CanvasRenderingContext2D,flair:Flair|undefined,x:number,y:number,w:number,h:number){
 if(!flair)return;const f=readFlair(flair);ctx.save();
 const g=ctx.createLinearGradient(x,y,x+w,y+h),colors={gold:['#2a2b29ef','#0a1b30ef'],glass:['#274853d9','#112b44dd'],petal:['#3b233cef','#15263eef'],neon:['#081c32eb','#081c32eb'],ribbon:['#403048f2','#152a42ef']}[f.nameplate];
 g.addColorStop(0,colors[0]);g.addColorStop(1,colors[1]);ctx.fillStyle=g;ctx.strokeStyle=f.nameplate==='glass'?'#c4e3ed77':f.color;ctx.lineWidth=2;
 if(f.nameplate==='neon'){ctx.shadowColor=f.color;ctx.shadowBlur=16;}
 if(f.nameplate==='ribbon'){ctx.fillStyle=f.color+'33';ctx.fillRect(x+7,y+7,w,h);ctx.fillStyle=g;}
 round(ctx,x,y,w,h,f.nameplate==='ribbon'?3:f.nameplate==='petal'?[28,5,28,5]:16);ctx.fill();ctx.stroke();ctx.restore();
}
