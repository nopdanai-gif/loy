import {requestJSON,type RequestOptions} from './request';
import type {Ceremony,ArchiveRow} from './event-options';
export function uid(){if(crypto.randomUUID)return crypto.randomUUID();const b=crypto.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const h=Array.from(b,v=>v.toString(16).padStart(2,'0')).join('');return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);}
import type {EventInfo,Wish} from './types';
type ApiResult={event:EventInfo;events:EventInfo[];wish:Wish;wishes:Wish[];counts:{status:string;n:number}[];hidden:{id:string;seq:number}[];cursor:number;hiddenCursor:number;serverTime:number;ceremony:Ceremony|null;ceremonyWishes?:Wish[];rows:ArchiveRow[];snapshot:number;hasMore:boolean;total:number;error?:string};
export async function api(path:string,method='GET',data?:unknown,options:RequestOptions={}){return requestJSON<ApiResult>('/api/'+path,method,data,options);}
