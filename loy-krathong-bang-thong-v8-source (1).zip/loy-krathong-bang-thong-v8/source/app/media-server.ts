import {getChatGPTUser} from './chatgpt-auth';
import {MediaProblem,PHOTO_MAX_BYTES,validatePhoto,validMediaId,mediaUrl,type MediaKind,type AttachedMedia} from './media';
import type {Wish} from './types';
type MediaRow={id:string;event_id:string;submission_id:string;device:string;kind:'photo'|'voice';mime:string;byte_size:number;duration_ms:number|null;digest:string;read_token:string;ready:number;created_at:number};
type Rate=(key:string,max:number,window:number)=>Promise<void>;
const day=86400000,key=(m:Pick<MediaRow,'event_id'|'id'>)=>'wishes/'+m.event_id+'/'+m.id;
export const mediaFields=(r:Record<string,unknown>)=>({... (r.photo_id?{photo:{id:String(r.photo_id),url:mediaUrl(String(r.photo_id))}}:{})});
async function binary(req:Request,max:number){
 if(Number(req.headers.get('content-length'))>max)throw new MediaProblem(413,'ไฟล์ใหญ่เกินไป กรุณาเลือกรูปใหม่');
 const reader=req.body?.getReader();if(!reader)throw new MediaProblem(400,'ไม่พบไฟล์');let size=0;const parts:Uint8Array[]=[];
 try{while(true){const {value,done}=await reader.read();if(done)break;size+=value.length;if(size>max){await reader.cancel();throw new MediaProblem(413,'ไฟล์ใหญ่เกินไป');}parts.push(value);}}finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}return bytes;
}
export async function uploadMedia(req:Request,db:D1Database,bucket:R2Bucket|undefined,event:{id:string;accepting:number},kind:MediaKind,rate:Rate){
 if(!bucket)throw new MediaProblem(503,'ระบบแนบไฟล์กำลังเตรียมพร้อม กรุณาลองอีกครั้ง');
 if(req.headers.get('origin')!==new URL(req.url).origin||req.headers.get('x-media-consent')!=='yes')throw new MediaProblem(403,'กรุณายืนยันการแสดงรูปก่อนส่ง');
 const id=req.headers.get('x-upload-id'),submission=req.headers.get('x-wish-id'),device=req.headers.get('x-device-id');
 if(!validMediaId(id)||!validMediaId(submission)||!validMediaId(device))throw new MediaProblem(400,'ข้อมูลแนบไฟล์ไม่ถูกต้อง');
 if(!event.accepting)throw new MediaProblem(409,'ห้องงานนี้ปิดรับกระทงแล้ว');
 const expected='image/jpeg';if(req.headers.get('content-type')?.split(';')[0]!==expected)throw new MediaProblem(415,'รูปแบบไฟล์ไม่รองรับ');
 await rate('media:'+event.id+':'+device,60,3600000);const ip=req.headers.get('cf-connecting-ip');if(ip)await rate('media-ip:'+event.id+':'+ip,6000,60000);
 const bytes=await binary(req,PHOTO_MAX_BYTES),meta=validatePhoto(bytes);
 const digest=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(n=>n.toString(16).padStart(2,'0')).join('');
 const token=crypto.randomUUID().replaceAll('-','')+crypto.randomUUID().replaceAll('-','');
 await db.prepare('INSERT OR IGNORE INTO media (id,event_id,submission_id,device,kind,mime,byte_size,duration_ms,digest,read_token,ready,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,0,?)').bind(id,event.id,submission,device,kind,meta.mime,bytes.length,null,digest,token,Date.now()).run();
 const row=await db.prepare('SELECT * FROM media WHERE id=?').bind(id).first<MediaRow>();
 if(!row||row.event_id!==event.id||row.submission_id!==submission||row.device!==device||row.kind!==kind||row.digest!==digest)throw new MediaProblem(409,'ไฟล์แนบเปลี่ยนไป กรุณาเลือกไฟล์ใหม่');
 if(row.created_at<Date.now()-day)throw new MediaProblem(409,'ไฟล์แนบหมดเวลาส่ง กรุณาเลือกไฟล์ใหม่');
 // Identical retries write identical bytes. A failed put can safely resume with the same ID.
 if(!row.ready){await bucket.put(key(row),bytes,{httpMetadata:{contentType:meta.mime}});await db.prepare('UPDATE media SET ready=1 WHERE id=?').bind(id).run();}
 // Bounded cleanup of abandoned uploads only; submitted memories are retained.
 try{const old=await db.prepare('SELECT m.id,m.event_id FROM media m WHERE m.event_id=? AND m.created_at<? AND NOT EXISTS (SELECT 1 FROM wishes w WHERE w.id=m.submission_id AND (w.photo_id=m.id OR w.voice_id=m.id)) LIMIT 4').bind(event.id,Date.now()-day).all<Pick<MediaRow,'id'|'event_id'>>();for(const m of old.results){await bucket.delete(key(m));await db.prepare('DELETE FROM media WHERE id=?').bind(m.id).run();}}catch{/* Cleanup never discards the current submission. */}
 return {id:row.id,url:mediaUrl(row.id)+'?key='+row.read_token} satisfies AttachedMedia;
}
export async function attachMedia(db:D1Database,request:{photoId?:unknown;voiceId?:unknown;id:string;device:string;event_id:string}){
 if(request.voiceId!==undefined&&request.voiceId!==null)throw new MediaProblem(410,'ยกเลิกการแนบเสียงแล้ว กรุณารีเฟรชหน้าเว็บแล้วส่งใหม่');
 const id=request.photoId;if(id===undefined||id===null)return {photoId:null,voiceId:null,durationMs:null};
 if(!validMediaId(id))throw new MediaProblem(400,'รูปแนบไม่ถูกต้อง');
 const row=await db.prepare('SELECT * FROM media WHERE id=?').bind(id).first<MediaRow>();
 if(!row||row.event_id!==request.event_id||row.submission_id!==request.id||row.device!==request.device||!row.ready||row.created_at<Date.now()-day||row.kind!=='photo')throw new MediaProblem(400,'รูปแนบยังส่งไม่ครบ หรือไม่ได้เป็นของกระทงนี้ กรุณาลองอีกครั้ง');
 return {photoId:id,voiceId:null,durationMs:null};
}
export async function receiptMedia(db:D1Database,wish:Wish){
 if(!wish.photo)return wish;const row=await db.prepare('SELECT read_token FROM media WHERE id=? AND submission_id=?').bind(wish.photo.id,wish.id).first<{read_token:string}>();
 return {...wish,photo:{...wish.photo,url:mediaUrl(wish.photo.id)+(row?'?key='+row.read_token:'')}};
}
export async function serveMedia(req:Request,db:D1Database,bucket:R2Bucket|undefined,id:string){
 const missing=()=>{throw new MediaProblem(404,'ไม่พบไฟล์นี้ หรือไฟล์ยังไม่เปิดให้แสดง');};
 if(!validMediaId(id)||!bucket)return missing();
 const row=await db.prepare('SELECT m.*,e.owner,w.status FROM media m JOIN events e ON e.id=m.event_id LEFT JOIN wishes w ON w.id=m.submission_id AND (w.photo_id=m.id OR w.voice_id=m.id) WHERE m.id=? AND m.ready=1').bind(id).first<MediaRow&{owner:string;status:string|null}>();
 if(!row)return missing();
 const approved=row.kind==='photo'&&row.status==='approved',ownLink=row.kind==='photo'&&row.status!=='hidden'&&new URL(req.url).searchParams.get('key')===row.read_token&&(row.status!==null||row.created_at>=Date.now()-day);
 if(!approved&&!ownLink&&(await getChatGPTUser())?.userId!==row.owner)return missing();
 const headers=new Headers({'Content-Type':row.mime,'Cache-Control':approved?'private,max-age=0,must-revalidate':'private,no-store','ETag':'"'+row.digest+'"','X-Content-Type-Options':'nosniff','Cross-Origin-Resource-Policy':'same-origin','Referrer-Policy':'no-referrer','Content-Disposition':'inline; filename="krathong-'+row.id+(row.kind==='photo'?'.jpg':'.wav')+'"'});
 if(approved&&req.headers.get('if-none-match')===headers.get('etag'))return new Response(null,{status:304,headers});
 const object=await bucket.get(key(row));if(!object)return missing();headers.set('Content-Length',String(object.size));return new Response(object.body,{headers});
}
