declare module 'qrcode' { const qr: {toString(text:string,options:Record<string,unknown>):Promise<string>};export default qr; }
