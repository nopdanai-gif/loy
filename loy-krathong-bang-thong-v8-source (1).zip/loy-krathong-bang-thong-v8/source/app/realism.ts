export const REAL_BASES=[
  {id:'banana',name:'ใบตองพับกลีบ',detail:'เส้นใบตอง · พับสามชั้น',shape:'leaf'},
  {id:'lotus',name:'บัวหลวงชมพู',detail:'กลีบซ้อน · สีชมพูธรรมชาติ',shape:'lotus'},
  {id:'marigold',name:'บุปผาดาวเรือง',detail:'ดอกแน่น · เหลืองทองอบอุ่น',shape:'lotus'},
  {id:'orchid',name:'กล้วยไม้ม่วง',detail:'กลีบละมุน · มาลัยมะลิ',shape:'lotus'},
  {id:'coconut',name:'กะลาธรรมชาติ',detail:'ผิวกะลา · ใบเตยหอม',shape:'boat'},
  {id:'swan',name:'หงส์ใบตอง',detail:'งานพับประณีต · ดอกไม้สด',shape:'swan'},
] as const;
export const REAL_DECORATIONS=[
  {id:'lotus',name:'บัวสด',kind:'lotus',group:'flower',photo:true},
  {id:'rose',name:'กุหลาบสด',kind:'rose',group:'flower',photo:true},
  {id:'marigold',name:'ดาวเรืองสด',kind:'marigold',group:'flower',photo:true},
  {id:'orchid',name:'กล้วยไม้สด',kind:'orchid',group:'flower',photo:true},
  {id:'jasmine',name:'มะลิสด',kind:'daisy',group:'flower',photo:true},
  {id:'leaf',name:'ใบตองพับ',kind:'leaf',group:'leaf',photo:true},
  {id:'pearl',name:'มุกเงาวาว',kind:'pearl',group:'jewel',photo:false},
  {id:'crystal',name:'คริสตัลเจียระไน',kind:'diamond',group:'jewel',photo:false},
  {id:'candle',name:'เทียนขี้ผึ้ง',kind:'candle',group:'light',photo:false},
  {id:'incense',name:'ธูปหอม',kind:'incense',group:'light',photo:false},
  {id:'goldleaf',name:'ทองคำเปลว',kind:'leaf',group:'jewel',photo:false},
  {id:'garland',name:'สายมาลัยมุก',kind:'ribbon',group:'jewel',photo:false},
] as const;
export type RealBase=typeof REAL_BASES[number]['id'];
export type RealDecoration=typeof REAL_DECORATIONS[number]['id'];
export const REAL_TONES=[
  ['natural','สีธรรมชาติ','#86ac64','#f7dfae'],['warm','อุ่นแสงเทียน','#d99b60','#ffddb2'],
  ['moon','จันทร์นวล','#9fb8d2','#eef4ff'],['jade','หยกมรกต','#4e9b7c','#c4e8bb'],
  ['rose','ชมพูกลีบบัว','#dca5b3','#ffdee6'],['gold','ทองบุปผา','#cda455','#ffe49a'],
  ['violet','ม่วงออร์คิด','#aa90c0','#e2d1f1'],['vintage','วินเทจอุ่น','#b9a07a','#ead9b5'],
] as const;
export const FINISHES=[['natural','ผิวธรรมชาติ'],['matte','นุ่มด้าน'],['dew','หยาดน้ำค้าง'],['gold','แต้มทองคำเปลว']] as const;
export const REAL_LIGHTS=[['candle','แสงเทียนอุ่น','#ffb45e'],['moon','แสงจันทร์','#bfdcff'],['sunset','อาทิตย์ลับฟ้า','#ff9c72'],['lantern','โคมทอง','#ffdb81'],['studio','นุ่มละมุน','#fff0d3'],['festival','คืนเฉลิมฉลอง','#d2b5ff']] as const;
export const MOTIONS=[['gentle','เอื่อยเบา ๆ'],['breeze','พลิ้วตามลม'],['still','นิ่งสงบ']] as const;
export type Realism={shape:boolean;color:boolean;decor:boolean;light:boolean;base:RealBase;tone:typeof REAL_TONES[number][0];finish:typeof FINISHES[number][0];saturation:number;exposure:number;contrast:number;lightPreset:typeof REAL_LIGHTS[number][0];reflection:number;ripples:boolean;smoke:boolean;sparks:boolean;motion:typeof MOTIONS[number][0];flameSize:number};
export const DEFAULT_REALISM:Realism={shape:false,color:false,decor:false,light:false,base:'banana',tone:'natural',finish:'natural',saturation:1,exposure:1,contrast:1,lightPreset:'candle',reflection:45,ripples:true,smoke:true,sparks:false,motion:'gentle',flameSize:1};
const object=(x:unknown):x is Record<string,unknown>=>!!x&&typeof x==='object'&&!Array.isArray(x);
const number=(x:unknown,a:number,b:number):x is number=>typeof x==='number'&&Number.isFinite(x)&&x>=a&&x<=b;
export function validateRealism(x:unknown):Realism|null{
 if(!object(x)||!['shape','color','decor','light','ripples','smoke','sparks'].every(k=>typeof x[k]==='boolean')||!REAL_BASES.some(v=>v.id===x.base)||!REAL_TONES.some(v=>v[0]===x.tone)||!FINISHES.some(v=>v[0]===x.finish)||!REAL_LIGHTS.some(v=>v[0]===x.lightPreset)||!MOTIONS.some(v=>v[0]===x.motion)||!number(x.saturation,.5,1.5)||!number(x.exposure,.75,1.25)||!number(x.contrast,.8,1.3)||!number(x.reflection,0,100)||!number(x.flameSize,.6,1.4))return null;
 return Object.fromEntries(Object.keys(DEFAULT_REALISM).map(k=>[k,x[k]])) as Realism;
}
export function realOptions(x?:Realism):Realism{return x??DEFAULT_REALISM;}
export function baseAsset(id:RealBase){return '/assets/realistic/base-'+id+'.webp';}
export function decorationAsset(id:RealDecoration){return '/assets/realistic/decor-'+id+'.webp';}
export function realDecorationFor(kind:string):RealDecoration|undefined{return REAL_DECORATIONS.find(x=>x.kind===kind)?.id;}
export const DECOR_GROUPS=[['all','ทั้งหมด'],['flower','ดอกไม้สด'],['leaf','ใบไม้'],['jewel','มุก & เครื่องประดับ'],['light','เทียน & ธูป']] as const;
