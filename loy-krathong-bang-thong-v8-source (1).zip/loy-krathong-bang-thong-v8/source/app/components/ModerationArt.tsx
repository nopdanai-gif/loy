'use client';
import {memo,useEffect,useRef,useState} from 'react';
import DisplayArt from './DisplayArt';
import KrathongArt from './KrathongArt';
import {readDesign} from '../design';
import type {Wish} from '../types';
function ModerationArt({wish}:{wish:Wish}){
 const ref=useRef<HTMLDetailsElement>(null),[visible,setVisible]=useState(false),[open,setOpen]=useState(false);
 useEffect(()=>{const element=ref.current;if(!element)return;if(!('IntersectionObserver' in window)){setVisible(true);return;}const observer=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){setVisible(true);observer.disconnect();}},{rootMargin:'200px'});observer.observe(element);return()=>observer.disconnect();},[]);
 const design=wish.design??readDesign(undefined,wish.style);
 return <details ref={ref} className="moderation-art" onToggle={e=>setOpen(e.currentTarget.open)}><summary aria-label={'ดูแบบกระทงของ '+wish.name}>{visible?<DisplayArt design={design}/>:<span className="art-placeholder">✧</span>}<span>ดูแบบ</span></summary>{open&&<div><KrathongArt design={design}/></div>}</details>;
}
export default memo(ModerationArt);
