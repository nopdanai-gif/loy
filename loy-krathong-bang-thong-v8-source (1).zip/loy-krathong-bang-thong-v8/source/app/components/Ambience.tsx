'use client';
import {memo,type CSSProperties} from 'react';
import {type Scene,DEFAULT_SCENE} from '../design';
const colors={festival:['#e686c4','#60ddd0','#ffc77e'],aurora:['#60f1d0','#777ef2','#9deeff'],gold:['#ffc966','#ffeabd','#d9984c'],dream:['#c49aff','#ed9dcc','#8ab2ff']};
function Ambience({scene=DEFAULT_SCENE,quiet=false}:{scene?:Scene;quiet?:boolean}){
  const c=colors[scene.theme];
  return <div aria-hidden="true" className={'ambience theme-'+scene.theme+(quiet?' quiet':'')} style={{'--light-a':c[0],'--light-b':c[1],'--light-c':c[2],opacity:scene.intensity/100} as CSSProperties}>
    <div className="sky-glow glow-a"/><div className="sky-glow glow-b"/>
    {scene.water&&<><div className="water-light"><div/><div/></div><div className="river-current"><div className="current-surface current-near"/><div className="current-surface current-far"/>{Array.from({length:18},(_,i)=><i key={i} style={{top:(8+i*19%88)+'%',left:(i*31%110)+'%','--current-time':(10+i%7*2)+'s','--current-delay':(-i*2.3)+'s',width:(32+i%5*23)+'px'} as CSSProperties}/>)}</div></>}
    {scene.fireflies&&<div className="fireflies">{Array.from({length:36},(_,i)=><i key={i} style={{left:((i*37+13)%100)+'%',top:((i*19+37)%88)+'%','--delay':-(i%11)+'s','--time':(5+i%6)+'s'} as CSSProperties}/>)}</div>}
    {scene.lanterns&&<div className="lanterns">{Array.from({length:8},(_,i)=><i key={i} style={{left:((i*17+18)%98)+'%','--delay':(-i*7)+'s','--time':(38+i*4)+'s','--size':(8+i%3*3)+'px'} as CSSProperties}/>)}</div>}
    {scene.fireworks&&<div className="fireworks">{[0,1,2].map(i=><div className="firework" key={i} style={{left:(25+i*30)+'%',top:(14+i%2*16)+'%','--delay':(-i*5)+'s'} as CSSProperties}>{Array.from({length:12},(_,j)=><i key={j} style={{transform:'rotate('+j*30+'deg)'}}/>)}</div>)}</div>}
  </div>;
}

export default memo(Ambience);
