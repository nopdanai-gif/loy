'use client';
import {FramedPhoto,Badge,flairStyle} from './FlairArt';
import {memo,type CSSProperties} from 'react';
import type {Ceremony} from '../event-options';import type {Wish} from '../types';
import DisplayArt from './DisplayArt';import BangThongSeal from './BangThongSeal';import {readDesign} from '../design';
type Props={ceremony:Ceremony;wishes:Wish[];phase:'ready'|'countdown'|'fleet';now:number;logo:boolean;quiet:boolean};
function CeremonyStage({ceremony,wishes,phase,now,logo,quiet}:Props){
  return <section className={'ceremony-stage phase-'+phase+(quiet?' quiet':'')} aria-label="ช่วงลอยกระทงพร้อมกัน">
    <div className="ceremony-halo" aria-hidden="true"/>
    {phase!=='fleet'?<div className="countdown-scene" role="status">{logo&&<BangThongSeal/>}<p className="eyebrow">ให้ความปรารถนาดีของเรา ลอยไปด้วยกัน</p>{phase==='ready'?<><div className="countdown-ready">✧</div><h2>เตรียมกระทงของคุณให้พร้อม</h2></>:<><div className="countdown-number" key={Math.ceil((ceremony.releaseAt-now)/1000)}>{Math.max(1,Math.ceil((ceremony.releaseAt-now)/1000))}</div><h2>อีกสักครู่… เราจะลอยไปพร้อมกัน</h2></>}<p>คืนแห่งสายน้ำ แสงเทียน และความหวัง</p></div>:<>
    <div className="fleet-heading">{logo&&<BangThongSeal/>}<div><p className="eyebrow">ช่วงพิเศษแห่งความทรงจำ</p><h2>ให้ทุกความหวัง<em>ลอยไปด้วยกัน</em></h2></div></div>
    <div className="ceremony-fleet" style={{'--fleet-columns':wishes.length>9?4:3} as CSSProperties}>{wishes.map((w,i)=><article className="fleet-boat" key={w.id} style={{'--boat-delay':(i%4)*.18+'s'} as CSSProperties}><DisplayArt design={w.design??readDesign(undefined,w.style)}/><div>{w.photo&&<FramedPhoto className="fleet-photo" src={w.photo.url} flair={w.design?.flair} alt={"รูปของ "+w.name}/>}<h3 style={flairStyle(w.design?.flair)}><Badge flair={w.design?.flair}/>{w.name}</h3><p>{w.message}</p></div></article>)}</div>
    {!wishes.length&&<p className="fleet-empty">ขอให้ทุกความปรารถนา เดินทางไปถึงสายน้ำ</p>}
    {!quiet&&<div className="celebration-rays" aria-hidden="true">{Array.from({length:18},(_,i)=><i key={i} style={{'--angle':i*20+'deg','--spark-delay':i%6*.2+'s'} as CSSProperties}/>)}</div>}
    </>}
  </section>;
}
export default memo(CeremonyStage,(a,b)=>a.ceremony.id===b.ceremony.id&&a.phase===b.phase&&a.wishes===b.wishes&&a.logo===b.logo&&a.quiet===b.quiet&&(a.phase!=='countdown'||Math.ceil((a.ceremony.releaseAt-a.now)/1000)===Math.ceil((b.ceremony.releaseAt-b.now)/1000)));
