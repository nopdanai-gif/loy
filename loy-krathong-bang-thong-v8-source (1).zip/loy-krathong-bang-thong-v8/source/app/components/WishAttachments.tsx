'use client';
import {useState} from 'react';
import type {AttachedMedia} from '../media';
import type {Flair} from '../flair';
import {FramedPhoto} from './FlairArt';
export default function WishAttachments({photo,flair,collapsible=false}:{photo?:AttachedMedia;flair?:Flair;collapsible?:boolean}){
 const [open,setOpen]=useState(!collapsible);if(!photo)return null;
 return <div className="wish-attachments">{collapsible&&<button type="button" className="text-button attachment-expand" aria-expanded={open} onClick={()=>setOpen(!open)}>{open?'ซ่อนรูปแนบ':'ดูรูปแนบ'}</button>}{open&&<div className="wish-attachment-content"><a href={photo.url} target="_blank" rel="noreferrer" aria-label="เปิดรูปแนบขนาดเต็ม"><FramedPhoto src={photo.url} flair={flair} alt="รูปแนบของผู้ส่งกระทง" lazy/></a></div>}</div>;
}
