'use client';
import {useEffect,useState} from 'react';
export default function usePageVisibility(){
 const [visible,setVisible]=useState(true);
 useEffect(()=>{const update=()=>setVisible(!document.hidden);update();document.addEventListener('visibilitychange',update);return()=>document.removeEventListener('visibilitychange',update);},[]);
 return visible;
}
