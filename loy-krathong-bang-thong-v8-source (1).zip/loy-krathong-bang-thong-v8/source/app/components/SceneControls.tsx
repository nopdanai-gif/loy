'use client';
import {useId} from 'react';
import {type Scene,SCENE_THEMES} from '../design';
export default function SceneControls({value,onChange}:{value:Scene;onChange:(v:Scene)=>void}){
  const id=useId();return <div className="scene-controls">
    <label className="field-label" htmlFor={id}>โทนแสงบนสายน้ำ</label><select id={id} value={value.theme} onChange={e=>onChange({...value,theme:e.target.value as Scene['theme']})}>{SCENE_THEMES.map(([key,name])=><option value={key} key={key}>{name}</option>)}</select>
    <label className="range-label" htmlFor={id+'intensity'}>ความเข้มแสงสี <output>{value.intensity}%</output></label><input id={id+'intensity'} type="range" min="0" max="100" value={value.intensity} onChange={e=>onChange({...value,intensity:+e.target.value})}/>
    <label className="range-label" htmlFor={id+'brightness'}>ความสว่างฉาก <output>{value.brightness}%</output></label><input id={id+'brightness'} type="range" min="60" max="150" value={value.brightness} onChange={e=>onChange({...value,brightness:+e.target.value})}/>
    <div className="effects-grid">{([['lanterns','โคมลอย'],['fireflies','หิ่งห้อย'],['fireworks','พลุนุ่มนวล'],['water','แสงสะท้อนน้ำ']] as const).map(([key,label])=><label key={key}><input type="checkbox" checked={value[key]} onChange={e=>onChange({...value,[key]:e.target.checked})}/>{label}</label>)}</div>
  </div>;
}
