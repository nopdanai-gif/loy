'use client';
import {useEffect,useState,useRef} from 'react';
import {Download,Search,Archive} from 'lucide-react';
import WishAttachments from './WishAttachments';
import {api} from '../client';
import {SHAPES} from '../design';
import {REAL_BASES} from '../realism';
import {STATUS_LABELS,type ArchiveRow} from '../event-options';
import type {EventInfo} from '../types';
const when=(t:number)=>new Intl.DateTimeFormat('th-TH',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Bangkok'}).format(t);
const shapeName=(s:string)=>s.startsWith('real:')?(REAL_BASES.find(x=>x.id===s.slice(5))?.name??'กระทง')+' (สมจริง)':SHAPES.find(x=>x[0]===s)?.[1]??'บัวบาน';
type Page={after:number;snapshot:number|null};
export default function ArchivePanel({event}:{event:EventInfo}){
  const [q,setQ]=useState(''),[filter,setFilter]=useState({q:'',status:'all'}),[page,setPage]=useState<Page>({after:0,snapshot:null}),[history,setHistory]=useState<Page[]>([]),[rows,setRows]=useState<ArchiveRow[]>([]),[next,setNext]=useState({cursor:0,snapshot:0,hasMore:false}),[total,setTotal]=useState(0),[loading,setLoading]=useState(true),[error,setError]=useState(''),[exporting,setExporting]=useState(false),[progress,setProgress]=useState(0),[download,setDownload]=useState('');
  const mounted=useRef(true);useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;};},[]);
  useEffect(()=>()=>{if(download)URL.revokeObjectURL(download);},[download]);
  function path(after:number,snapshot:number|null){return 'events/'+event.id+'/archive?status='+filter.status+'&q='+encodeURIComponent(filter.q)+'&after='+after+(snapshot===null?'':'&snapshot='+snapshot);}
  useEffect(()=>{
    let alive=true;setLoading(true);setError('');
    api(path(page.after,page.snapshot)).then(d=>{if(alive){setRows(d.rows);setTotal(d.total);setNext({cursor:d.cursor,snapshot:d.snapshot,hasMore:d.hasMore});}}).catch(e=>{if(alive)setError(e.message);}).finally(()=>{if(alive)setLoading(false);});
    return()=>{alive=false;};
  },[event.id,filter,page]);
  function reset(nextFilter:typeof filter){setDownload('');setFilter(nextFilter);setPage({after:0,snapshot:null});setHistory([]);}
  async function exportAll(){
    if(exporting)return;setExporting(true);setError('');setProgress(0);setDownload('');
    try{
      const savedEvent=(await api('events/'+event.id)).event;
      const all:ArchiveRow[]=[];let after=0,snapshot:number|null=null;
      while(true){
        const d=await api(path(after,snapshot));if(!mounted.current)return;
        all.push(...d.rows);setProgress(all.length);snapshot=d.snapshot;
        if(all.length>200000)throw new Error('ข้อมูลจำนวนมากเกินไปสำหรับการดาวน์โหลดบนอุปกรณ์นี้ กรุณาเลือกตัวกรองให้แคบลง');
        if(!d.hasMore)break;if(d.cursor<=after)throw new Error('อ่านข้อมูลไม่ครบ กรุณาลองดาวน์โหลดใหม่');after=d.cursor;
      }
      const {makeWorkbook}=await import('../xlsx');
      const table:(string|number)[][]=[['ลำดับ','ชื่อ','คำอวยพร','แบบกระทง','สถานะ','วันเวลาส่ง (ประเทศไทย)','รหัสกระทง','ลิงก์รูปแนบ'],...all.map((r,i)=>[i+1,r.name,r.message,shapeName(r.shape),STATUS_LABELS[r.status]??r.status,when(r.created_at),r.id,r.photo?location.origin+r.photo.url:''])];
      const bytes=makeWorkbook([{name:'คำอวยพร',rows:table,widths:[9,25,72,18,18,30,42,64]},{name:'ข้อมูลงาน',rows:[['รายการ','รายละเอียด'],['ชื่องาน',savedEvent.title],['สถานที่',savedEvent.place],['จำนวนรายการ',all.length],['ตัวกรอง',STATUS_LABELS[filter.status]],['คำค้น',filter.q||'ทั้งหมด'],['ดาวน์โหลดเมื่อ',when(Date.now())],['หน่วยงาน','องค์การบริหารส่วนตำบลบางทอง']],widths:[26,80]}]);
      if(!mounted.current)return;const url=URL.createObjectURL(new Blob([bytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));setDownload(url);
      const a=document.createElement('a');a.href=url;a.download='bang-thong-wishes-'+event.id+'.xlsx';a.click();
    }catch(e){if(mounted.current)setError((e as Error).message);}finally{if(mounted.current)setExporting(false);}
  }
  return <section className="panel archive-panel"><div className="section-heading"><div><p className="eyebrow"><Archive size={14}/> ความทรงจำของค่ำคืนนี้</p><h2>คลังคำอวยพรและไฟล์ Excel</h2></div><button className="button gold" disabled={exporting||loading} onClick={exportAll}><Download size={16}/>{exporting?'กำลังรวบรวม '+progress+' รายการ…':'ดาวน์โหลด Excel'}</button></div><p className="muted small">ค้นหาและเปิดย้อนหลังได้แม้ปิดรับกระทงแล้ว ไฟล์ดาวน์โหลดรวมทุกรายการตามตัวกรอง พร้อมลิงก์รูป · ไฟล์ที่ยังไม่อนุมัติหรือซ่อนไว้เปิดได้เฉพาะผู้จัดงาน</p>
    <form className="archive-search" onSubmit={e=>{e.preventDefault();reset({...filter,q:q.trim()});}}><label><span className="sr-only">ค้นหาชื่อหรือคำอวยพร</span><input disabled={exporting} value={q} onChange={e=>setQ(e.target.value)} maxLength={80} placeholder="ค้นหาชื่อหรือคำอวยพร…"/></label><select disabled={exporting} aria-label="สถานะคำอวยพรในคลัง" value={filter.status} onChange={e=>reset({...filter,status:e.target.value})}>{Object.entries(STATUS_LABELS).map(([v,l])=><option value={v} key={v}>{l}</option>)}</select><button className="button outline" type="submit" disabled={exporting}><Search size={15}/>ค้นหา</button><button className="button outline" type="button" disabled={exporting} onClick={()=>reset(filter)}>อัปเดต</button></form>
    {error&&<p className="error" role="alert">{error}</p>}{download&&<p className="archive-download" role="status">ไฟล์พร้อมแล้ว · <a href={download} download={'bang-thong-wishes-'+event.id+'.xlsx'}>แตะที่นี่หากยังไม่ได้ดาวน์โหลด ↓</a></p>}
    <div className="archive-count">{loading?'กำลังอ่านคำอวยพร…':total.toLocaleString('th-TH')+' รายการ'}{filter.q&&' · คำค้น “'+filter.q+'”'}</div>
    {!loading&&rows.length===0?<div className="empty">ไม่พบคำอวยพรตามตัวกรองนี้</div>:<div className="archive-table-wrap" tabIndex={0} aria-label="ตารางคำอวยพร เลื่อนด้านข้างเพื่อดูครบ"><table className="archive-table"><thead><tr><th>ชื่อและคำอวยพร</th><th>แบบกระทง</th><th>สถานะ</th><th>วันเวลาส่ง</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td><strong>{r.name}</strong><p>{r.message}</p><WishAttachments photo={r.photo}  collapsible/></td><td>{shapeName(r.shape)}</td><td><span className={'status status-'+r.status}>{STATUS_LABELS[r.status]}</span></td><td>{when(r.created_at)}</td></tr>)}</tbody></table></div>}
    <div className="pagination"><button className="button outline small-button" disabled={loading||!history.length} onClick={()=>{setPage(history.at(-1)!);setHistory(history.slice(0,-1));}}>← ก่อนหน้า</button><span>หน้า {history.length+1}</span><button className="button outline small-button" disabled={loading||!next.hasMore} onClick={()=>{setHistory([...history,page]);setPage({after:next.cursor,snapshot:next.snapshot});}}>ถัดไป →</button></div>
  </section>;
}
