'use client';
import {memo,useEffect,useMemo,useRef,useState} from 'react';
import {Aura} from './FlairArt';
import KrathongArt from './KrathongArt';
import type {Design} from '../design';
import {inlineRealisticImages} from '../inline-svg';
import {RenderPool} from '../render-pool';
import {DisplayFlames,DisplayWater} from './DisplayEffects';
// Share the detailed, high-resolution surface; flames and water remain live.
const pool=new RenderPool<string>(40,url=>URL.revokeObjectURL(url));
export const ART_WIDTH=960,ART_HEIGHT=750;
function nextPaint(){return new Promise<void>(resolve=>setTimeout(resolve,32));}
export async function rasterizeArt(source:SVGSVGElement):Promise<string>{
 await nextPaint();
 const svg=source.cloneNode(true) as SVGSVGElement;
 svg.setAttribute('xmlns','http://www.w3.org/2000/svg');svg.setAttribute('width',String(ART_WIDTH));svg.setAttribute('height',String(ART_HEIGHT));svg.removeAttribute('class');
 await inlineRealisticImages(svg);
 const blob=new Blob([new XMLSerializer().serializeToString(svg)],{type:'image/svg+xml;charset=utf-8'}),input=URL.createObjectURL(blob);
 try{
  const image=new Image();await new Promise<void>((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Render timed out')),12000);image.onload=()=>{clearTimeout(timer);resolve()};image.onerror=()=>{clearTimeout(timer);reject(new Error('Render unavailable'))};image.src=input;});
  const canvas=document.createElement('canvas');canvas.width=ART_WIDTH;canvas.height=ART_HEIGHT;const ctx=canvas.getContext('2d');if(!ctx)throw new Error('Canvas unavailable');
  ctx.drawImage(image,0,0,ART_WIDTH,ART_HEIGHT);
  const result=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('Render unavailable')),'image/webp',.97));
  canvas.width=0;canvas.height=0;return URL.createObjectURL(result);
 }finally{URL.revokeObjectURL(input);}
}
function DisplayArt({design}:{design:Design}){
 const source=useRef<HTMLSpanElement>(null),[image,setImage]=useState<{key:string;url:string}|null>(null),[ready,setReady]=useState('');
 const key=useMemo(()=>JSON.stringify(design),[design]);
 useEffect(()=>{
  const svg=source.current?.querySelector('svg');if(!svg)return;let live=true;
  const job=pool.acquire(key,()=>rasterizeArt(svg));
  job.promise.then(url=>{if(live)setImage({key,url});}).catch(()=>{});
  return()=>{live=false;job.release();};
 },[key]);
 const url=image?.key===key?image.url:undefined;
 return <span className={'krathong-art display-art display-art-'+(design.realism?.light?design.realism.motion:'gentle')}>
  <Aura flair={design.flair}/><DisplayWater design={design} url={ready===key?url:undefined}/>
  <span className="display-surface">
   {ready!==key&&<span ref={source} className="display-art-source"><KrathongArt design={design} surfaceOnly/></span>}
   {url&&<img src={url} alt="กระทงที่ออกแบบเอง" width={ART_WIDTH} height={ART_HEIGHT} decoding="async" onLoad={()=>setReady(key)} onError={()=>{setImage(null);setReady('');}} style={ready===key?undefined:{position:'absolute',opacity:0}}/>}
   <DisplayFlames design={design}/>
  </span>
 </span>;
}
export default memo(DisplayArt);
