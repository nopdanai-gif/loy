'use client';
import {useEffect,useRef,useState} from 'react';
import {ImagePlus,Trash2} from 'lucide-react';
import {preparePhoto} from '../media-client';
import type {LocalAttachment} from '../media';
import type {Flair} from '../flair';
import {FramedPhoto} from './FlairArt';
import {uid} from '../client';
type Props={photo:LocalAttachment|null;onPhoto:(v:LocalAttachment|null)=>void;disabled:boolean;onWorking:(v:boolean)=>void;flair?:Flair};
export default function AttachmentComposer({photo,onPhoto,disabled,onWorking,flair}:Props){
 const [preparing,setPreparing]=useState(false),[error,setError]=useState('');const input=useRef<HTMLInputElement>(null),alive=useRef(true),busy=useRef(false);
 useEffect(()=>{alive.current=true;return()=>{alive.current=false;};},[]);
 async function choose(file:File){if(busy.current||disabled)return;busy.current=true;setPreparing(true);onWorking(true);setError('');try{const blob=await preparePhoto(file);if(alive.current)onPhoto({id:uid(),blob,url:URL.createObjectURL(blob)});}catch(e){if(alive.current)setError((e as Error).message);}finally{busy.current=false;if(alive.current){setPreparing(false);onWorking(false);}if(input.current)input.current.value='';}}
 return <section className="attachment-compose" aria-label="แนบรูปกับกระทง"><div className="attachment-heading"><span>เพิ่มรูปความทรงจำ</span><small>เลือกแนบได้ 1 รูป</small></div><div className="photo-attach-card">
  <input ref={input} type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" aria-label="เลือกรูปแนบกระทง" disabled={disabled||preparing} onChange={e=>{const file=e.target.files?.[0];if(file)void choose(file);}}/>
  {photo?<FramedPhoto className="attachment-photo-preview" src={photo.url} alt="รูปที่จะแนบกับกระทง" flair={flair}/>:<button type="button" className="photo-attach-empty" disabled={disabled||preparing} onClick={()=>input.current?.click()}><ImagePlus size={30}/><span>แตะเพื่อเพิ่มรูปของคุณ</span></button>}
  <div className="photo-attach-info"><strong>ภาพดี ๆ ที่อยากฝากไว้ในค่ำคืนนี้</strong><p>รูปจะแสดงคู่กับคำอวยพร และอยู่ในภาพที่ระลึกด้วย</p><div className="attachment-actions"><button type="button" className="button outline small-button" disabled={disabled||preparing} onClick={()=>input.current?.click()}>{preparing?'กำลังเตรียมรูป…':photo?'เปลี่ยนรูป':'เลือกรูป'}</button>{photo&&<button type="button" className="icon-button" disabled={disabled||preparing} onClick={()=>onPhoto(null)} aria-label="ลบรูปแนบ"><Trash2 size={16}/></button>}</div><small>JPG · PNG · WebP ไม่เกิน 12 MB</small></div>
 </div>{error&&<p className="error" role="alert">{error}</p>}<p className="attachment-note">เลือกกรอบรูปที่ชอบได้ในหมวด 05 ลูกเล่น</p></section>;
}
