import type {CSSProperties} from 'react';
import {readFlair,badgeSymbol,type Flair} from '../flair';
export const flairStyle=(flair?:Flair)=>({'--flair-color':readFlair(flair).color} as CSSProperties);
export function Badge({flair}:{flair?:Flair}){const symbol=badgeSymbol(readFlair(flair).badge);return symbol?<span className="flair-badge" aria-hidden="true">{symbol}</span>:null;}
export function FramedPhoto({src,alt,flair,className='',lazy=false}:{src:string;alt:string;flair?:Flair;className?:string;lazy?:boolean}){
 const f=readFlair(flair);return <span className={'framed-photo photo-frame-'+f.frame+' '+className} style={flairStyle(f)}><img src={src} alt={alt} loading={lazy?'lazy':undefined} decoding="async"/><span className="photo-frame-ornament" aria-hidden="true">{f.frame==='bloom'?'❀':f.frame==='moon'?'☾':f.frame==='pearl'?'✧':f.frame==='polaroid'?'♡':''}</span></span>;
}
export function AuraLayers({flair}:{flair?:Flair}){
 const f=readFlair(flair);if(f.aura==='none')return null;
 return <g className={'flair-aura-layers aura-'+f.aura} pointerEvents="none" fill="none" stroke={f.color}>
  {f.aura==='halo'&&<><ellipse cx="160" cy="148" rx="120" ry="75" strokeWidth="8" opacity=".08"/><ellipse cx="160" cy="148" rx="116" ry="71" strokeWidth="1" opacity=".55"/><ellipse cx="160" cy="148" rx="125" ry="80" strokeWidth=".7" strokeDasharray="1 11" opacity=".5"/></>}
  {f.aura==='orbit'&&<g className="aura-turn"><ellipse cx="160" cy="147" rx="122" ry="40" transform="rotate(-25 160 147)" opacity=".7"/><ellipse cx="160" cy="147" rx="122" ry="40" transform="rotate(25 160 147)" opacity=".35"/><circle cx="50" cy="182" r="4" fill={f.color} stroke="none"/><circle cx="260" cy="112" r="2.5" fill="#fff3d8" stroke="none"/></g>}
  {f.aura==='heart'&&<><path d="M160 218C-20 125 55 25 160 95C265 25 340 125 160 218Z" opacity=".16" strokeWidth="7"/><path d="M160 218C-20 125 55 25 160 95C265 25 340 125 160 218Z" opacity=".65" strokeWidth="1.2"/></>}
  {f.aura==='moon'&&<><path d="M226 51A103 83 0 1 0 258 188A91 76 0 0 1 226 51Z" fill={f.color} fillOpacity=".09" strokeOpacity=".6"/><path d="m238 75 3 8 8 3-8 3-3 8-3-8-8-3 8-3Z" fill={f.color} stroke="none"/><circle cx="267" cy="105" r="2" fill="#fff6db" stroke="none"/></>}
 </g>;
}
export function Aura({flair}:{flair?:Flair}){return flair&&flair.aura!=='none'?<svg className="flair-aura" viewBox="0 0 320 250" aria-hidden="true"><AuraLayers flair={flair}/></svg>:null;}
export function FlairBurst({flair,small=false}:{flair?:Flair;small?:boolean}){
 const f=readFlair(flair);if(!flair||f.entrance==='none')return null;
 const count=small?8:22;
 return <span className={'flair-burst burst-'+f.entrance+(small?' burst-small':'')} style={flairStyle(f)} aria-hidden="true"><svg viewBox="-160 -120 320 240" overflow="visible">{Array.from({length:count},(_,i)=>{
  const angle=i/count*Math.PI*2,radius=75+i%4*18,style={'--burst-x':Math.cos(angle)*radius+'px','--burst-y':Math.sin(angle)*radius-30+'px','--burst-delay':i%5*.06+'s','--burst-turn':(i%2?130:-110)+'deg'} as CSSProperties;
  return <g className="flair-particle" key={i} style={style} fill={i%3?f.color:'#fff1d2'}>{f.entrance==='petals'?<path d="M0 7Q-13-1 0-12Q13-1 0 7Z"/>:f.entrance==='hearts'?<path d="M0 7C-18-4-6-15 0-7C6-15 18-4 0 7Z"/>:f.entrance==='bubbles'?<circle r={3+i%4} fill="none" stroke={f.color} strokeWidth="1.4"/>:f.entrance==='lanterns'?<><rect x="-6" y="-11" width="12" height="17" rx="4" opacity=".7"/><ellipse cy="5" rx="5" ry="2" fill="#fff3be"/><path d="M-4 8 0 13 4 8" stroke={f.color} fill="none"/></>:f.entrance==='stars'?<path d="m0-9 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z"/>:<path d="m0-9 2 7 7 2-7 2-2 7-2-7-7-2 7-2Z"/>}</g>;
 })}</svg></span>;
}
