'use client';
import {useState} from 'react';
import {Shuffle,ChevronDown} from 'lucide-react';
import {WISH_IDEAS} from '../flair';
export default function WishIdeas({onChoose,disabled=false}:{onChoose:(text:string)=>void;disabled?:boolean}){
 const [open,setOpen]=useState(false),[category,setCategory]=useState(0);const chosen=WISH_IDEAS[category];
 return <div className="wish-ideas"><button type="button" className="wish-ideas-toggle" aria-expanded={open} onClick={()=>setOpen(!open)}><span>✧ ช่วยคิดคำอวยพร</span><ChevronDown size={16} style={{transform:open?'rotate(180deg)':undefined}}/></button>{open&&<div className="wish-ideas-body"><div className="flair-choice-chips">{WISH_IDEAS.map((c,i)=><button type="button" key={c.id} className={i===category?'selected':''} aria-pressed={i===category} onClick={()=>setCategory(i)}>{c.label}</button>)}</div><div className="wish-idea-list">{chosen.items.map(text=><button type="button" key={text} disabled={disabled} onClick={()=>onChoose(text)}>{text}<span aria-hidden="true">＋</span></button>)}</div><button type="button" className="text-button" disabled={disabled} onClick={()=>onChoose(chosen.items[Math.floor(Math.random()*chosen.items.length)])}><Shuffle size={13}/>สุ่มคำอวยพรหมวดนี้</button><p>แตะข้อความที่ชอบ แล้วปรับให้เป็นคำอวยพรของคุณได้เลย</p></div>}</div>;
}
