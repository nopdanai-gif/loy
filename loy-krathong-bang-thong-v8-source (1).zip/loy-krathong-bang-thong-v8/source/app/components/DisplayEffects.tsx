'use client';
import {useId,type CSSProperties} from 'react';
import type {Design} from '../design';
import {lightSources} from '../art-motion';
import {realOptions,REAL_LIGHTS} from '../realism';

export function DisplayFlames({design:d}:{design:Design}){
 const id=useId().replace(/:/g,''),r=realOptions(d.realism),color=r.light?REAL_LIGHTS.find(x=>x[0]===r.lightPreset)![2]:d.glow;
 return <svg className="display-flames" viewBox="0 0 320 250" aria-hidden="true">
  <defs>
   <radialGradient id={id+'-fire'} cx="48%" cy="75%"><stop offset="0" stopColor="#fff"/><stop offset=".32" stopColor="#fff5bb"/><stop offset=".68" stopColor="#ffcf65"/><stop offset="1" stopColor="#f98c35" stopOpacity=".45"/></radialGradient>
   <radialGradient id={id+'-heat'}><stop offset="0" stopColor={color} stopOpacity=".45"/><stop offset=".4" stopColor="#ffbb67" stopOpacity=".16"/><stop offset="1" stopColor={color} stopOpacity="0"/></radialGradient>
  </defs>
  {lightSources(d).map((light,i)=><g key={i} data-live-flame transform={`translate(${light.x} ${light.y}) rotate(${light.rotation}) scale(${light.scale})`}>
   <ellipse className="live-candle-halo" cy="-12" rx="28" ry="37" fill={'url(#'+id+'-heat)'} style={{'--fire-delay':(-i*.31)+'s',opacity:.35+d.glowPower/160} as CSSProperties}/>
   <g className="live-candle-flame" style={{'--fire-delay':(-i*.37)+'s','--fire-time':(1.7+i%5*.19)+'s'} as CSSProperties}>
    <path d="M0-29C-1-21-8-15-6-8C-4 1 6 1 6-9C6-16 2-21 0-29Z" fill={'url(#'+id+'-fire)'}/><path d="M0-15Q-5-5-1-2Q5 0 2-9Z" fill="#fffde8"/><path d="M-2-2Q0-6 2-2" fill="none" stroke="#9bd6ff" strokeWidth=".7" opacity=".7"/>
   </g>
   {light.smoke&&<g className="live-candle-smoke" style={{'--fire-delay':(-i*.43)+'s'} as CSSProperties}><path d="M0-33c-8-10 8-17 1-26s-4-15 1-23" stroke="#d6e1e9" strokeWidth=".85" fill="none" opacity=".24"/><path d="M2-37c7-13-9-17-3-31" stroke="#f2e2cc" strokeWidth=".45" fill="none" opacity=".2"/></g>}
  </g>)}
  {d.decorations.filter(x=>x.kind==='incense').map((x,i)=><g key={i} transform={`translate(${x.x} ${x.y}) rotate(${x.rotation}) scale(${x.scale})`}><g className="live-incense-smoke" fill="none" stroke="#cedee6" strokeWidth=".7" opacity=".4">{[-7,0,7].map((v,j)=><path key={v} d={`M${v} ${-27-j*4}q-8-8 1-17t-2-16`}/>)}</g></g>)}
  {(!r.light||r.sparks)&&<g className="live-art-sparks" fill={color} opacity={d.glowPower/100}>{Array.from({length:r.light?9:5},(_,i)=><circle key={i} cx={56+i*37%220} cy={64+i*23%127} r={.7+i%3*.4} style={{'--spark-phase':(-i*.7)+'s'} as CSSProperties}/>)}</g>}
 </svg>;
}

export function DisplayWater({design:d,url}:{design:Design;url?:string}){
 const id=useId().replace(/:/g,''),r=realOptions(d.realism),color=r.light?REAL_LIGHTS.find(x=>x[0]===r.lightPreset)![2]:d.glow;
 const reflection=r.light?r.reflection/100:.5;
 return <svg className="display-water" viewBox="0 0 320 310" aria-hidden="true">
  <defs>
   <linearGradient id={id+'-fade'} x1="0" y1="0" x2="0" y2="1"><stop stopColor="#fff" stopOpacity=".72"/><stop offset=".55" stopColor="#fff" stopOpacity=".28"/><stop offset="1" stopColor="#fff" stopOpacity="0"/></linearGradient>
   <radialGradient id={id+'-pool'}><stop stopColor={color} stopOpacity=".28"/><stop offset="1" stopColor={color} stopOpacity="0"/></radialGradient>
   <mask id={id+'-mirror'} maskUnits="userSpaceOnUse" x="0" y="210" width="320" height="100"><rect x="0" y="210" width="320" height="100" fill={'url(#'+id+'-fade)'}/>{Array.from({length:10},(_,i)=><rect key={i} x="0" y={216+i*8} width="320" height={1.2+i*.12} fill="#000" opacity=".6"/>)}</mask>
  </defs>
  <ellipse className="live-water-glow" cx="160" cy="218" rx="150" ry="25" fill={'url(#'+id+'-pool)'} opacity={d.glowPower/100}/>
  {url&&reflection>0&&<g mask={'url(#'+id+'-mirror)'} opacity={reflection}><g className="live-reflection"><image href={url} x="0" y="0" width="320" height="250" transform="translate(0 302) scale(1 -.42)" preserveAspectRatio="none"/></g></g>}
  {(!r.light||r.ripples)&&<>
   <g className="live-wake" fill="none" stroke={color} strokeWidth=".65"><path d="M64 210Q155 235 276 215Q300 211 318 216" opacity=".3"/><path d="M79 217Q177 245 304 222" opacity=".2"/><path d="M93 225Q204 248 318 232" opacity=".12"/></g>
   {[0,1,2].map(i=><g className="live-ripple" key={i} style={{'--ripple-delay':(-i*1.8)+'s'} as CSSProperties}><ellipse cx="160" cy="217" rx="108" ry="12" fill="none" stroke={color} strokeWidth=".8"/><path d="M69 221Q160 238 251 221" fill="none" stroke="#fff0cd" strokeWidth=".45" opacity=".5"/></g>)}
  </>}
  {lightSources(d).length>0&&reflection>0&&<g className="live-fire-reflection" fill="#ffe2a2" opacity={reflection*.65}>{[0,1,2,3,4,5].map(i=><ellipse key={i} cx={160+Math.sin(i*1.7)*4} cy={228+i*8} rx={8-i*.85} ry=".9"/>)}</g>}
 </svg>;
}
