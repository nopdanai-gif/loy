'use client';
import {useEffect,useRef,useState} from 'react';
import {Download,Image as ImageIcon} from 'lucide-react';
import KrathongArt from './KrathongArt';
import {readDesign} from '../design';
import {inlineRealisticImages} from '../inline-svg';
import type {EventInfo,Wish} from '../types';
export default function SouvenirCard({wish,event}:{wish:Wish;event:Pick<EventInfo,'title'|'place'>}){
  const source=useRef<HTMLDivElement>(null),[url,setUrl]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),mounted=useRef(true),revision=useRef(0);
  useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;};},[]);
  useEffect(()=>{revision.current++;setUrl('');setError('');},[wish.design,wish.name,wish.message,wish.photo?.url,event.title,event.place]);
  useEffect(()=>()=>{if(url)URL.revokeObjectURL(url);},[url]);
  async function create(){
    if(busy)return;const version=revision.current;setBusy(true);setError('');
    try{
      const svg=source.current?.querySelector('svg')?.cloneNode(true) as SVGSVGElement|undefined;if(!svg)throw new Error('ยังเตรียมกระทงไม่พร้อม กรุณาลองอีกครั้ง');
      svg.setAttribute('xmlns','http://www.w3.org/2000/svg');svg.setAttribute('width','960');svg.setAttribute('height','750');svg.removeAttribute('class');
      await inlineRealisticImages(svg);
      const {createSouvenir}=await import('../souvenir');const blob=await createSouvenir(new XMLSerializer().serializeToString(svg),wish,event);
      if(!mounted.current||version!==revision.current)return;setUrl(URL.createObjectURL(blob));
    }catch(e){if(mounted.current)setError((e as Error).message);}finally{if(mounted.current)setBusy(false);}
  }
  return <div className="souvenir-card"><div ref={source} className="souvenir-source" aria-hidden="true"><KrathongArt design={readDesign(wish.design,wish.style)}/></div><p className="souvenir-title"><ImageIcon size={17}/>เก็บค่ำคืนนี้ไว้เป็นความทรงจำ</p><p className="muted small">กระทง ลายวาด ชื่อ และคำอวยพรของคุณ{wish.photo?' พร้อมรูปที่แนบ':''}<br/>ในกรอบงานบางทอง พร้อมตรา อบต.</p>{!url?<button type="button" className="button outline" disabled={busy} onClick={create}>{busy?'กำลังสร้างภาพที่ระลึก…':'สร้างภาพที่ระลึก'}</button>:<><img className="souvenir-result" src={url} alt={'ภาพที่ระลึกกระทงของ '+wish.name} width="1080" height="1440"/><a className="button gold" href={url} download={'bang-thong-krathong-'+wish.id+'.png'}><Download size={16}/>ดาวน์โหลดภาพ PNG</a><p className="muted small">บนมือถือ แตะดาวน์โหลด หรือกดค้างที่ภาพเพื่อบันทึก</p></>}{error&&<p className="error" role="alert">{error}</p>}</div>;
}
