'use client';
import {useEffect,useRef,useState,useMemo,memo,type CSSProperties} from 'react';
import {FramedPhoto,Badge,FlairBurst,flairStyle} from './FlairArt';import {readFlair,FLAIR_PRESETS} from '../flair';
import DisplayArt from './DisplayArt';import usePageVisibility from './usePageVisibility';
import {animateRiverBoat,motionSeed} from '../river-motion';
import {DEFAULT_REALISM,REAL_BASES} from '../realism';
import {QUEUE_LIMIT,FEED_BATCH,MAX_VISIBLE_BOATS,makeCheckpoint,readCheckpoint,appendFeed,rememberShown} from '../display-queue';import Ambience from './Ambience';import SceneControls from './SceneControls';import Brand from './Brand';
import BangThongSeal from './BangThongSeal';import LedControls from './LedControls';import CeremonyStage from './CeremonyStage';
import {api,uid} from '../client';import {DEFAULT_SCENE,readDesign,readScene,sampleDesign} from '../design';import {readLed,ceremonyPhase} from '../event-options';import type {EventInfo,Wish} from '../types';
type Floating=Wish&{key:string;lane:number;started:number;duration:number};
type Feature={wish:Wish;key:string;until:number};
const samples=[['อิ่มใจ','ขอให้ครอบครัวมีความสุขและสุขภาพแข็งแรง'],['ต้นกล้า','ขอให้ทุกการเริ่มต้นเต็มไปด้วยสิ่งดี ๆ'],['มะลิ','ขอให้ความสุขลอยมาหาเราในทุกวัน'],['นภา','ขอให้ได้พบเจอผู้คนที่อบอุ่นหัวใจ'],['กานต์','ปล่อยความทุกข์ไปกับสายน้ำ แล้วเริ่มต้นใหม่'],['พิมพ์ดาว','ให้ความหวังผลิบาน ในทุกวันของเรา']];
const Boat=memo(function Boat({wish:w,paused}:{wish:Floating;paused:boolean}){
 const element=useRef<HTMLElement>(null),motion=useRef<ReturnType<typeof animateRiverBoat>|null>(null),d=w.design!,seed=motionSeed(w.id);
 useEffect(()=>{if(!element.current)return;const driver=animateRiverBoat(element.current,{duration:w.duration,lane:w.lane,seed,paused});motion.current=driver;return()=>{driver.destroy();motion.current=null;};},[w.key,w.duration,w.lane,seed]);
 useEffect(()=>{motion.current?.setPaused(paused);},[paused]);
 return <article ref={element} className="floating-krathong" style={{'--lane':w.lane,'--duration':w.duration+'ms','--wish-glow':d.glow,'--hull-scale':1.12-w.lane*.055,'--bob-time':(4.8+seed%23/10)+'s','--bob-phase':-(seed%50)/10+'s',zIndex:10-w.lane} as CSSProperties}>
  <FlairBurst flair={d.flair} small/><div className={"wish-label flair-nameplate nameplate-"+readFlair(d.flair).nameplate+(w.photo?" has-photo":"")} style={flairStyle(d.flair)}>{w.photo&&<FramedPhoto className="boat-photo" src={w.photo.url} flair={d.flair} alt={"รูปของ "+w.name}/>}<div><strong><Badge flair={d.flair}/>{w.name}</strong><p>{w.message}</p></div></div><DisplayArt design={d}/>
 </article>;
});
function riverSample(index:number){
 const design={...sampleDesign(index),flair:FLAIR_PRESETS[index%FLAIR_PRESETS.length].value};if(index%4===3)return design;
 return {...design,realism:{...DEFAULT_REALISM,shape:true,color:true,decor:true,light:true,base:REAL_BASES[index%REAL_BASES.length].id,finish:index%2?'dew' as const:'gold' as const,reflection:65,sparks:true,motion:index%2?'breeze' as const:'gentle' as const}};
}
export default function Display({id}:{id:string}){
  const demo=id==='demo',visible=usePageVisibility();
  const [event,setEvent]=useState<EventInfo|null>(demo?{id,title:'สายน้ำแห่งคำอวยพร',place:'คืนจันทร์เต็มดวง · บางทอง',accepting:1,moderation:0,paused:0,interval_ms:2200,float_ms:24000,scene:DEFAULT_SCENE,created_at:0}:null);
  const [floating,setFloating]=useState<Floating[]>([]),[featured,setFeatured]=useState<Feature|null>(null),[batch,setBatch]=useState<Wish[]>([]),[clock,setClock]=useState(0),[error,setError]=useState(''),[connected,setConnected]=useState(demo),[queued,setQueued]=useState(0),[upcoming,setUpcoming]=useState<Wish[]>([]),[motionPaused,setMotionPaused]=useState(false),[controls,setControls]=useState(false),[localTools,setLocalTools]=useState<boolean|null>(null),[fullscreenError,setFullscreenError]=useState('');
  const buffer=useRef<Wish[]>([]),active=useRef<Floating[]>([]),cursor=useRef(0),hidden=useRef(0),settings=useRef(event),last=useRef(0),lane=useRef(0),sample=useRef(0),feature=useRef<Feature|null>(null),batchRef=useRef<Wish[]>([]),batchId=useRef(''),serverOffset=useRef(0),performed=useRef(new Set<string>()),shown=useRef(new Set<string>()),special=useRef(new Map<string,number>());settings.current=event;
  const persistTimer=useRef<ReturnType<typeof setTimeout>|null>(null),lastSaved=useRef('');
  const motionHold=useRef(motionPaused);motionHold.current=motionPaused;
  function syncQueue(){setQueued(buffer.current.length);setUpcoming(old=>{const next=buffer.current.slice(0,2);return old.length===next.length&&old.every((w,i)=>w===next[i])?old:next;});}
  function saveNow(){
    if(demo)return;
    if(persistTimer.current){clearTimeout(persistTimer.current);persistTimer.current=null;}
    try{const text=JSON.stringify(makeCheckpoint(cursor.current,[...active.current,...buffer.current],shown.current,special.current));if(text!==lastSaved.current){sessionStorage.setItem('river-'+id,text);lastSaved.current=text;}}catch{}
  }
  function save(){if(!demo&&!persistTimer.current)persistTimer.current=setTimeout(saveNow,800);}
  useEffect(()=>{window.addEventListener('pagehide',saveNow);return()=>{window.removeEventListener('pagehide',saveNow);saveNow();};},[id,demo]);
  useEffect(()=>{const key=(e:KeyboardEvent)=>{if(e.key==='Escape'){setLocalTools(true);setControls(false);}};window.addEventListener('keydown',key);return()=>window.removeEventListener('keydown',key);},[]);
  useEffect(()=>{setLocalTools(null);},[event?.led?.showControls]);
  useEffect(()=>{
    if(demo)return;
    try{const checkpoint=readCheckpoint(sessionStorage.getItem('river-'+id));if(checkpoint){cursor.current=checkpoint.cursor;shown.current=new Set(checkpoint.shown);special.current=new Map(checkpoint.special);}}catch{}
    // Replay removals after a reload, so formerly queued hidden wishes stay hidden.
    hidden.current=0;
    let stopped=false,inFlight=false,failures=0,timer:ReturnType<typeof setTimeout>;
    const controller=new AbortController();
    async function poll(){
      if(stopped||inFlight)return;
      if(document.hidden){timer=setTimeout(poll,4000);return;}
      inFlight=true;let moreHidden=false;
      try{
        const limit=Math.max(0,Math.min(FEED_BATCH,QUEUE_LIMIT-buffer.current.length)),started=Date.now();
        const d=await api('events/'+id+'/feed?after='+cursor.current+'&hiddenAfter='+hidden.current+'&limit='+limit+'&ceremonySeen='+encodeURIComponent(batchId.current),'GET',undefined,{signal:controller.signal,retries:0});if(stopped)return;
        if(d.serverTime)serverOffset.current=d.serverTime-(started+Date.now())/2;
        setEvent(previous=>JSON.stringify(previous)===JSON.stringify(d.event)?previous:d.event);setConnected(true);setError('');failures=0;
        const removed=new Set(d.hidden.map(w=>w.id));moreHidden=d.hidden.length===100;
        buffer.current=buffer.current.filter(w=>!removed.has(w.id));
        if(active.current.some(w=>removed.has(w.id))){active.current=active.current.filter(w=>!removed.has(w.id));setFloating([...active.current]);}
        if(feature.current&&removed.has(feature.current.wish.id)){feature.current=null;setFeatured(null);}
        if(d.ceremonyWishes!==undefined){batchId.current=d.event.ceremony?.id??'';batchRef.current=d.ceremonyWishes;}
        if(d.ceremonyWishes!==undefined||batchRef.current.some(w=>removed.has(w.id))){batchRef.current=batchRef.current.filter(w=>!removed.has(w.id));setBatch([...batchRef.current]);}
        buffer.current=appendFeed(buffer.current,d.wishes,active.current,new Set([...shown.current,...special.current.keys()]),removed);
        cursor.current=d.cursor;hidden.current=d.hiddenCursor;for(const [key,seq] of special.current)if(seq<=cursor.current)special.current.delete(key);syncQueue();save();
      }catch(e){if(!stopped){failures++;setConnected(false);setError((e as Error).message);}}
      finally{
        inFlight=false;
        if(!stopped)timer=setTimeout(poll,failures?Math.min(30000,2000*2**Math.min(4,failures))+Math.random()*500:moreHidden?150:2500);
      }
    }
    const wake=()=>{if(!document.hidden){clearTimeout(timer);void poll();}};
    document.addEventListener('visibilitychange',wake);void poll();
    return()=>{stopped=true;clearTimeout(timer);controller.abort();document.removeEventListener('visibilitychange',wake);saveNow();};
  },[id,demo]);
  useEffect(()=>{
    let previous=Date.now(),hiddenSince=0,clockKey='';
    const tick=setInterval(()=>{
      const now=Date.now();
      if(document.hidden){if(!hiddenSince)hiddenSince=now;previous=now;return;}
      if(hiddenSince){const pause=now-hiddenSince;for(const w of active.current)w.started+=pause;if(feature.current)feature.current.until+=pause;last.current+=pause;hiddenSince=0;previous=now;}
      const elapsed=Math.max(0,now-previous);previous=now;const s=settings.current;if(!s)return;
      const led=readLed(s.led),serverNow=now+serverOffset.current,phase=ceremonyPhase(s.ceremony,serverNow),locked=phase!=='idle';
      const nextClockKey=phase==='countdown'?phase+Math.ceil((s.ceremony!.releaseAt-serverNow)/1000):phase;if(nextClockKey!==clockKey){clockKey=nextClockKey;setClock(serverNow);}
      let changed=false;
      if(locked||motionHold.current){
        for(const w of active.current)w.started+=elapsed;
        if(feature.current)feature.current.until+=elapsed;
        const ceremony=s.ceremony!;
        if(locked&&phase==='fleet'&&batchId.current===ceremony.id&&!performed.current.has(ceremony.id)){
          performed.current.clear();performed.current.add(ceremony.id);rememberShown(shown.current,batchRef.current.map(w=>w.id));for(const w of batchRef.current)if((w.seq??Number.MAX_SAFE_INTEGER)>cursor.current)special.current.set(w.id,w.seq??Number.MAX_SAFE_INTEGER);
          const selected=new Set(batchRef.current.map(w=>w.id));buffer.current=buffer.current.filter(w=>!selected.has(w.id));active.current=active.current.filter(w=>!selected.has(w.id));syncQueue();
          if(feature.current&&selected.has(feature.current.wish.id)){feature.current=null;setFeatured(null);}changed=true;
        }
      }else{
        rememberShown(shown.current,active.current.filter(w=>now-w.started>=w.duration).map(w=>w.id));const remaining=active.current.filter(w=>now-w.started<w.duration);if(remaining.length!==active.current.length){active.current=remaining;changed=true;}
        if(feature.current&&(now>=feature.current.until||!led.highlight)){feature.current=null;setFeatured(null);}
        const releaseGap=Math.max(s.interval_ms,led.highlight?5200:0);
        if(!s.paused&&now-last.current>=releaseGap&&active.current.length<MAX_VISIBLE_BOATS){
          const index=sample.current,a=samples[index%samples.length];
          const next:Wish|undefined=demo?{id:'demo-'+index,name:a[0],message:a[1],style:index%4,design:riverSample(index)}:buffer.current[0];
          if(next){
            const duration=Math.max(8000,Math.min(60000,(s.float_ms??24000)/(next.design??readDesign(undefined,next.style)).speed));
            const gap=Math.min(.55,Math.max(.16,((innerWidth<700?185:245)*Math.max(1,led.fontScale)+40)/(innerWidth+270)));
            const order=[0,2,4,1,3],available=Array.from({length:5},(_,i)=>order[(lane.current+i)%5]).find(l=>active.current.every(w=>{
              if(Math.abs(w.lane-l)>(led.fontScale>1.3?3:2))return true;
              return (now-w.started)/w.duration>=gap&&(w.duration-now+w.started)/duration<=1-gap;
            }));
            if(available!==undefined){
              if(demo)sample.current++;else buffer.current.shift();lane.current=(order.indexOf(available)+1)%5;last.current=now;
              const item={...next,design:next.design??readDesign(undefined,next.style),key:uid(),lane:available,started:now,duration};
              active.current=[...active.current,item];changed=true;syncQueue();
              if(led.highlight){feature.current={wish:item,key:item.key,until:now+5000};setFeatured(feature.current);}
            }
          }
        }
      }
      if(changed){setFloating([...active.current]);save();}
    },200);return()=>clearInterval(tick);
  },[id,demo]);
  function demoCeremony(){
    if(!event)return;const startsAt=Date.now()+3500,releaseAt=startsAt+10000,c={id:uid(),startsAt,releaseAt,endsAt:releaseAt+18000,count:6,status:'scheduled' as const};
    batchRef.current=Array.from({length:6},(_,i)=>({id:'festival-demo-'+i,name:samples[i][0],message:samples[i][1],style:i%4,design:riverSample(i+2)}));batchId.current=c.id;setBatch([...batchRef.current]);setEvent({...event,ceremony:c});setControls(false);setClock(Date.now());
  }
  async function full(){try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{setFullscreenError('อุปกรณ์นี้ไม่รองรับปุ่มเต็มจอ ลองใช้โหมดเต็มจอของเบราว์เซอร์');}}
  const scene=useMemo(()=>readScene(event?.scene),[event?.scene]),led=useMemo(()=>readLed(event?.led),[event?.led]),phase=ceremonyPhase(event?.ceremony,clock||Date.now()+serverOffset.current),toolsVisible=localTools??led.showControls;
  return <main className={'display scenic full-motion qr-'+led.qrPosition+(!visible?' tab-sleep':'')+(motionPaused?' motion-paused':'')+(phase!=='idle'?' ceremony-on':'')+(!toolsVisible?' clean-display':'')} style={{'--scene-brightness':scene.brightness/100,'--text-scale':led.fontScale,'--qr-size':led.qrSize+'px','--safe-margin':led.safeMargin+'%'} as CSSProperties}>
    <Ambience scene={scene}/><header className="display-header"><div className="display-title-group"><div className="display-brand-row">{led.showLogo&&<BangThongSeal/>}<Brand/></div><h1>{event?.title??'สายน้ำแห่งคำอวยพร'}</h1><p>{event?.place}</p><span className="live-badge"><i className={connected?'connected':''}/>{demo?'ภาพตัวอย่าง · ข้อความสมมติ':connected?'เชื่อมต่อกับงานแล้ว':'กำลังเชื่อมต่อใหม่…'}</span>{event?.paused?<span className="live-badge">พักการปล่อยกระทง</span>:null}</div>
    {demo?<div className="demo-invite"><p>เติมสีสันให้คืนพิเศษของคุณ</p><a className="button gold" href="/studio">ลองแต่งกระทง ↗</a><button className="demo-settings-button" aria-expanded={controls} onClick={()=>setControls(!controls)}>☷ แสงสี · จอ LED · ช่วงพิเศษ</button></div>:led.showQR?<aside className="qr-invite"><img src={'/api/events/'+id+'/qr'} alt="QR สำหรับส่งคำอวยพร" width={led.qrSize} height={led.qrSize}/><div><strong>สแกนเพื่อลอยกระทง</strong><p>แต่งกระทง · วาดลาย · ฝากคำอวยพร<br/>แล้วมองหากระทงของคุณ</p><a href={'/join/'+id}>เปิดหน้าส่งกระทง ↗</a></div></aside>:null}</header>
    {demo&&controls&&event&&<section className="demo-controls panel" aria-label="ปรับแสงและความเร็วตัวอย่าง"><div className="section-heading"><h2>เนรมิตค่ำคืนนี้</h2><button aria-label="ปิดการตั้งค่าตัวอย่าง" onClick={()=>setControls(false)}>×</button></div><label className="range-label" htmlFor="demo-speed">ความเร็วการลอย <output>{(24000/(event.float_ms??24000)).toFixed(1)}×</output></label><input id="demo-speed" type="range" min=".5" max="2" step=".1" value={+(24000/(event.float_ms??24000)).toFixed(1)} onChange={e=>setEvent({...event,float_ms:Math.round(24000/+e.target.value)})}/><label className="range-label" htmlFor="demo-interval">ปล่อยกระทงทุก <output>{(event.interval_ms/1000).toFixed(1)} วินาที</output></label><input id="demo-interval" type="range" min="600" max="6000" step="100" value={event.interval_ms} onChange={e=>setEvent({...event,interval_ms:+e.target.value})}/><SceneControls value={scene} onChange={v=>setEvent({...event,scene:v})}/><LedControls value={led} onChange={v=>setEvent({...event,led:v})}/><button className="button gold wide" disabled={phase!=='idle'} onClick={demoCeremony}>✧ ลองนับถอยหลังและลอยพร้อมกัน</button><p className="muted small">ค่าที่ปรับในหน้านี้เป็นตัวอย่าง ไม่มีผลกับห้องงานจริง</p></section>}
    {!event&&error&&<div className="display-error panel" role="alert">{error}<br/><a href="/">กลับหน้าหลัก</a></div>}
    <div className="art-preload" aria-hidden="true">{upcoming.map(w=><DisplayArt key={w.id} design={w.design??readDesign(undefined,w.style)}/>)}</div>
    <div className="river" aria-label="กระทงที่กำลังลอย">{floating.map(w=><Boat key={w.key} wish={w} paused={!visible||motionPaused||phase!=='idle'}/>)}</div>
    {featured&&led.highlight&&<aside className="arrival-highlight" key={featured.key} style={{'--arrival-color':(featured.wish.design??readDesign(undefined,featured.wish.style)).glow} as CSSProperties} aria-label="ไฮไลต์กระทงใหม่"><FlairBurst flair={featured.wish.design?.flair}/><div className="arrival-art"><DisplayArt design={featured.wish.design??readDesign(undefined,featured.wish.style)}/><span className="arrival-sparkles" aria-hidden="true">✧ · ✦ · ✧</span></div><div className="arrival-copy">{featured.wish.photo&&<FramedPhoto className="arrival-photo" src={featured.wish.photo.url} flair={featured.wish.design?.flair} alt={"รูปของ "+featured.wish.name}/>}<p className="eyebrow">คำอวยพรที่เพิ่งลอยมาถึง</p><h2 style={flairStyle(featured.wish.design?.flair)}><Badge flair={featured.wish.design?.flair}/>{featured.wish.name}</h2><p className="arrival-message">“{featured.wish.message}”</p></div></aside>}
    {phase!=='idle'&&event?.ceremony&&<CeremonyStage ceremony={event.ceremony} wishes={batch} phase={phase} now={clock||Date.now()+serverOffset.current} logo={led.showLogo} quiet={false}/>}
    {!demo&&event&&floating.length===0&&queued===0&&phase==='idle'&&<div className="river-empty"><span>✧</span><p>สายน้ำพร้อมรับคำอวยพรของคุณ</p></div>}
    {toolsVisible?<footer className="display-footer"><a href="/">← หน้าหลัก</a><span>{demo?'กระทงตัวอย่าง ไม่มีการบันทึกคำอวยพร':error?'การเชื่อมต่อขัดข้อง กำลังลองอีกครั้ง':queued>0?'กำลังทยอยปล่อยกระทงตามลำดับ':'ให้ความปรารถนาดีล่องไปด้วยกัน'}</span><div><button onClick={()=>setMotionPaused(!motionPaused)} aria-pressed={motionPaused}>{motionPaused?'▶ ลอยต่อ':'⏸ พักการเคลื่อนไหว'}</button><button onClick={()=>{setLocalTools(false);setControls(false);}}>ซ่อนเครื่องมือ</button><button onClick={full} aria-label="เปิดหรือปิดจอเต็ม">⛶ เต็มจอ</button></div></footer>:<button className="reveal-controls" aria-label="แสดงเครื่องมือจอฉาย หรือกด Escape" title="แสดงเครื่องมือ" onClick={()=>setLocalTools(true)}>☷</button>}
    {fullscreenError&&toolsVisible&&<p className="fullscreen-note" role="status">{fullscreenError}</p>}
  </main>;
}
