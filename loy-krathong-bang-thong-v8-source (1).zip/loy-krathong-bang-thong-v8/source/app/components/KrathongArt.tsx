'use client';
import {AuraLayers} from './FlairArt';
import {useId,memo} from 'react';
import {realOptions,REAL_LIGHTS} from '../realism';
import {RealToneFilter,RealBaseLayers,RealCandle,RealDecorationSymbol,RealWater,RealAtmosphere} from './RealisticArt';
import {type Design,type DecorationKind} from '../design';
import {candleHeight} from '../art-motion';

export function DecorationSymbol({kind,color,staticEffects=false}:{kind:DecorationKind;color:string;staticEffects?:boolean}){
  const star='M0-24 7-8 24-7 11 5 15 23 0 14-15 23-11 5-24-7-7-8Z';
  const flower=(petals:number,long:number,width:number)=><>{Array.from({length:petals},(_,i)=><ellipse key={i} cx="0" cy={-long*.5} rx={width} ry={long*.65} transform={'rotate('+i*360/petals+')'}/>)}<circle r="6" fill="#ffda82"/></>;
  return <g fill={color} stroke="#fff0c3" strokeWidth="1" strokeLinejoin="round">
    {kind==='lotus'&&<>{[-50,-25,0,25,50].map(a=><path key={a} d="M0 16Q-24-8 0-29Q24-8 0 16" transform={'rotate('+a+' 0 16)'}/>)}<path d="M-26 12Q0 29 26 12Q0 35-26 12Z" fill="#64b894"/></>}
    {kind==='rose'&&<>{flower(7,18,11)}<path d="M-7-1Q-6-14 7-6Q19 9 0 12Q-18 7-9-7M0-4Q10 0 3 7" fill="none" stroke="#fff0c3"/></>}
    {kind==='daisy'&&flower(10,22,5)}
    {kind==='marigold'&&<>{flower(12,18,8)}<circle r="12" fill="#ffd66d" strokeDasharray="2 3"/><circle r="6" fill="#e8a03d"/></>}
    {kind==='orchid'&&<>{flower(5,22,9)}<path d="M-9 5L0 17 9 5 0 0Z" fill="#efb5db"/></>}
    {kind==='candle'&&<><rect x="-5" y="-8" width="10" height="34" rx="2"/>{!staticEffects&&<><path className="art-flame" d="M0-34Q-14-16 0-12Q13-17 0-34" fill="#ffcf72"/><path d="M0-23Q-6-15 0-14Q5-16 0-23" fill="#fff4c1"/></>}</>}
    {kind==='incense'&&<>{[-8,0,8].map((x,i)=><g key={x}><path d={'M'+x+' 26V'+(-15-i*4)} stroke="#edbc88" strokeWidth="2.5"/><circle cx={x} cy={-15-i*4} r="2" fill="#ff936c"/>{!staticEffects&&<path d={'M'+x+' '+(-22-i*4)+'q8-7 0-13'} fill="none" opacity=".4"/>}</g>)}</>}
    {kind==='leaf'&&<><path d="M-20 21Q-31-12 22-27Q32 13-20 21Z"/><path d="M-20 21L19-23M-9 9L-13-8M2-2L16 1" fill="none"/></>}
    {kind==='palm'&&<>{[-55,-28,0,28,55].map(a=><path key={a} d="M0 22Q-15-5 0-27Q15-5 0 22" transform={'rotate('+a+' 0 22)'}/>)}<path d="M0 22V-8" fill="none"/></>}
    {kind==='heart'&&<path d="M0 22C-55-9-13-42 0-19C13-42 55-9 0 22Z"/>}
    {kind==='star'&&<path d={star}/>}
    {kind==='moon'&&<path d="M8-25A26 26 0 1 0 22 17A23 23 0 0 1 8-25Z"/>}
    {kind==='diamond'&&<><path d="M-22-8-11-22 11-22 22-8 0 25Z"/><path d="M-22-8H22M-11-22-8-8 0 25 8-8 11-22M-8-8H8" fill="none"/></>}
    {kind==='pearl'&&<><circle r="19"/><circle cx="-6" cy="-7" r="6" fill="#fff" stroke="none" opacity=".75"/><path d="M-8 14Q10 19 15 6" fill="none" opacity=".5"/></>}
    {kind==='ribbon'&&<><path d="M0 0Q-36-38-28-3Q-29 14 0 0Q29 14 28-3Q36-38 0 0ZM-6 0-15 27-3 23 0 8 6 25 17 27 6 0"/><circle r="6"/></>}
    {kind==='butterfly'&&<><path d="M0 0C-42-42-37 20-6 9C-30 32-2 35 0 9C2 35 30 32 6 9C37 20 42-42 0 0Z"/><path d="M0 17V-13M0-10-6-18M0-10 6-18" fill="none" strokeWidth="2"/></>}
    {kind==='fish'&&<><path d="M-19 0Q1-26 22 0Q1 26-19 0L-31 12V-12Z"/><circle cx="13" cy="-2" r="2.5" fill="#102238"/><path d="M-2-11 3 0-2 11" fill="none"/></>}
    {kind==='bird'&&<><path d="M-28 5Q-21-11-1 0Q-3-22 18-27Q10-6 15 0L29 5 15 8Q4 28-15 12L-28 15Z"/><circle cx="16" cy="3" r="1.5" fill="#102238"/></>}
    {kind==='sparkle'&&<><path d="M0-29 6-6 25 0 6 6 0 29-6 6-25 0-6-6Z"/><circle cx="21" cy="-23" r="3"/><circle cx="-24" cy="20" r="2"/></>}
    {kind==='lantern'&&<><path d="M-15-20Q-23 0-12 19H12Q23 0 15-20Z"/><path d="M-15-20H15M-12 19H12M0 20V31M-6-19Q-12 0-5 18M6-19Q12 0 5 18" fill="none"/><circle cy="6" r="6" fill="#fff1a7" stroke="none"/></>}
  </g>;
}

export function ArtLayers({design:d,surfaceOnly=false}:{design:Design;surfaceOnly?:boolean}){
  const id=useId().replace(/:/g,''),r=realOptions(d.realism),lightColor=r.light?REAL_LIGHTS.find(x=>x[0]===r.lightPreset)![2]:d.glow;
  const petal='M160 175Q103 116 160 65Q217 116 160 175Z';
  const primary='url(#'+id+'-petal)',base='url(#'+id+'-base)';
  return <>
    <defs>
      <RealToneFilter id={id+'-tone'} r={r} tint={d.primary}/>
      <linearGradient id={id+'-petal'} x1="0" y1="0" x2=".25" y2="1"><stop offset="0" stopColor="#fff6dd"/><stop offset=".35" stopColor={d.primary}/><stop offset="1" stopColor={d.secondary}/></linearGradient>
      <linearGradient id={id+'-base'} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={d.secondary}/><stop offset="1" stopColor="#164237"/></linearGradient>
      <radialGradient id={id+'-glow'}><stop offset="0" stopColor={d.glow} stopOpacity=".6"/><stop offset="1" stopColor={d.glow} stopOpacity="0"/></radialGradient>
    </defs>
    {!surfaceOnly&&<AuraLayers flair={d.flair}/>}
    <ellipse cx="160" cy="207" rx="146" ry="34" fill={'url(#'+id+'-glow)'} opacity={d.glowPower/100}/>
    <ellipse cx="160" cy="211" rx="106" ry="8" fill="none" stroke={d.glow} strokeOpacity={d.glowPower/250}/>
    {r.light&&<>{!surfaceOnly&&<RealWater id={id} r={r} bodyId={id+'-body'} color={lightColor}/>}<RealAtmosphere r={surfaceOnly?{...r,sparks:false}:r} glow={lightColor}/></>}
    <g className={!surfaceOnly&&r.light?'real-motion real-motion-'+r.motion:undefined}>
    <g id={id+'-body'} filter={r.shape||r.color?'url(#'+id+'-tone)':undefined}>
    {r.shape?<RealBaseLayers r={r} id={id}/>:<>
    <ellipse cx="160" cy="194" rx="105" ry="24" fill={base} stroke="#c4ca8d" strokeWidth=".8"/>
    <path d="M55 188Q160 218 265 188L254 204Q160 230 66 204Z" fill={base} stroke="#e9cc8a" strokeWidth="1"/>
    <g fill={primary} stroke="#fff0c3" strokeWidth="1.1" strokeLinejoin="round">
      {d.shape==='lotus'&&<>{[-65,-43,-22,0,22,43,65].map(a=><path key={a} d={petal} transform={'rotate('+a+' 160 177)'}/>)}{[-58,-29,0,29,58].map(a=><path key={a} d="M160 194Q116 157 160 118Q204 157 160 194Z" transform={'rotate('+a+' 160 194)'}/>)}</>}
      {d.shape==='leaf'&&<>{[-75,-50,-25,0,25,50,75].map(a=><g key={a} transform={'rotate('+a+' 160 182)'}><path d="M139 178 160 48 181 178Z" fill={d.secondary}/><path d="M147 172 160 76 172 172Z" opacity=".7"/></g>)}<path d="M63 181Q160 144 257 181Q160 216 63 181Z"/></>}
      {d.shape==='swan'&&<><path d="M72 168Q101 131 156 164Q188 134 167 93Q143 42 183 42Q205 42 203 64L191 71Q185 53 180 62Q171 76 194 99Q223 137 217 166Q192 211 117 190Z"/><path d="M98 165Q104 104 170 139Q156 176 116 179Z"/><path d="M190 63 216 65 200 74Z" fill="#ffce73"/><circle cx="191" cy="55" r="2.3" fill="#172633"/><path d="M110 164Q134 130 160 140M119 172Q140 149 164 145" fill="none"/></>}
      {d.shape==='heart'&&<><path d="M160 196C-14 100 107 9 160 98C213 9 334 100 160 196Z"/><path d="M160 174C53 114 125 69 160 121C195 69 267 114 160 174Z" fill={d.secondary} opacity=".65"/></>}
      {d.shape==='moon'&&<><path d="M176 43A79 79 0 1 0 238 164A71 71 0 0 1 176 43Z"/><path d="M126 97Q88 154 148 181" fill="none" strokeWidth="2" opacity=".5"/><g transform="translate(204 112) scale(.8)"><DecorationSymbol kind="star" color={d.secondary}/></g></>}
      {d.shape==='star'&&<><path d="M160 39 188 100 255 108 205 152 220 204 160 178 100 204 115 152 65 108 132 100Z"/><path d="M160 73 178 120 224 122 189 148 196 180 160 160 124 180 131 148 96 122 142 120Z" fill={d.secondary} opacity=".6"/></>}
      {d.shape==='palace'&&<><path d="M110 177V127L160 90 210 127V177Z"/><path d="M68 151Q97 144 108 102Q117 142 143 151ZM177 151Q203 144 214 102Q223 142 252 151Z"/><path d="M104 128Q149 104 160 43Q171 104 216 128Z"/><path d="M125 111Q153 90 160 63Q167 90 195 111" fill="none"/><path d="M73 151H135V181H73ZM185 151H247V181H185Z" fill={d.secondary}/><path d="M146 178V142Q160 124 174 142V178Z" fill={d.secondary}/></>}
      {d.shape==='boat'&&<><path d="M35 133Q64 174 160 160Q256 174 285 133Q266 203 160 198Q54 203 35 133Z"/><path d="M48 156Q160 193 272 156" fill="none"/>{[115,160,205].map((x,i)=><g transform={'translate('+x+' '+(126-i%2*18)+') scale(.9)'} key={x}><DecorationSymbol kind="lotus" color={d.primary}/></g>)}</>}
    </g>
    <path d="M65 197Q160 224 255 197" fill="none" stroke={d.glow} strokeWidth="2" opacity={d.glowPower/100}/>
    </>}
    </g>
    {Array.from({length:d.candles},(_,i)=><g key={i} transform={'translate('+(160+(i-(d.candles-1)/2)*24)+' '+candleHeight(d)+')'}>
      {r.shape||r.light?<RealCandle staticEffects={surfaceOnly} id={id+'-candle-'+i} flame={r.light?r.flameSize:1} smoke={r.light&&r.smoke} glow={lightColor}/>:<>
      <rect x="-4" y="-14" width="8" height="42" rx="2" fill="#fff1b5" stroke="#d7ae69"/>
      {!surfaceOnly&&<><path d="M0-40Q-11-23 0-17Q11-23 0-40" fill="#ffc361" className="art-flame"/>
      <path d="M0-30Q-5-21 0-19Q5-21 0-30" fill="#fff7d1"/>
      <ellipse cx="0" cy="-22" rx="28" ry="36" fill={'url(#'+id+'-glow)'} opacity={d.glowPower/100}/></>}
    </>}
    </g>)}
    {d.decorations.map((x,i)=><g key={i} data-deco={i} transform={'translate('+x.x+' '+x.y+') rotate('+x.rotation+') scale('+x.scale+')'}><>{r.decor?<RealDecorationSymbol staticEffects={surfaceOnly} kind={x.kind} color={x.color} asset={x.realAsset} fallback={<DecorationSymbol staticEffects={surfaceOnly} kind={x.kind} color={x.color}/>}/>:<DecorationSymbol staticEffects={surfaceOnly} kind={x.kind} color={x.color}/>}</></g>)}
    <g pointerEvents="none">{d.strokes.map((s,i)=><polyline key={i} points={(s.points.length===1?[s.points[0],[s.points[0][0]+.01,s.points[0][1]]]:s.points).map(p=>p.join(',')).join(' ')} fill="none" stroke={s.color} strokeWidth={s.width} strokeLinecap="round" strokeLinejoin="round"/>)}</g>
    </g>
  </>;
}
function KrathongArt({design,className='',surfaceOnly=false}:{design:Design;className?:string;surfaceOnly?:boolean}){return <svg className={'krathong-art '+className} viewBox="0 0 320 250" role="img" aria-label="กระทงที่ออกแบบเอง"><ArtLayers design={design} surfaceOnly={surfaceOnly}/></svg>;}

export default memo(KrathongArt);
