'use client';
import {useEffect,useState,useRef} from 'react';
import {FramedPhoto,Badge,flairStyle} from './FlairArt';import {readFlair} from '../flair';import WishIdeas from './WishIdeas';
import AttachmentComposer from './AttachmentComposer';import WishAttachments from './WishAttachments';
import {uploadAttachment} from '../media-client';import type {LocalAttachment,AttachedMedia} from '../media';
import Brand from './Brand';import SouvenirCard from './SouvenirCard';
import KrathongArt from './KrathongArt';
import KrathongEditor from './KrathongEditor';
import Ambience from './Ambience';
import {api,uid} from '../client';
import {defaultDesign,readDesign} from '../design';
import type {EventInfo,Wish} from '../types';
export default function Join({id}:{id:string}){
  const [event,setEvent]=useState<EventInfo|null>(null),[error,setError]=useState(''),[name,setName]=useState(''),[message,setMessage]=useState(''),[design,setDesign]=useState(defaultDesign()),[consent,setConsent]=useState(false),[busy,setBusy]=useState(false),[retry,setRetry]=useState(0),[saved,setSaved]=useState<Wish|null>(null),[loaded,setLoaded]=useState(false);
  const [photo,setPhoto]=useState<LocalAttachment|null>(null),[attachmentWorking,setAttachmentWorking]=useState(false),[progress,setProgress]=useState('');
  const submission=useRef(''),device=useRef(''),uploadAbort=useRef<AbortController|null>(null),uploadCache=useRef(new Map<string,AttachedMedia>()),sending=useRef(false);
  useEffect(()=>()=>{if(photo)URL.revokeObjectURL(photo.url);},[photo]);
  useEffect(()=>()=>{uploadAbort.current?.abort();},[]);
  useEffect(()=>{
    let live=true;api('events/'+id+'?compact=1').then(d=>{if(live)setEvent(d.event);}).catch(e=>{if(live)setError(e.message);}).finally(()=>{if(live)setLoaded(true);});
    try{
      device.current=localStorage.getItem('krathong-device')||uid();localStorage.setItem('krathong-device',device.current);
      submission.current=sessionStorage.getItem('krathong-submit-'+id)||uid();sessionStorage.setItem('krathong-submit-'+id,submission.current);
      const receipt=JSON.parse(sessionStorage.getItem('krathong-receipt-'+id)||'null');
      if(receipt&&typeof receipt.id==='string'&&typeof receipt.name==='string'&&typeof receipt.message==='string')setSaved({...receipt,design:readDesign(receipt.design,receipt.style)});
      const draft=JSON.parse(sessionStorage.getItem('krathong-draft-'+id)||'null');
      if(draft){setDesign(readDesign(draft.design));setName(typeof draft.name==='string'?Array.from(draft.name).slice(0,40).join(''):'');setMessage(typeof draft.message==='string'?Array.from(draft.message).slice(0,140).join(''):'');}
    }catch{if(!device.current)device.current=uid();if(!submission.current)submission.current=uid();}
    return()=>{live=false;};
  },[id]);
  useEffect(()=>{if(!loaded||saved)return;const timer=setTimeout(()=>{try{sessionStorage.setItem('krathong-draft-'+id,JSON.stringify({design,name,message}));}catch{}},400);return()=>clearTimeout(timer);},[id,design,name,message,loaded,saved]);
  useEffect(()=>{if(saved)window.scrollTo(0,0);},[saved]);
  async function send(e:React.FormEvent<HTMLFormElement>){
    e.preventDefault();if(sending.current||attachmentWorking||!consent)return;sending.current=true;setBusy(true);setRetry(0);setError('');setProgress('กำลังส่งกระทง…');const controller=new AbortController();uploadAbort.current=controller;
    try{
      const f=new FormData(e.currentTarget);
      if(photo&&!uploadCache.current.has(photo.id)){
        setProgress('กำลังส่งรูป…');const uploaded=await uploadAttachment(id,submission.current,device.current,'photo',photo,controller.signal,setRetry);uploadCache.current.set(photo.id,uploaded);
      }
      setRetry(0);setProgress('กำลังส่งกระทง…');
      const d=await api('wishes','POST',{id:submission.current,event_id:id,device:device.current,name,message,style:0,design,consent,website:f.get('website'),photoId:photo?.id},{onRetry:setRetry,signal:controller.signal});
      setSaved(d.wish);setPhoto(null);uploadCache.current.clear();try{sessionStorage.setItem('krathong-receipt-'+id,JSON.stringify(d.wish));sessionStorage.removeItem('krathong-submit-'+id);sessionStorage.removeItem('krathong-draft-'+id);}catch{}
    }catch(e){if((e as Error).name!=='AbortError')setError((e as Error).message);}finally{sending.current=false;uploadAbort.current=null;setBusy(false);}
  }
  function another(){setPhoto(null);uploadCache.current.clear();setAttachmentWorking(false);setSaved(null);setConsent(false);setError('');submission.current=uid();try{sessionStorage.removeItem('krathong-receipt-'+id);sessionStorage.setItem('krathong-submit-'+id,submission.current);}catch{}}
  return <main className="creative-page scenic"><Ambience scene={event?.scene}/><header className="site-header"><Brand linked={false}/><span className="guest-page-label">พื้นที่สร้างกระทงของคุณ</span></header><div className="creative-wrap">
    {saved?<section className="panel creative-success success" role="status"><span className="success-check">✓</span><p className="eyebrow">หนึ่งความหวัง · หนึ่งแสงเทียน</p><h1>รับกระทงของคุณแล้ว</h1><KrathongArt design={readDesign(saved.design,saved.style)}/><h2>{saved.name}</h2><p className="saved-wish">“{saved.message}”</p><WishAttachments photo={saved.photo} flair={saved.design?.flair}/><p className="muted">{saved.status==='pending'?'กระทงและคำอวยพรจะขึ้นจอหลังผู้จัดงานอนุมัติ':'กระทงพร้อมลายที่คุณวาดจะทยอยลอยออกมาตามลำดับบนจอของงาน'}</p><p className="guest-screen-note">✧ รอชมกระทงของคุณบนจอใหญ่ของงานได้เลย</p>{event&&<SouvenirCard wish={saved} event={event}/>}<button type="button" className="text-button" onClick={another}>ออกแบบกระทงอีกใบ</button></section>:<>
    <div className="studio-heading"><div><p className="eyebrow">หนึ่งกระทง · หนึ่งความปรารถนาดี</p><h1>แต่งกระทง<em>ในแบบของคุณ</em></h1><p>{event?.title??'ฝากความหวังไว้กับสายน้ำ'}{event?.place?' · '+event.place:''}</p></div><span className="step-badge">ตกแต่ง → เขียนคำอวยพร → ลอยกระทง</span></div>
    {!loaded?<div className="panel" role="status">กำลังเปิดห้องงาน…</div>:!event?<div className="panel error" role="alert">{error}</div>:!event.accepting?<div className="panel notice"><h2>ปิดรับกระทงแล้ว</h2><p>ขอบคุณที่มาร่วมแบ่งปันค่ำคืนดี ๆ ด้วยกัน</p><p className="guest-screen-note">รับชมกระทงและคำอวยพรได้ที่จอใหญ่ของงาน</p></div>:<form onSubmit={send} aria-busy={busy}>
      <KrathongEditor value={design} onChange={setDesign}/>
      <section className="wish-compose panel"><div><p className="eyebrow">ส่งความปรารถนาดี</p><h2>อยากฝากอะไรให้ค่ำคืนนี้?</h2><label className="field-label" htmlFor="name">ชื่อที่แสดงบนกระทง <span>{Array.from(name).length}/40</span></label><input id="name" required value={name} onChange={e=>setName(Array.from(e.target.value).slice(0,40).join(''))} placeholder="ชื่อเล่นหรือชื่อที่อยากให้ทุกคนเห็น" autoComplete="nickname"/>
      <label className="field-label" htmlFor="message">คำอวยพรของคุณ <span>{Array.from(message).length}/140</span></label><textarea id="message" required rows={3} value={message} onChange={e=>setMessage(Array.from(e.target.value).slice(0,140).join(''))} placeholder="ขอให้ปีนี้เต็มไปด้วยเรื่องราวดี ๆ…"/><WishIdeas onChoose={setMessage} disabled={busy}/>
      <AttachmentComposer photo={photo} onPhoto={setPhoto} flair={design.flair} disabled={busy} onWorking={setAttachmentWorking}/><div className="honey" aria-hidden="true"><label>Website<input name="website" tabIndex={-1} autoComplete="off"/></label></div><label className="consent"><input type="checkbox" required checked={consent} onChange={e=>setConsent(e.target.checked)}/><span>ยินยอมให้แสดงชื่อ คำอวยพร ลายที่วาด รวมถึงรูปที่แนบ บนจอและหน้าเว็บของงาน</span></label>{error&&<p className="error" role="alert">{error}</p>}<button className="button gold wide" disabled={busy||attachmentWorking||!consent||!name.trim()||!message.trim()}>{busy?(retry?'กำลังเชื่อมต่ออีกครั้ง ('+retry+'/2)…':progress):attachmentWorking?'กำลังเตรียมไฟล์แนบ…':'ลอยกระทงของฉัน'} <span>✧</span></button><p className="muted small center">โปรดใช้ข้อความ รูป และภาพวาดที่สุภาพ และไม่ใส่ข้อมูลส่วนตัวที่เป็นความลับ</p></div>
      <aside className="final-preview">{photo&&<FramedPhoto className="final-photo" src={photo.url} flair={design.flair} alt="รูปคู่กับคำอวยพรของคุณ"/>}<div className={"sample-wish flair-nameplate nameplate-"+readFlair(design.flair).nameplate} style={flairStyle(design.flair)}><span><Badge flair={design.flair}/>{name||'ชื่อของคุณ'}</span><p>{message||'ขอให้ทุกวันเต็มไปด้วยเรื่องราวดี ๆ'}</p></div><KrathongArt design={design}/><span>กระทงหนึ่งเดียว ที่มีเรื่องราวของคุณ</span></aside></section>
    </form>}</>}
  </div></main>;
}
