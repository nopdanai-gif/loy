'use client';
import {useRef,useState,useId,useEffect,useMemo,memo,type PointerEvent,type KeyboardEvent} from 'react';
import {Move,Pencil,Eraser,Undo2,Redo2,Trash2,Shuffle,Copy,Play,Pause,RotateCcw} from 'lucide-react';
import {ArtLayers,DecorationSymbol} from './KrathongArt';
import KrathongArt from './KrathongArt';
import FlairOptions from './FlairOptions';
import RealisticOptions,{type EditorTab} from './RealisticOptions';
import {realOptions,REAL_BASES,REAL_DECORATIONS,realDecorationFor,type RealDecoration} from '../realism';
import {SHAPES,DECORATIONS,PALETTES,SWATCHES,LIMITS,defaultDesign,sampleDesign,validateDesign,type Design,type Decoration,type DecorationKind} from '../design';
type Point=[number,number];
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));
function distance(p:Point,a:Point,b:Point){const dx=b[0]-a[0],dy=b[1]-a[1],t=clamp(((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy||1),0,1);return Math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy);}
function KrathongEditor({value,onChange}:{value:Design;onChange:(d:Design)=>void}){
  const [favorite,setFavorite]=useState<Design|null>(null);
  useEffect(()=>{try{const saved=validateDesign(JSON.parse(localStorage.getItem('krathong-favorite-v1')||'null'));if(saved)setFavorite(saved);}catch{}},[]);
  const id=useId(),current=useRef(value);current.current=value;
  const [tab,setTab]=useState<EditorTab|'flair'>('shape'),[tool,setTool]=useState<'move'|'draw'|'erase'>('move'),[selected,setSelected]=useState<number|null>(null),[ink,setInk]=useState('#ffcf6a'),[width,setWidth]=useState(4),[preview,setPreview]=useState(false),[note,setNote]=useState('');
  const [,render]=useState(0),history=useRef<Design[]>([]),future=useRef<Design[]>([]);
  const moveFrame=useRef(0),pendingPoints=useRef<Point[]>([]);
  useEffect(()=>()=>{if(moveFrame.current)cancelAnimationFrame(moveFrame.current);},[]);
  const gesture=useRef<{pointer:number;kind:'move'|'draw'|'erase';index:number;dx:number;dy:number}|null>(null);
  function apply(d:Design){current.current=d;onChange(d);}
  function checkpoint(){history.current=[...history.current.slice(-29),structuredClone(current.current)];future.current=[];render(n=>n+1);}
  function commit(d:Design){checkpoint();apply(d);setNote('');}
  function undo(){const d=history.current.pop();if(d){future.current.push(structuredClone(current.current));apply(d);setSelected(null);render(n=>n+1);}}
  function redo(){const d=future.current.pop();if(d){history.current.push(structuredClone(current.current));apply(d);setSelected(null);render(n=>n+1);}}
  function updateDecoration(changes:Partial<Decoration>){if(selected===null)return;commit({...current.current,decorations:current.current.decorations.map((d,i)=>i===selected?{...d,...changes}:d)});}
  function remove(){if(selected===null)return;commit({...current.current,decorations:current.current.decorations.filter((_,i)=>i!==selected)});setSelected(null);}
  function add(kind:DecorationKind,realAsset?:RealDecoration){
    const d=current.current;if(d.decorations.length>=LIMITS.decorations){setNote('ใส่ของประดับได้สูงสุด 24 ชิ้น ลบชิ้นเดิมเพื่อเพิ่มชิ้นใหม่ได้');return;}
    const index=d.decorations.length;
    commit({...d,decorations:[...d.decorations,{kind,x:125+(index%4)*24,y:145+(index%3)*15,scale:.65,rotation:0,color:ink,...(realAsset?{realAsset}:{})}]});
    setSelected(index);setTool('move');setPreview(false);
  }
  function duplicate(){if(selected===null||value.decorations.length>=LIMITS.decorations)return;const d=value.decorations[selected];commit({...value,decorations:[...value.decorations,{...d,x:clamp(d.x+18,15,305),y:clamp(d.y+12,15,235)}]});setSelected(value.decorations.length);}
  function point(e:PointerEvent<SVGSVGElement>):Point{
    const svg=e.currentTarget,matrix=svg.getScreenCTM();if(!matrix)return [160,125];
    const p=svg.createSVGPoint();p.x=e.clientX;p.y=e.clientY;const q=p.matrixTransform(matrix.inverse());
    return [clamp(Math.round(q.x),0,320),clamp(Math.round(q.y),0,250)];
  }
  function erase(p:Point){const d=current.current;const strokes=d.strokes.filter(s=>!s.points.some((a,i)=>distance(p,a,s.points[Math.max(0,i-1)])<10+s.width/2));if(strokes.length!==d.strokes.length)apply({...d,strokes});}
  function down(e:PointerEvent<SVGSVGElement>){
    if(preview||gesture.current||e.button!==0)return;
    e.preventDefault();e.currentTarget.focus();const p=point(e),d=current.current;setNote('');
    if(tool==='move'){
      const target=(e.target as Element).closest('[data-deco]');if(!target){setSelected(null);return;}
      const index=Number(target.getAttribute('data-deco')),item=d.decorations[index];if(!item)return;
      checkpoint();setSelected(index);gesture.current={pointer:e.pointerId,kind:'move',index,dx:p[0]-item.x,dy:p[1]-item.y};
    }else if(tool==='draw'){
      if(d.strokes.length>=LIMITS.strokes||d.strokes.reduce((n,s)=>n+s.points.length,0)>=LIMITS.totalPoints){setNote('พื้นที่วาดเต็มแล้ว ใช้ยางลบหรือล้างภาพวาดเพื่อวาดต่อ');return;}
      checkpoint();setSelected(null);gesture.current={pointer:e.pointerId,kind:'draw',index:d.strokes.length,dx:0,dy:0};
      apply({...d,strokes:[...d.strokes,{color:ink,width,points:[p]}]});
    }else{checkpoint();setSelected(null);gesture.current={pointer:e.pointerId,kind:'erase',index:0,dx:0,dy:0};erase(p);}
    e.currentTarget.setPointerCapture(e.pointerId);
  }
  function applyPoint(p:Point){
    const g=gesture.current;if(!g)return;const d=current.current;
    if(g.kind==='move')apply({...d,decorations:d.decorations.map((x,i)=>i===g.index?{...x,x:clamp(p[0]-g.dx,15,305),y:clamp(p[1]-g.dy,15,235)}:x)});
    else if(g.kind==='erase')erase(p);
    else{
      const stroke=d.strokes[g.index];if(!stroke)return;const prev=stroke.points.at(-1)!;
      if(Math.hypot(p[0]-prev[0],p[1]-prev[1])<2)return;
      if(stroke.points.length>=LIMITS.points){setNote('ยกนิ้วหรือปล่อยเมาส์ แล้วเริ่มเส้นใหม่ได้เลย');return;}
      if(d.strokes.reduce((n,s)=>n+s.points.length,0)>=LIMITS.totalPoints){setNote('พื้นที่วาดเต็มแล้ว ลบบางเส้นเพื่อวาดต่อ');return;}
      apply({...d,strokes:d.strokes.map((s,i)=>i===g.index?{...s,points:[...s.points,p]}:s)});
    }
  }

  function flushMove(){
    if(moveFrame.current){cancelAnimationFrame(moveFrame.current);moveFrame.current=0;}
    const points=pendingPoints.current;pendingPoints.current=[];
    for(const p of points)applyPoint(p);
  }
  function move(e:PointerEvent<SVGSVGElement>){
    if(!gesture.current||gesture.current.pointer!==e.pointerId)return;
    e.preventDefault();const p=point(e);
    pendingPoints.current=[...pendingPoints.current.slice(-7),p];
    if(!moveFrame.current)moveFrame.current=requestAnimationFrame(flushMove);
  }
  function up(e:PointerEvent<SVGSVGElement>){if(gesture.current?.pointer!==e.pointerId)return;if(e.type==='pointerup')pendingPoints.current.push(point(e));flushMove();gesture.current=null;if(e.currentTarget.hasPointerCapture(e.pointerId))e.currentTarget.releasePointerCapture(e.pointerId);}
  function keyboard(e:KeyboardEvent<SVGSVGElement>){
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();e.shiftKey?redo():undo();return;}
    if(selected===null||preview)return;
    if(e.key==='Delete'||e.key==='Backspace'){e.preventDefault();remove();return;}
    const step=e.shiftKey?10:2,d=value.decorations[selected];
    if(!d)return;
    if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();updateDecoration({x:clamp(d.x+(e.key==='ArrowLeft'?-step:e.key==='ArrowRight'?step:0),15,305),y:clamp(d.y+(e.key==='ArrowUp'?-step:e.key==='ArrowDown'?step:0),15,235)});}
  }
  const chosen=selected===null?null:value.decorations[selected],r=realOptions(value.realism);
  const chosenReal=chosen&&r.decor?REAL_DECORATIONS.find(d=>d.id===(chosen.realAsset??realDecorationFor(chosen.kind))):null;
  const shapePreviews=useMemo(()=>SHAPES.map(([shape])=>({...value,shape,realism:{...realOptions(value.realism),shape:false},decorations:[],strokes:[],candles:1})),[value.primary,value.secondary,value.glow,value.glowPower,value.realism]);
  const sectionNumber={shape:1,color:2,decor:3,light:4,flair:5}[tab];
  function saveFavorite(){try{localStorage.setItem('krathong-favorite-v1',JSON.stringify(current.current));setFavorite(structuredClone(current.current));setNote('เก็บแบบนี้ไว้ในเครื่องแล้ว เรียกกลับมาใช้ได้ในหมวด 05 ลูกเล่น');}catch{setNote('อุปกรณ์นี้ยังเก็บแบบไม่ได้ กรุณาลองอีกครั้ง');}}
  function layer(front:boolean){if(selected===null||!chosen)return;const decorations=value.decorations.filter((_,i)=>i!==selected);if(front)decorations.push(chosen);else decorations.unshift(chosen);commit({...value,decorations});setSelected(front?decorations.length-1:0);}

  return <section className="krathong-editor" aria-label="ห้องตกแต่งกระทง">
    <div className="editor-preview">
      <div className="editor-section-title"><span><i/> กระทงของคุณ</span><span>{r.shape?REAL_BASES.find(b=>b.id===r.base)?.name:SHAPES.find(s=>s[0]===value.shape)?.[1]}</span></div>
      <div className={'editor-stage '+(preview?'is-preview':'')+' tool-'+tool+(r.light?' real-preview':'')}>
        <div className="editor-moon" aria-hidden="true"/>
        <svg viewBox="0 0 320 250" tabIndex={0} role="application" aria-label="พื้นที่ตกแต่งกระทง ลากของประดับหรือใช้เครื่องมือวาด ลูกศรขยับชิ้นที่เลือก ปุ่มลบเพื่อลบ" onKeyDown={keyboard} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} onLostPointerCapture={()=>{flushMove();gesture.current=null;}} style={preview?{'--preview-time':(4/value.speed)+'s'} as React.CSSProperties:undefined}>
          <ArtLayers design={value}/>
          {chosen&&!preview&&<g pointerEvents="none" transform={'translate('+chosen.x+' '+chosen.y+') rotate('+chosen.rotation+')'}><rect x={-(chosenReal?.photo?39:30)*chosen.scale} y={-(chosenReal?.photo?39:33)*chosen.scale} width={(chosenReal?.photo?78:60)*chosen.scale} height={(chosenReal?.photo?78:66)*chosen.scale} fill="none" stroke="#fff1bb" strokeWidth="1.2" strokeDasharray="4 3" rx="3"/></g>}
        </svg>
        <div className="stage-caption">{preview?'ตัวอย่างการลอย · '+value.speed.toFixed(1)+'×':tool==='draw'?'วาดด้วยนิ้วหรือเมาส์ได้เลย':tool==='erase'?'แตะเส้นที่ต้องการลบ':'แตะแล้วลากของประดับไปวางได้ตามใจ'}</div>
      </div>
      <div className="editor-toolbar" aria-label="เครื่องมือออกแบบ">
        <div>{([{key:'move',label:'จัดวาง',Icon:Move},{key:'draw',label:'วาด',Icon:Pencil},{key:'erase',label:'ยางลบเส้น',Icon:Eraser}] as const).map(({key,label,Icon})=><button type="button" key={key} className={tool===key&&!preview?'active':''} aria-pressed={tool===key&&!preview} onClick={()=>{setTool(key);setPreview(false);setNote('');}}><Icon size={17}/><span>{label}</span></button>)}</div>
        <div><button type="button" aria-label="ย้อนกลับ" title="ย้อนกลับ" disabled={!history.current.length} onClick={undo}><Undo2 size={18}/></button><button type="button" aria-label="ทำซ้ำ" title="ทำซ้ำ" disabled={!future.current.length} onClick={redo}><Redo2 size={18}/></button><button type="button" aria-label={preview?'หยุดตัวอย่าง':'ดูตัวอย่างการลอย'} title="ดูตัวอย่างการลอย" className={preview?'active':''} onClick={()=>setPreview(!preview)}>{preview?<Pause size={18}/>:<Play size={18}/>}</button></div>
      </div>
      {tool==='draw'&&!preview&&<div className="brush-settings"><label>สีปากกา <input type="color" aria-label="สีปากกา" value={ink} onChange={e=>setInk(e.target.value)}/></label><label>ขนาด <input type="range" aria-label="ขนาดปากกา" min="1" max="14" value={width} onChange={e=>setWidth(+e.target.value)}/><output>{width}</output></label><button type="button" disabled={!value.strokes.length} onClick={()=>commit({...value,strokes:[]})}>ล้างภาพวาด</button></div>}
      <div className="editor-caption"><span>ของประดับ {value.decorations.length}/24 · เส้นวาด {value.strokes.length}/40</span><button type="button" onClick={()=>{commit(defaultDesign());setSelected(null);setPreview(false);}}><RotateCcw size={13}/>เริ่มใหม่</button></div>
      <p className="editor-feedback" role="status">{note||'ลองเพิ่มดอกไม้ วาดคำสั้น ๆ แล้วแต่งแสงให้เป็นสไตล์ของคุณ'}</p>
      {chosen&&!preview&&<div className="selection-panel">
        <div className="editor-section-title"><strong>{chosenReal?.name??DECORATIONS.find(d=>d[0]===chosen.kind)?.[1]}ที่เลือก</strong><div><button type="button" title="ทำสำเนาของประดับ" aria-label="ทำสำเนาของประดับ" disabled={value.decorations.length>=24} onClick={duplicate}><Copy size={16}/></button><button type="button" title="ลบของประดับ" aria-label="ลบของประดับ" onClick={remove}><Trash2 size={16}/></button></div></div>
        <div className="selection-grid"><label>ขนาด <output>{chosen.scale.toFixed(2)}×</output><input type="range" min=".35" max="2" step=".05" value={chosen.scale} onChange={e=>updateDecoration({scale:+e.target.value})}/></label><label>หมุน <output>{chosen.rotation}°</output><input type="range" min="-180" max="180" value={chosen.rotation} onChange={e=>updateDecoration({rotation:+e.target.value})}/></label><label>ซ้าย–ขวา<input type="range" min="15" max="305" value={chosen.x} onChange={e=>updateDecoration({x:+e.target.value})}/></label><label>บน–ล่าง<input type="range" min="15" max="235" value={chosen.y} onChange={e=>updateDecoration({y:+e.target.value})}/></label></div>
        {(!chosenReal||chosenReal.id==='crystal')&&<label className="color-field">สีของประดับ <input type="color" value={chosen.color} onChange={e=>updateDecoration({color:e.target.value})}/></label>}<div className="real-layer-buttons"><button type="button" disabled={selected===0} onClick={()=>layer(false)}>ย้ายไปด้านหลัง</button><button type="button" disabled={selected===value.decorations.length-1} onClick={()=>layer(true)}>ย้ายมาด้านหน้า</button></div>
      </div>}
    </div>
    <div className="editor-options">
      <div className="editor-tabs" aria-label="หมวดตกแต่ง">{[['shape','01','กระทง'],['color','02','สีสัน'],['decor','03','ของประดับ'],['light','04','แสง & ลอย'],['flair','05','ลูกเล่น']].map(([key,n,name])=><button type="button" key={key} aria-pressed={tab===key} className={tab===key?'active':''} onClick={()=>setTab(key as EditorTab|'flair')}><small>{n}</small>{name}</button>)}</div>
      {tab!=='flair'&&<div className="editor-mode-switch" aria-label="รูปแบบของหมวดนี้"><button type="button" aria-pressed={!r[tab]} className={!r[tab]?'selected':''} onClick={()=>commit({...value,realism:{...r,[tab]:false}})}><b>{'0'+sectionNumber}</b><span>แบบปกติ</span></button><button type="button" aria-pressed={r[tab]} className={r[tab]?'selected real-selected':''} onClick={()=>commit({...value,realism:{...r,[tab]:true}})}><b>{sectionNumber+'.1'}</b><span>แบบสมจริง</span><small>ใหม่</small></button></div>}
      <div className="option-content">
        {tab==='flair'&&<FlairOptions value={value.flair} onChange={flair=>commit({...value,flair})} onSave={saveFavorite} onRestore={()=>{if(favorite){commit(structuredClone(favorite));setSelected(null);setNote('เรียกแบบที่เก็บไว้แล้ว');}}} hasSaved={!!favorite}/>}
        {tab!=='flair'&&r[tab]&&<RealisticOptions tab={tab} value={value} onChange={d=>{commit(d);setSelected(null);}} onAdd={add} preview={preview} onPreview={()=>setPreview(!preview)}/>}
        {tab==='shape'&&!r.shape&&<><div className="option-heading"><div><h3>เริ่มจากกระทงที่ชอบ</h3><p>8 รูปทรง พร้อมให้คุณเติมจินตนาการ</p></div><button type="button" className="random-button" onClick={()=>{commit(sampleDesign(Math.floor(Math.random()*120)));setSelected(null);}}><Shuffle size={15}/>สุ่มไอเดีย</button></div><div className="shape-grid">{SHAPES.map(([key,name],i)=><button type="button" key={key} className={value.shape===key?'selected':''} aria-pressed={value.shape===key} onClick={()=>commit({...value,shape:key})}><KrathongArt design={shapePreviews[i]}/><span>{name}</span></button>)}</div><div className="creative-tip"><Pencil size={18}/><p>กระทงทุกแบบวาดเพิ่มได้<br/><span>เลือก “วาด” ใต้ภาพ แล้วเริ่มสร้างลายของคุณ</span></p></div></>}
        {tab==='color'&&!r.color&&<><div className="option-heading"><div><h3>เลือกสีให้ความปรารถนา</h3><p>ใช้ชุดสีสำเร็จ หรือผสมสีเองได้เลย</p></div></div><div className="palette-grid">{PALETTES.map(p=><button type="button" key={p.name} onClick={()=>commit({...value,primary:p.primary,secondary:p.secondary,glow:p.glow})}><span>{[p.primary,p.secondary,p.glow].map(c=><i key={c} style={{background:c}}/>)}</span>{p.name}</button>)}</div><div className="custom-colors">{([['primary','สีหลัก'],['secondary','สีรอง / ใบตอง'],['glow','สีแสงรอบกระทง']] as const).map(([key,label])=><label className="color-field" key={key}>{label}<input type="color" value={value[key]} onChange={e=>commit({...value,[key]:e.target.value})}/></label>)}</div></>}
        {tab==='decor'&&!r.decor&&<><div className="option-heading"><div><h3>เติมชิ้นเล็ก ๆ ที่เป็นคุณ</h3><p>แตะเพื่อเพิ่ม แล้วลาก หมุน หรือปรับขนาด</p></div></div><div className="ink-swatches" aria-label="สีของประดับชิ้นใหม่">{SWATCHES.map(c=><button type="button" key={c} aria-label={'เลือกสี '+c} aria-pressed={ink===c} className={ink===c?'selected':''} style={{background:c}} onClick={()=>setInk(c)}/>)}<input type="color" aria-label="เลือกสีของประดับเอง" value={ink} onChange={e=>setInk(e.target.value)}/></div><div className="decoration-grid">{DECORATIONS.map(([key,name])=><button type="button" key={key} disabled={value.decorations.length>=24} onClick={()=>add(key)}><svg viewBox="-38 -38 76 76" aria-hidden="true"><DecorationSymbol kind={key} color={ink}/></svg><span>{name}</span></button>)}</div><p className="muted small">เพิ่มได้ 24 ชิ้นต่อกระทง · ใช้ปุ่มลูกศรขยับชิ้นที่เลือกได้</p></>}
        {tab==='light'&&!r.light&&<><div className="option-heading"><div><h3>จุดแสงให้ค่ำคืนนี้</h3><p>แสงและจังหวะการลอยในแบบของคุณ</p></div></div><label className="color-field">สีแสง<input type="color" value={value.glow} onChange={e=>commit({...value,glow:e.target.value})}/></label><label className="range-label" htmlFor={id+'glow'}>ประกายรอบกระทง<output>{value.glowPower}%</output></label><input id={id+'glow'} type="range" min="0" max="100" value={value.glowPower} onChange={e=>commit({...value,glowPower:+e.target.value})}/><label className="range-label" htmlFor={id+'candles'}>จำนวนเทียน<output>{value.candles} เล่ม</output></label><input id={id+'candles'} type="range" min="0" max="3" value={value.candles} onChange={e=>commit({...value,candles:+e.target.value})}/><label className="range-label" htmlFor={id+'float'}>ความเร็วของกระทงนี้<output>{value.speed.toFixed(1)}×</output></label><input id={id+'float'} type="range" min=".7" max="1.5" step=".1" value={value.speed} onChange={e=>commit({...value,speed:+e.target.value})}/><div className="range-ends"><span>ลอยเอื่อย ๆ</span><span>ลอยไวขึ้น</span></div><button type="button" className="button outline wide" onClick={()=>setPreview(!preview)}>{preview?<Pause size={16}/>:<Play size={16}/>} {preview?'หยุดดูตัวอย่าง':'ลองดูกระทงลอย'}</button><p className="muted small">ความเร็วบนจอจริงจะปรับตามค่าของผู้จัดงานร่วมด้วย</p></>}
      </div>
    </div>
  </section>;
}

export default memo(KrathongEditor);
