'use client';
import {useId} from 'react';import {Monitor} from 'lucide-react';
import {DEFAULT_LED,QR_POSITIONS,type LedOptions} from '../event-options';
import BangThongSeal from './BangThongSeal';
export default function LedControls({value,onChange}:{value:LedOptions;onChange:(v:LedOptions)=>void}){
  const id=useId();return <section className="led-controls"><div className="led-heading"><div><p className="eyebrow"><Monitor size={14}/> เตรียมจอสำหรับหน้างาน</p><h3>จอ LED และไฮไลต์กระทง</h3></div><BangThongSeal/></div><div className="led-presets"><button type="button" onClick={()=>onChange({...value,fontScale:1.35,qrSize:180,safeMargin:4,showLogo:true,showControls:false})}>จอใหญ่ · อ่านชัด</button><button type="button" onClick={()=>onChange({...DEFAULT_LED})}>ค่ามาตรฐาน</button></div>
    <label className="range-label" htmlFor={id+'font'}>ขนาดชื่อและคำอวยพร<output>{Math.round(value.fontScale*100)}%</output></label><input id={id+'font'} type="range" min=".8" max="1.8" step=".05" value={value.fontScale} onChange={e=>onChange({...value,fontScale:+e.target.value})}/>
    <label className="field-label" htmlFor={id+'qr'}>ตำแหน่ง QR บนจอ</label><select id={id+'qr'} value={value.qrPosition} onChange={e=>onChange({...value,qrPosition:e.target.value as LedOptions['qrPosition']})}>{QR_POSITIONS.map(([v,l])=><option key={v} value={v}>{l}</option>)}</select>
    <label className="range-label" htmlFor={id+'qrsize'}>ขนาด QR<output>{value.qrSize} px</output></label><input id={id+'qrsize'} type="range" min="90" max="240" step="2" value={value.qrSize} onChange={e=>onChange({...value,qrSize:+e.target.value})}/>
    <label className="range-label" htmlFor={id+'safe'}>เว้นขอบจอ<output>{value.safeMargin}%</output></label><input id={id+'safe'} type="range" min="0" max="8" step=".5" value={value.safeMargin} onChange={e=>onChange({...value,safeMargin:+e.target.value})}/>
    <div className="led-toggles">{([['showLogo','แสดงตรา อบต.บางทอง'],['showQR','แสดง QR สำหรับผู้ร่วมงาน'],['highlight','ไฮไลต์กระทงใหม่พร้อมประกายแสง'],['showControls','แสดงปุ่มควบคุมด้านล่างจอ']] as const).map(([key,label])=><label className="toggle-line" key={key}><span>{label}</span><input type="checkbox" checked={value[key]} onChange={e=>onChange({...value,[key]:e.target.checked})}/></label>)}</div><p className="muted small">เมื่อเปิดไฮไลต์ จะแสดงกระทงละ 5 วินาที และเว้นจังหวะปล่อยอย่างน้อย 5.2 วินาที เมื่อซ่อนปุ่ม กด Esc บนจอฉายเพื่อแสดงเครื่องมืออีกครั้ง</p>
  </section>;
}
