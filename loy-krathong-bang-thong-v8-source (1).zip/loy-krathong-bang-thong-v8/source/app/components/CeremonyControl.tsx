'use client';
import {useEffect,useState,useRef} from 'react';import {Sparkles,Timer,Square} from 'lucide-react';
import {api,uid} from '../client';import {ceremonyPhase,type Ceremony} from '../event-options';
export default function CeremonyControl({id,initial}:{id:string;initial?:Ceremony|null}){
  const [ceremony,setCeremony]=useState(initial??null),[seconds,setSeconds]=useState(15),[count,setCount]=useState(6),[busy,setBusy]=useState(false),[error,setError]=useState(''),[now,setNow]=useState(0);
  const offset=useRef(0),latest=useRef(0),requestId=useRef('');
  useEffect(()=>{
    let alive=true;const tick=setInterval(()=>setNow(Date.now()+offset.current),250);
    async function poll(){try{const start=Date.now(),d=await api('events/'+id);if(!alive||d.serverTime<latest.current)return;latest.current=d.serverTime;if(d.serverTime)offset.current=d.serverTime-(start+Date.now())/2;setCeremony(d.event.ceremony??null);}catch{/* Keep last known state; POST reports failures. */}}
    poll();const timer=setInterval(poll,2500);return()=>{alive=false;clearInterval(tick);clearInterval(timer);};
  },[id]);
  const phase=now?ceremonyPhase(ceremony,now):ceremony?.status==='scheduled'?'ready':'idle',active=phase!=='idle';
  async function start(){
    if(busy)return;setBusy(true);setError('');
    try{requestId.current ||= uid();const started=Date.now(),d=await api('events/'+id+'/ceremony','POST',{action:'start',id:requestId.current,seconds,count});latest.current=d.serverTime;offset.current=d.serverTime-(started+Date.now())/2;setNow(Date.now()+offset.current);setCeremony(d.ceremony);requestId.current='';}catch(e){setError((e as Error).message);}finally{setBusy(false);}
  }
  async function cancel(){if(!ceremony||busy)return;setBusy(true);setError('');try{const d=await api('events/'+id+'/ceremony','POST',{action:'cancel',id:ceremony.id});latest.current=d.serverTime;setCeremony(d.ceremony);}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
  return <section className="panel ceremony-control"><div className="ceremony-control-heading"><span className="ceremony-icon"><Sparkles size={26}/></span><div><p className="eyebrow">ช่วงพิเศษของค่ำคืนนี้</p><h2>นับถอยหลัง ลอยไปพร้อมกัน</h2></div></div><p className="muted">นำกระทงที่อนุมัติล่าสุดมาแสดงเป็นชุดพร้อมแสงสี 18 วินาที จอที่เปิดห้องงานเดียวกันจะใช้เวลานับถอยหลังร่วมกัน</p><div className="ceremony-options"><label>นับถอยหลัง<select value={seconds} disabled={active||busy} onChange={e=>setSeconds(+e.target.value)}>{[10,15,30].map(n=><option key={n} value={n}>{n} วินาที</option>)}</select></label><label>กระทงในชุด<select value={count} disabled={active||busy} onChange={e=>setCount(+e.target.value)}>{[3,6,9,12].map(n=><option key={n} value={n}>{n} กระทง</option>)}</select></label></div>
    {active&&ceremony?<div className="ceremony-running" role="status"><Timer size={22}/><div><strong>{phase==='ready'?'กำลังเตรียมจอ…':phase==='countdown'?'นับถอยหลัง '+Math.max(1,Math.ceil((ceremony.releaseAt-now)/1000)):'กำลังลอยกระทงพร้อมกัน'}</strong><p>{ceremony.count} กระทงในช่วงพิเศษ</p></div><button className="button outline" disabled={busy} onClick={cancel}><Square size={14}/>ยกเลิกช่วงพิเศษ</button></div>:<button className="button gold wide" disabled={busy} onClick={start}><Sparkles size={18}/>{busy?'กำลังเตรียมช่วงพิเศษ…':'เริ่มนับถอยหลังบนจอ'}</button>}
    {error&&<p className="error" role="alert">{error}</p>}<p className="muted small">กระทงต้องผ่านการอนุมัติก่อนกดเริ่ม หากมีน้อยกว่าที่เลือกจะแสดงเท่าที่มี เมื่อจบช่วงพิเศษจะกลับสู่คิวปกติ</p>
  </section>;
}
