import {PHOTO_MAX_BYTES,PHOTO_MAX_EDGE,type AttachedMedia,type LocalAttachment,type MediaKind} from './media';

export async function preparePhoto(file:File):Promise<Blob>{
 if(file.size>12*1024*1024)throw new Error('เลือกรูปขนาดไม่เกิน 12 MB ครับ');
 if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw new Error('รองรับรูป JPG, PNG และ WebP');
 const url=URL.createObjectURL(file);
 try{
  const image=new Image();image.src=url;await image.decode();if(!image.naturalWidth||!image.naturalHeight)throw new Error('อ่านรูปนี้ไม่ได้');
  const ratio=Math.min(1,PHOTO_MAX_EDGE/Math.max(image.naturalWidth,image.naturalHeight));
  const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*ratio));canvas.height=Math.max(1,Math.round(image.naturalHeight*ratio));const ctx=canvas.getContext('2d');if(!ctx)throw new Error('อุปกรณ์นี้เตรียมรูปไม่ได้');
  ctx.fillStyle='#0b1e30';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);
  for(const quality of [.92,.86,.78]){const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('เตรียมรูปไม่สำเร็จ')),'image/jpeg',quality));if(blob.size<=PHOTO_MAX_BYTES){canvas.width=0;canvas.height=0;return blob;}}
  throw new Error('รูปนี้มีรายละเอียดมากเกินไป ลองเลือกรูปอื่น');
 }catch(e){throw new Error(e instanceof Error?e.message:'อ่านรูปไม่สำเร็จ กรุณาเลือกใหม่');}finally{URL.revokeObjectURL(url);}
}

export async function uploadAttachment(eventId:string,wishId:string,device:string,kind:MediaKind,attachment:LocalAttachment,signal:AbortSignal,onRetry:(n:number)=>void):Promise<AttachedMedia>{
 for(let attempt=0;;attempt++){
  const controller=new AbortController(),abort=()=>controller.abort();signal.addEventListener('abort',abort,{once:true});if(signal.aborted)abort();const timer=setTimeout(abort,30000);
  let retry=false,error=new Error('ส่งไฟล์ไม่สำเร็จ กรุณาลองอีกครั้ง');
  try{const r=await fetch('/api/events/'+eventId+'/media/'+kind,{method:'POST',headers:{'Content-Type':attachment.blob.type,'X-Wish-ID':wishId,'X-Device-ID':device,'X-Upload-ID':attachment.id,'X-Media-Consent':'yes'},body:attachment.blob,signal:controller.signal});const d=await r.json() as {media:AttachedMedia;error?:string};if(r.ok)return d.media;error=new Error(d.error??error.message);retry=[408,500,502,503,504].includes(r.status);}
  catch{retry=true;error=new Error('ส่งไฟล์ไม่สำเร็จ กรุณาตรวจอินเทอร์เน็ตแล้วลองอีกครั้ง');}
  finally{clearTimeout(timer);signal.removeEventListener('abort',abort);}
  if(signal.aborted)throw new DOMException('Aborted','AbortError');if(!retry||attempt>=2)throw error;onRetry(attempt+1);
  await new Promise<void>((resolve,reject)=>{const cancel=()=>{clearTimeout(timer);reject(new DOMException('Aborted','AbortError'));};const timer=setTimeout(()=>{signal.removeEventListener('abort',cancel);resolve();},700*2**attempt);signal.addEventListener('abort',cancel,{once:true});if(signal.aborted)cancel();});
 }
}
