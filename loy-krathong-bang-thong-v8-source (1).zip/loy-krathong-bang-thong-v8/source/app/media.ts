export const PHOTO_MAX_BYTES=800*1024;
export const PHOTO_MAX_EDGE=1600;
export type MediaKind='photo';
export type AttachedMedia={id:string;url:string};
export type LocalAttachment={id:string;blob:Blob;url:string};
export class MediaProblem extends Error{constructor(public status:number,message:string){super(message);}}
export function mediaUrl(id:string){return '/api/media/'+id;}
export function validMediaId(id:unknown):id is string{return typeof id==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(id);}
/** Accept only JPEG output from the photo preparation step, with bounded dimensions. */
export function validatePhoto(bytes:Uint8Array){
 const bad=()=>{throw new MediaProblem(400,'รูปไม่ถูกต้อง กรุณาเลือกรูป JPG, PNG หรือ WebP ใหม่');};
 if(bytes.length<16||bytes.length>PHOTO_MAX_BYTES||bytes[0]!==255||bytes[1]!==216||bytes.at(-2)!==255||bytes.at(-1)!==217)bad();
 let at=2,width=0,height=0,scan=false;
 while(at+3<bytes.length){
  if(bytes[at++]!==255)bad();while(bytes[at]===255)at++;const marker=bytes[at++];
  if(marker===0xd9)break;
  if(at+1>=bytes.length)bad();const length=bytes[at]*256+bytes[at+1];if(length<2||at+length>bytes.length-2)bad();
  if(marker===0xda){if(length<6||at+length>=bytes.length-2)bad();scan=true;break;}
  if([0xc0,0xc1,0xc2].includes(marker)){if(length<8||bytes[at+2]!==8)bad();height=bytes[at+3]*256+bytes[at+4];width=bytes[at+5]*256+bytes[at+6];}
  at+=length;
 }
 if(!scan||!width||!height||width>PHOTO_MAX_EDGE||height>PHOTO_MAX_EDGE)bad();
 return {width,height,mime:'image/jpeg'};
}
