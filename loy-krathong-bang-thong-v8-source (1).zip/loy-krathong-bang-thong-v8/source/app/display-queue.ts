import type {Wish} from './types';
export const QUEUE_LIMIT=36;
export const FEED_BATCH=12;
export const FEED_BYTES=192*1024;
export type Checkpoint={v:2;cursor:number;shown:string[];special:[string,number][]};
/** Rewind to the earliest unfinished feed sequence; the DB retains all art. */
export function makeCheckpoint(cursor:number,pending:Pick<Wish,'seq'>[],shown:Iterable<string>,special:Iterable<[string,number]>=[]):Checkpoint{
 let resume=cursor;
 for(const wish of pending){if(Number.isSafeInteger(wish.seq)&&wish.seq!>0)resume=Math.min(resume,wish.seq!-1);else resume=0;}
 return {v:2,cursor:Math.max(0,resume),shown:[...shown].slice(-500),special:[...special]};
}
export function readCheckpoint(raw:string|null):Checkpoint|null{
 try{
  const s=JSON.parse(raw??'null');if(!s||!Number.isSafeInteger(s.cursor)||s.cursor<0)return null;
  if(s.v!==2&&!Array.isArray(s.queue))return null;
  const shown=Array.isArray(s.shown)?s.shown.filter((id:unknown)=>typeof id==='string'&&id.length<=100).slice(-500):[];
  const special=Array.isArray(s.special)?s.special.filter((v:unknown)=>Array.isArray(v)&&v.length===2&&typeof v[0]==='string'&&v[0].length<=100&&Number.isSafeInteger(v[1])&&v[1]>0):[];
  return makeCheckpoint(s.cursor,s.v===2?[]:s.queue,shown,special);
 }catch{return null;}
}
export function appendFeed(queue:Wish[],incoming:Wish[],active:Wish[],shown:Set<string>,removed:Set<string>){
 const result=queue.filter(w=>!removed.has(w.id)),known=new Set([...result,...active].map(w=>w.id));
 for(const wish of incoming){
  if(result.length>=QUEUE_LIMIT)break;
  if(!known.has(wish.id)&&!shown.has(wish.id)&&!removed.has(wish.id)){result.push(wish);known.add(wish.id);}
 }
 return result;
}
export function rememberShown(shown:Set<string>,ids:Iterable<string>){for(const id of ids)shown.add(id);while(shown.size>500)shown.delete(shown.values().next().value!);}
// Density bounds the number of simultaneous journeys, never the quality of their art.
// Waiting entries stay in the event database and are released in order.
export const MAX_VISIBLE_BOATS=18;
