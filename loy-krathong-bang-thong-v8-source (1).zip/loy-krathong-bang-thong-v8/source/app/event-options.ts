export const QR_POSITIONS=[['top-right','บนขวา'],['top-left','บนซ้าย'],['bottom-right','ล่างขวา'],['bottom-left','ล่างซ้าย']] as const;
export type LedOptions={fontScale:number;qrPosition:typeof QR_POSITIONS[number][0];qrSize:number;showQR:boolean;showLogo:boolean;showControls:boolean;highlight:boolean;safeMargin:number};
export const DEFAULT_LED:LedOptions={fontScale:1,qrPosition:'top-right',qrSize:132,showQR:true,showLogo:true,showControls:true,highlight:true,safeMargin:2};
const obj=(x:unknown):x is Record<string,unknown>=>!!x&&typeof x==='object'&&!Array.isArray(x);
const num=(x:unknown,min:number,max:number):x is number=>typeof x==='number'&&Number.isFinite(x)&&x>=min&&x<=max;
export function validateLed(x:unknown):LedOptions|null{
  if(!obj(x)||!num(x.fontScale,.8,1.8)||!num(x.qrSize,90,240)||!num(x.safeMargin,0,8)||!QR_POSITIONS.some(p=>p[0]===x.qrPosition)||!['showQR','showLogo','showControls','highlight'].every(k=>typeof x[k]==='boolean'))return null;
  return {fontScale:x.fontScale,qrPosition:x.qrPosition as LedOptions['qrPosition'],qrSize:x.qrSize,safeMargin:x.safeMargin,showQR:x.showQR as boolean,showLogo:x.showLogo as boolean,showControls:x.showControls as boolean,highlight:x.highlight as boolean};
}
export function readLed(x:unknown):LedOptions{try{return validateLed(typeof x==='string'?JSON.parse(x):x)??{...DEFAULT_LED};}catch{return {...DEFAULT_LED};}}
export type Ceremony={id:string;startsAt:number;releaseAt:number;endsAt:number;count:number;status:'scheduled'|'cancelled'};
export type StoredCeremony=Ceremony&{wishIds:string[]};
export function readCeremony(x:unknown):StoredCeremony|null{
  try{const c=typeof x==='string'?JSON.parse(x):x;
    if(!obj(c)||typeof c.id!=='string'||!num(c.startsAt,0,Number.MAX_SAFE_INTEGER)||!num(c.releaseAt,c.startsAt,Number.MAX_SAFE_INTEGER)||!num(c.endsAt,c.releaseAt,Number.MAX_SAFE_INTEGER)||!num(c.count,1,12)||!Number.isInteger(c.count)||!['scheduled','cancelled'].includes(String(c.status))||!Array.isArray(c.wishIds)||c.wishIds.length!==c.count||new Set(c.wishIds).size!==c.wishIds.length||!c.wishIds.every(w=>typeof w==='string'&&w.length<=64))return null;
    return {id:c.id,startsAt:c.startsAt,releaseAt:c.releaseAt,endsAt:c.endsAt,count:c.count,status:c.status as Ceremony['status'],wishIds:c.wishIds};
  }catch{return null;}
}
export function ceremonyPhase(c:Ceremony|null|undefined,now:number):'idle'|'ready'|'countdown'|'fleet'{if(!c||c.status==='cancelled'||now>=c.endsAt)return 'idle';return now<c.startsAt?'ready':now<c.releaseAt?'countdown':'fleet';}
export function publicCeremony(c:StoredCeremony|null):Ceremony|null{if(!c)return null;const {wishIds,...value}=c;return value;}
export const STATUS_LABELS:Record<string,string>={all:'ทั้งหมด',pending:'รออนุมัติ',approved:'อนุมัติแล้ว',hidden:'ซ่อนแล้ว'};
export type ArchiveRow={photo?:import('./media').AttachedMedia;position:number;id:string;name:string;message:string;shape:string;style:number;status:string;created_at:number};
