import type {LedOptions,Ceremony} from './event-options';
import type {Design,Scene} from './design';
import type {AttachedMedia} from './media';
export type EventInfo = { id:string; title:string; place:string; accepting:number; moderation:number; paused:number; interval_ms:number; created_at:number; float_ms?:number; scene?:Scene; count?:number; led?:LedOptions; ceremony?:Ceremony|null; owner?:string };
export type Wish = { id:string; name:string; message:string; style:number; status?:string; created_at?:number; seq?:number; design?:Design; photo?:AttachedMedia };
