import {REAL_BASES,REAL_DECORATIONS,baseAsset,decorationAsset} from './realism';
const allowedAssets=new Set<string>([...REAL_BASES.map(b=>baseAsset(b.id)),...REAL_DECORATIONS.filter(d=>d.photo).map(d=>decorationAsset(d.id))]);
export function isRealisticAsset(path:string){return allowedAssets.has(path);}
function asDataUrl(blob:Blob):Promise<string>{return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result as string);reader.onerror=()=>reject(new Error('อ่านภาพกระทงไม่สำเร็จ กรุณาลองอีกครั้ง'));reader.readAsDataURL(blob);});}
const assetData=new Map<string,Promise<string>>();
/** Self-contained SVG images work inside a canvas-backed souvenir on mobile. */
export async function inlineRealisticImages(svg:SVGSVGElement){
 const cache=assetData;
 const images=Array.from(svg.querySelectorAll('image'));
 await Promise.all(images.map(async image=>{
  const path=image.getAttribute('href')??'';
  if(!isRealisticAsset(path))throw new Error('ไม่พบภาพกระทงที่รองรับ');
  if(!cache.has(path))cache.set(path,(async()=>{
   const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
   try{
    const response=await fetch(path,{signal:controller.signal,credentials:'same-origin'});
    if(!response.ok)throw new Error('โหลดภาพกระทงไม่สำเร็จ กรุณาลองอีกครั้ง');
    const blob=await response.blob();if(blob.size>1024*1024||!blob.type.startsWith('image/'))throw new Error('รูปแบบภาพกระทงไม่ถูกต้อง');
    return await asDataUrl(blob);
   }finally{clearTimeout(timer);}
  })().catch(error=>{cache.delete(path);throw error;}));
  image.setAttribute('href',await cache.get(path)!);
  image.removeAttribute('xlink:href');
 }));
}
