export class GateBusyError extends Error{}
/** Bounds parsed request bodies held while D1 is busy. Waiting requests keep their streams unread. */
export class WorkGate{
 private active=0;
 private queue:{grant:()=>void;cancel:()=>void}[]=[];
 constructor(private concurrency=24,private waitingLimit=256,private waitMs=10000){}
 async run<T>(work:()=>Promise<T>,signal?:AbortSignal):Promise<T>{
  if(signal?.aborted)throw new GateBusyError('Request cancelled');
  if(this.active<this.concurrency)this.active++;
  else await new Promise<void>((resolve,reject)=>{
   if(this.queue.length>=this.waitingLimit){reject(new GateBusyError('Request queue is full'));return;}
   let settled=false;
   const clean=()=>{clearTimeout(timer);signal?.removeEventListener('abort',entry.cancel);};
   const entry={grant:()=>{if(settled)return;settled=true;clean();this.active++;resolve();},cancel:()=>{if(settled)return;settled=true;clean();const i=this.queue.indexOf(entry);if(i>=0)this.queue.splice(i,1);reject(new GateBusyError('Request queue timed out'));}};
   const timer=setTimeout(entry.cancel,this.waitMs);this.queue.push(entry);signal?.addEventListener('abort',entry.cancel,{once:true});if(signal?.aborted)entry.cancel();
  });
  try{if(signal?.aborted)throw new GateBusyError('Request cancelled');return await work();}
  finally{this.active--;this.queue.shift()?.grant();}
 }
 get size(){return {active:this.active,waiting:this.queue.length};}
}
