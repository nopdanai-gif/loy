import type {EventInfo,Wish} from './types';
import {badgeSymbol} from './flair';
import {drawPhotoFrame,drawNameplate} from './flair-canvas';
function image(src:string):Promise<HTMLImageElement>{return new Promise((resolve,reject)=>{const im=new Image(),timer=setTimeout(()=>reject(new Error('โหลดภาพไม่สำเร็จ กรุณาลองอีกครั้ง')),15000);im.onload=()=>{clearTimeout(timer);resolve(im);};im.onerror=()=>{clearTimeout(timer);reject(new Error('โหลดภาพไม่สำเร็จ กรุณาตรวจอินเทอร์เน็ตแล้วลองอีกครั้ง'));};im.src=src;});}
function cover(ctx:CanvasRenderingContext2D,im:HTMLImageElement,w:number,h:number){const scale=Math.max(w/im.naturalWidth,h/im.naturalHeight);ctx.drawImage(im,(w-im.naturalWidth*scale)*.57,(h-im.naturalHeight*scale)/2,im.naturalWidth*scale,im.naturalHeight*scale);}
function parts(text:string){return typeof Intl.Segmenter==='function'?Array.from(new Intl.Segmenter('th',{granularity:'grapheme'}).segment(text),s=>s.segment):Array.from(text);}
function lines(ctx:CanvasRenderingContext2D,text:string,width:number){
  const clean=text.replace(/\s+/g,' ').trim(),result:string[]=[];let line='';
  const words=typeof Intl.Segmenter==='function'?Array.from(new Intl.Segmenter('th',{granularity:'word'}).segment(clean),s=>s.segment):clean.split(/(\s+)/);
  for(const word of words){
    if(ctx.measureText(line+word).width<=width){line+=word;continue;}
    if(ctx.measureText(word.trimStart()).width<=width){if(line.trim())result.push(line.trim());line=word.trimStart();continue;}
    for(const ch of parts(word)){if(line&&ctx.measureText(line+ch).width>width){result.push(line.trim());line=ch;}else line+=ch;}
  }
  if(line.trim())result.push(line.trim());return result;
}
function fit(ctx:CanvasRenderingContext2D,text:string,width:number,size:number,min:number,maxLines:number,weight=500){let rows:string[]=[];for(;size>=min;size--){ctx.font=weight+' '+size+'px "Noto Sans Thai", Tahoma, sans-serif';rows=lines(ctx,text,width);if(rows.length<=maxLines)break;}return {rows,size:Math.max(size,min)};}
export async function createSouvenir(svg:string,wish:Wish,event:Pick<EventInfo,'title'|'place'>):Promise<Blob>{
  await Promise.race([document.fonts.ready,new Promise(r=>setTimeout(r,3000))]);
  const artUrl=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}));
  try{
    const [river,seal,art,photo]=await Promise.all([image('/assets/river.png'),image('/assets/bang-thong-seal.png'),image(artUrl),wish.photo?image(wish.photo.url):Promise.resolve(null)]);
    const canvas=document.createElement('canvas');canvas.width=1080;canvas.height=1440;const ctx=canvas.getContext('2d');if(!ctx)throw new Error('อุปกรณ์นี้ไม่รองรับการสร้างภาพ');
    ctx.fillStyle='#09182c';ctx.fillRect(0,0,1080,1440);ctx.globalAlpha=.5;cover(ctx,river,1080,1440);ctx.globalAlpha=1;
    const overlay=ctx.createLinearGradient(0,0,0,1440);overlay.addColorStop(0,'#06172bd9');overlay.addColorStop(.48,'#06172b66');overlay.addColorStop(1,'#06172bf2');ctx.fillStyle=overlay;ctx.fillRect(0,0,1080,1440);
    const glow=ctx.createRadialGradient(540,770,20,540,770,440);glow.addColorStop(0,'#efbc6f30');glow.addColorStop(.7,'#c683c412');glow.addColorStop(1,'#10223800');ctx.fillStyle=glow;ctx.fillRect(60,380,960,640);
    ctx.strokeStyle='#eac788';ctx.lineWidth=2;ctx.strokeRect(32,32,1016,1376);ctx.strokeStyle='#eac78855';ctx.lineWidth=1;ctx.strokeRect(46,46,988,1348);
    for(const [x,y] of [[64,64],[1016,64],[64,1376],[1016,1376]]){ctx.save();ctx.translate(x,y);ctx.rotate(Math.PI/4);ctx.fillStyle='#eac788';ctx.fillRect(-5,-5,10,10);ctx.restore();}
    ctx.save();ctx.beginPath();ctx.arc(540,139,76,0,Math.PI*2);ctx.clip();ctx.drawImage(seal,seal.naturalWidth*.155,seal.naturalHeight*.155,seal.naturalWidth*.69,seal.naturalHeight*.69,464,63,152,152);ctx.restore();
    ctx.textAlign='center';ctx.textBaseline='alphabetic';
    const title=fit(ctx,event.title,880,44,20,2,600);ctx.fillStyle='#ffe2a7';title.rows.forEach((t,i)=>ctx.fillText(t,540,268+i*52));
    const place=fit(ctx,event.place,880,25,16,2,400);ctx.fillStyle='#cbd6e3';place.rows.forEach((t,i)=>ctx.fillText(t,540,350+i*30));
    ctx.strokeStyle='#edc38255';ctx.beginPath();ctx.moveTo(210,400);ctx.lineTo(430,400);ctx.moveTo(650,400);ctx.lineTo(870,400);ctx.stroke();ctx.fillStyle='#edc382';ctx.font='26px Georgia';ctx.fillText('✧',540,410);
    ctx.save();ctx.shadowBlur=24;ctx.shadowColor='#edbc7455';if(photo){ctx.drawImage(art,100,425,670,523.4);}else ctx.drawImage(art,180,417,720,562.5);ctx.restore();
    if(photo)drawPhotoFrame(ctx,photo,wish.design?.flair,775,650,225,250);
    const badge=wish.design?.flair?badgeSymbol(wish.design.flair.badge):'';
    const name=fit(ctx,(badge?badge+'  ':'')+wish.name,840,48,30,2,600);
    drawNameplate(ctx,wish.design?.flair,100,967,880,name.rows.length>1?128:78);
    ctx.fillStyle='#ffe4ad';name.rows.forEach((t,i)=>ctx.fillText(t,540,1018+i*55));
    const message=fit(ctx,'“'+wish.message+'”',860,33,24,4,400);ctx.fillStyle='#f1eee8';message.rows.forEach((t,i)=>ctx.fillText(t,540,1130+i*45));
    ctx.strokeStyle='#edc38255';ctx.beginPath();ctx.moveTo(200,1328);ctx.lineTo(880,1328);ctx.stroke();ctx.fillStyle='#d4bb90';ctx.font='23px "Noto Sans Thai", Tahoma, sans-serif';ctx.fillText('หนึ่งกระทง หนึ่งความปรารถนาดี • อบต.บางทอง',540,1366);
    return await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('บันทึกภาพไม่สำเร็จ กรุณาลองอีกครั้ง')),'image/png'));
  }finally{URL.revokeObjectURL(artUrl);}
}
