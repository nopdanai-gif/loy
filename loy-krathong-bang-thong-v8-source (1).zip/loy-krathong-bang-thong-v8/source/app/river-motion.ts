/** One compositor animation per boat. No React state updates in the frame loop. */
export function riverFrames(width:number,boatWidth:number,lane:number,seed=0):Keyframe[]{
 const distance=Math.max(1,width)+Math.max(1,boatWidth)+60;
 const phase=(Math.abs(seed)%101)/101*Math.PI*2,amplitude=12-lane*1.4;
 const wave=(p:number)=>Math.sin(p*Math.PI*2+phase)*amplitude+Math.sin(p*Math.PI*4+phase)*3;
 const origin=wave(0);
 return Array.from({length:41},(_,i)=>{
  const p=i/40;
  return {offset:p,transform:`translate3d(${-distance*p}px,${(wave(p)-origin).toFixed(3)}px,0)`,opacity:i===0||i===40?0:1};
 });
}
export function motionSeed(value:string){let seed=0;for(const char of value)seed=(seed*31+char.charCodeAt(0))>>>0;return seed;}

/** Resize reprojects the same journey; pause/resume retains its current time. */
export function animateRiverBoat(element:HTMLElement,options:{duration:number;lane:number;seed:number;paused:boolean}){
 let animation:Animation|undefined,paused=options.paused,finished=false,width=0,boatWidth=0;
 const redraw=()=>{
  if(finished)return;
  const nextWidth=element.parentElement?.clientWidth??innerWidth,nextBoat=element.offsetWidth;
  if(animation&&nextWidth===width&&nextBoat===boatWidth)return;
  width=nextWidth;boatWidth=nextBoat;
  const time=typeof animation?.currentTime==='number'?animation.currentTime:0;
  animation?.cancel();
  if(typeof element.animate!=='function')return; // CSS maintains the same journey on older browsers.
  animation=element.animate(riverFrames(width,boatWidth,options.lane,options.seed),{duration:options.duration,easing:'linear',fill:'both'});
  animation.currentTime=time;
  element.classList.add('motion-driven');
  if(paused)animation.pause();
 };
 redraw();
 const observer=typeof ResizeObserver!=='undefined'?new ResizeObserver(redraw):undefined;
 if(element.parentElement)observer?.observe(element.parentElement);observer?.observe(element);
 return {
  setPaused(value:boolean){paused=value;if(animation){if(value)animation.pause();else animation.play();}},
  destroy(){finished=true;observer?.disconnect();animation?.cancel();element.classList.remove('motion-driven');},
 };
}
