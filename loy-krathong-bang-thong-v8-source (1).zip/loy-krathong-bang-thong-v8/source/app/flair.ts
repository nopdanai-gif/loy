export const FRAMES=[['gold','ขอบทอง'],['pearl','ไข่มุก'],['bloom','สวนดอกไม้'],['moon','จันทร์เสี้ยว'],['aurora','แสงออโรรา'],['polaroid','ภาพโพลารอยด์']] as const;
export const NAMEPLATES=[['gold','ทองคลาสสิก'],['glass','กระจกสายน้ำ'],['petal','กลีบดอกไม้'],['neon','นีออน'],['ribbon','ริบบิ้น']] as const;
export const BADGES=[['none','ไม่ใส่',''],['heart','หัวใจ','♥'],['star','ดาว','★'],['flower','ดอกไม้','❀'],['moon','จันทร์','☾'],['sparkle','ประกาย','✧'],['sun','ตะวัน','☀'],['leaf','ใบไม้','❧'],['crown','มงกุฎ','♛'],['infinity','นิรันดร์','∞'],['diamond','เพชร','◇'],['snow','ผลึก','❋']] as const;
export const ENTRANCES=[['none','เรียบง่าย','—'],['sparkles','ประกายทอง','✦'],['petals','กลีบดอกไม้','❀'],['stars','ดาวพราวฟ้า','★'],['hearts','หัวใจลอย','♥'],['bubbles','ฟองสายน้ำ','○'],['lanterns','โคมอธิษฐาน','▱']] as const;
export const AURAS=[['none','ไม่ใส่'],['halo','วงแสง'],['orbit','วงโคจร'],['heart','แสงหัวใจ'],['moon','จันทร์โอบกระทง']] as const;
export type Flair={frame:typeof FRAMES[number][0];nameplate:typeof NAMEPLATES[number][0];badge:typeof BADGES[number][0];entrance:typeof ENTRANCES[number][0];aura:typeof AURAS[number][0];color:string};
export const DEFAULT_FLAIR:Flair={frame:'gold',nameplate:'gold',badge:'none',entrance:'sparkles',aura:'none',color:'#edc382'};
export const FLAIR_PRESETS:{id:string;name:string;description:string;value:Flair}[]=[
 {id:'gold',name:'ทองประกายดาว',description:'อบอุ่น · หรูหรา',value:{frame:'gold',nameplate:'gold',badge:'star',entrance:'sparkles',aura:'halo',color:'#edc382'}},
 {id:'garden',name:'สวนบุปผา',description:'อ่อนหวาน · ดอกไม้',value:{frame:'bloom',nameplate:'petal',badge:'flower',entrance:'petals',aura:'halo',color:'#f5a2c7'}},
 {id:'love',name:'รักละมุน',description:'หัวใจ · ความปรารถนาดี',value:{frame:'pearl',nameplate:'ribbon',badge:'heart',entrance:'hearts',aura:'heart',color:'#ff9bb4'}},
 {id:'aurora',name:'แสงออโรรา',description:'สดใส · สีสัน',value:{frame:'aurora',nameplate:'neon',badge:'diamond',entrance:'stars',aura:'orbit',color:'#7de8d5'}},
 {id:'moon',name:'จันทร์ริมธาร',description:'ละมุน · ริมสายน้ำ',value:{frame:'moon',nameplate:'glass',badge:'moon',entrance:'bubbles',aura:'moon',color:'#a6c9ff'}},
 {id:'memory',name:'เก็บวันดี ๆ',description:'อบอุ่น · ความทรงจำ',value:{frame:'polaroid',nameplate:'ribbon',badge:'sun',entrance:'lanterns',aura:'halo',color:'#ffca8b'}},
];
export function validateFlair(value:unknown):Flair|null{
 if(!value||typeof value!=='object'||Array.isArray(value))return null;const f=value as Record<string,unknown>;
 if(!FRAMES.some(v=>v[0]===f.frame)||!NAMEPLATES.some(v=>v[0]===f.nameplate)||!BADGES.some(v=>v[0]===f.badge)||!ENTRANCES.some(v=>v[0]===f.entrance)||!AURAS.some(v=>v[0]===f.aura)||typeof f.color!=='string'||!/^#[a-fA-F0-9]{6}$/.test(f.color))return null;
 return {frame:f.frame,nameplate:f.nameplate,badge:f.badge,entrance:f.entrance,aura:f.aura,color:f.color} as Flair;
}
export function readFlair(value?:Flair):Flair{return value??DEFAULT_FLAIR;}
export function badgeSymbol(value:Flair['badge']){return BADGES.find(v=>v[0]===value)?.[2]??'';}
export function randomFlair(random= Math.random):Flair{
 const pick=<T extends readonly (readonly unknown[])[]>(list:T)=>list[Math.min(list.length-1,Math.max(0,Math.floor(random()*list.length)))][0];
 return {frame:pick(FRAMES),nameplate:pick(NAMEPLATES),badge:pick(BADGES),entrance:pick(ENTRANCES),aura:pick(AURAS),color:FLAIR_PRESETS[Math.min(5,Math.max(0,Math.floor(random()*6)))].value.color} as Flair;
}
export const WISH_IDEAS=[
 {id:'family',label:'ครอบครัว',items:['ขอให้ครอบครัวมีความสุข สุขภาพแข็งแรง และได้ยิ้มให้กันทุกวัน','ขอให้คนที่รักอยู่ด้วยกันอย่างอบอุ่นและปลอดภัย','ขอให้บ้านของเราเต็มไปด้วยเสียงหัวเราะและเรื่องราวดี ๆ','ขอให้พ่อแม่สุขภาพแข็งแรง อยู่เป็นรอยยิ้มของลูกไปนาน ๆ','ขอให้ทุกคนในครอบครัวผ่านเรื่องยากไปด้วยกัน','ฝากความรักและคำอวยพรไปถึงคนที่อยู่ไกลบ้าน']},
 {id:'love',label:'ความรัก',items:['ขอให้พบความรักที่อบอุ่น และเป็นตัวเองได้อย่างสบายใจ','ขอให้เราได้ดูพระจันทร์และยิ้มให้กันแบบนี้ไปนาน ๆ','ขอให้ความสัมพันธ์เต็มไปด้วยความเข้าใจและความอ่อนโยน','ปล่อยเรื่องที่ทำให้เสียใจ แล้วเปิดใจรับวันดี ๆ','ขอให้ได้ใช้เวลากับคนที่รัก และดูแลกันในทุกวัน','ขอให้รักตัวเองมากขึ้น และพบคนที่เห็นคุณค่าของเรา']},
 {id:'dream',label:'งานและเรียน',items:['ขอให้ความตั้งใจทุกอย่างค่อย ๆ พาเราไปถึงฝัน','ขอให้การเรียนและการงานราบรื่น ได้พบโอกาสดี ๆ','ขอให้มีแรงใจเริ่มต้นสิ่งใหม่ และกล้าลงมือทำในสิ่งที่รัก','ขอให้ความพยายามวันนี้ผลิบานเป็นความสำเร็จในวันข้างหน้า','ขอให้ได้ทำงานที่มีความสุข และพบผู้คนที่เกื้อกูลกัน','ขอให้ทุกก้าวของการเรียนรู้เต็มไปด้วยเรื่องน่าค้นหา']},
 {id:'hope',label:'กำลังใจ',items:['ปล่อยความทุกข์ไปกับสายน้ำ แล้วเริ่มวันใหม่ด้วยหัวใจที่เบาขึ้น','ขอให้ทุกวันมีเรื่องเล็ก ๆ ที่ทำให้ยิ้มได้','ขอให้ใจสงบ สุขภาพแข็งแรง และได้พักเมื่อเหนื่อย','ขอให้แสงเทียนคืนนี้พาความหวังกลับมาอีกครั้ง','ขอให้ผ่านวันที่ยากไปได้ และอ่อนโยนกับตัวเองเสมอ','ขอให้ชุมชนของเราอบอุ่น เต็มไปด้วยน้ำใจและความสุข']},
] as const;
