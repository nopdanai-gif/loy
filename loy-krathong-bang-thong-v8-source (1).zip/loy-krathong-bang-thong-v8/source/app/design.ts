import {validateFlair,type Flair} from './flair';
import {REAL_DECORATIONS,validateRealism,type Realism,type RealDecoration} from './realism';
export const SHAPES = [
  ['lotus','บัวบาน'],['leaf','ใบตอง'],['swan','หงส์'],['heart','หัวใจ'],
  ['moon','จันทร์เสี้ยว'],['star','ดวงดาว'],['palace','ปราสาท'],['boat','เรือบุปผา'],
] as const;
export const DECORATIONS = [
  ['lotus','ดอกบัว'],['rose','กุหลาบ'],['daisy','เดซี่'],['marigold','ดาวเรือง'],['orchid','กล้วยไม้'],
  ['candle','เทียน'],['incense','ธูป'],['leaf','ใบไม้'],['palm','ใบพัด'],['heart','หัวใจ'],
  ['star','ดาว'],['moon','จันทร์'],['diamond','อัญมณี'],['pearl','ไข่มุก'],['ribbon','โบ'],
  ['butterfly','ผีเสื้อ'],['fish','ปลา'],['bird','นก'],['sparkle','ประกาย'],['lantern','โคม'],
] as const;
export const PALETTES = [
  {name:'ชมพูอรุณ',primary:'#f39cbc',secondary:'#59b99b',glow:'#ffb671'},
  {name:'ทองอำไพ',primary:'#ffcf6a',secondary:'#9971bc',glow:'#ffd867'},
  {name:'ออโรรา',primary:'#74e0cf',secondary:'#7b80e6',glow:'#7af7dc'},
  {name:'ม่วงฝัน',primary:'#ad8cff',secondary:'#e8a6cf',glow:'#b89bff'},
  {name:'ฟ้าสายน้ำ',primary:'#6bbcf5',secondary:'#9de7e0',glow:'#90dcff'},
  {name:'มุกจันทรา',primary:'#f4f0df',secondary:'#d5a65c',glow:'#ffe8ab'},
];
export const SWATCHES=['#ffcf6a','#f39cbc','#f06f83','#ad8cff','#6bbcf5','#74e0cf','#59b99b','#f4f0df','#e8a6cf','#ff995c','#ffffff','#273b72'];
export type Shape=typeof SHAPES[number][0];
export type DecorationKind=typeof DECORATIONS[number][0];
export type Decoration={kind:DecorationKind;x:number;y:number;scale:number;rotation:number;color:string;realAsset?:RealDecoration};
export type Stroke={color:string;width:number;points:[number,number][]};
export type Design={v:1;shape:Shape;primary:string;secondary:string;glow:string;glowPower:number;candles:number;speed:number;decorations:Decoration[];strokes:Stroke[];realism?:Realism;flair?:Flair};
export const LIMITS={decorations:24,strokes:40,points:160,totalPoints:2400,body:65536};
export function defaultDesign(style=0):Design{
  const p=PALETTES[[0,1,3,2][style]??0];
  return {v:1,shape:'lotus',primary:p.primary,secondary:p.secondary,glow:p.glow,glowPower:80,candles:1,speed:1,decorations:[],strokes:[]};
}
export function sampleDesign(index:number):Design{
  const i=Math.abs(Math.floor(index)),p=PALETTES[i%PALETTES.length];
  return {...defaultDesign(),shape:SHAPES[i%SHAPES.length][0],primary:p.primary,secondary:p.secondary,glow:p.glow,candles:i%3+1,decorations:[
    {kind:'rose',x:110,y:178,scale:.6,rotation:-15,color:p.primary},
    {kind:'rose',x:210,y:178,scale:.6,rotation:15,color:p.primary},
    {kind:i%2?'star':'pearl',x:160,y:198,scale:.55,rotation:0,color:'#ffdc8a'},
  ]};
}
const object=(x:unknown):x is Record<string,unknown>=>!!x&&typeof x==='object'&&!Array.isArray(x);
const number=(x:unknown,min:number,max:number):x is number=>typeof x==='number'&&Number.isFinite(x)&&x>=min&&x<=max;
const color=(x:unknown):x is string=>typeof x==='string'&&/^#[a-fA-F0-9]{6}$/.test(x);
export function validateDesign(x:unknown):Design|null{
  if(!object(x)||x.v!==1||!SHAPES.some(s=>s[0]===x.shape)||!color(x.primary)||!color(x.secondary)||!color(x.glow)||!number(x.glowPower,0,100)||!number(x.candles,0,3)||!Number.isInteger(x.candles)||!number(x.speed,.7,1.5))return null;
  if(!Array.isArray(x.decorations)||x.decorations.length>LIMITS.decorations||!Array.isArray(x.strokes)||x.strokes.length>LIMITS.strokes)return null;
  const flair=x.flair===undefined?undefined:validateFlair(x.flair);if(flair===null)return null;
  const realism=x.realism===undefined?undefined:validateRealism(x.realism);if(realism===null)return null;
  const decorations:Decoration[]=[],strokes:Stroke[]=[];let points=0;
  for(const d of x.decorations){
    if(!object(d)||!DECORATIONS.some(k=>k[0]===d.kind)||!number(d.x,15,305)||!number(d.y,15,235)||!number(d.scale,.35,2)||!number(d.rotation,-180,180)||!color(d.color))return null;
    if(d.realAsset!==undefined&&!REAL_DECORATIONS.some(v=>v.id===d.realAsset&&v.kind===d.kind))return null;
    decorations.push({kind:d.kind as DecorationKind,x:d.x,y:d.y,scale:d.scale,rotation:d.rotation,color:d.color,...(d.realAsset?{realAsset:d.realAsset as RealDecoration}:{})});
  }
  for(const s of x.strokes){
    if(!object(s)||!color(s.color)||!number(s.width,1,14)||!Array.isArray(s.points)||!s.points.length||s.points.length>LIMITS.points)return null;
    const path:[number,number][]=[];
    for(const p of s.points){if(!Array.isArray(p)||p.length!==2||!number(p[0],0,320)||!number(p[1],0,250))return null;path.push([p[0],p[1]]);}
    points+=path.length;if(points>LIMITS.totalPoints)return null;
    strokes.push({color:s.color,width:s.width,points:path});
  }
  return {v:1,shape:x.shape as Shape,primary:x.primary,secondary:x.secondary,glow:x.glow,glowPower:x.glowPower,candles:x.candles,speed:x.speed,decorations,strokes,...(realism?{realism}:{}),...(flair?{flair}:{})};
}
export function readDesign(value:unknown,style=0):Design{try{return validateDesign(typeof value==='string'?JSON.parse(value):value)??defaultDesign(style);}catch{return defaultDesign(style);}}
export const SCENE_THEMES=[['festival','คืนสีสัน'],['aurora','ออโรรา'],['gold','แสงจันทร์ทอง'],['dream','ม่วงในฝัน']] as const;
export type Scene={theme:typeof SCENE_THEMES[number][0];intensity:number;brightness:number;lanterns:boolean;fireflies:boolean;fireworks:boolean;water:boolean};
export const DEFAULT_SCENE:Scene={theme:'festival',intensity:80,brightness:110,lanterns:true,fireflies:true,fireworks:true,water:true};
export function validateScene(x:unknown):Scene|null{
  if(!object(x)||!SCENE_THEMES.some(t=>t[0]===x.theme)||!number(x.intensity,0,100)||!number(x.brightness,60,150)||!['lanterns','fireflies','fireworks','water'].every(k=>typeof x[k]==='boolean'))return null;
  return {theme:x.theme as Scene['theme'],intensity:x.intensity,brightness:x.brightness,lanterns:x.lanterns as boolean,fireflies:x.fireflies as boolean,fireworks:x.fireworks as boolean,water:x.water as boolean};
}
export function readScene(value:unknown):Scene{try{return validateScene(typeof value==='string'?JSON.parse(value):value)??{...DEFAULT_SCENE};}catch{return {...DEFAULT_SCENE};}}
