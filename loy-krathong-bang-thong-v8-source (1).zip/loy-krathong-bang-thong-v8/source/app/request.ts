export type RequestOptions={signal?:AbortSignal;retries?:number;timeoutMs?:number;onRetry?:(attempt:number)=>void};
/** Retries retain the exact submission ID; non-idempotent mutations never retry. */
export async function requestJSON<T>(url:string,method:string,data:unknown,options:RequestOptions={}){
 const retries=options.retries??(method==='GET'?1:method==='POST'&&(url==='/api/wishes'||url.endsWith('/ceremony'))?2:0);
 const payload=data===undefined?undefined:JSON.stringify(data);
 for(let attempt=0;;attempt++){
  const controller=new AbortController(),abort=()=>controller.abort();options.signal?.addEventListener('abort',abort,{once:true});
  if(options.signal?.aborted)controller.abort();
  const timer=setTimeout(()=>controller.abort(),options.timeoutMs??20000);
  let retry=false,error:Error|undefined;
  try{
   const response=await fetch(url,{method,headers:payload?{'Content-Type':'application/json'}:undefined,body:payload,cache:'no-store',signal:controller.signal});
   const result=await response.json() as T&{error?:string};
   if(response.ok)return result;
   error=new Error(result.error??'เชื่อมต่อไม่สำเร็จ');retry=[408,500,502,503,504].includes(response.status);
  }catch(e){error=new Error(controller.signal.aborted?'การเชื่อมต่อใช้เวลานาน กรุณาลองอีกครั้ง':'เชื่อมต่อไม่สำเร็จ กรุณาตรวจอินเทอร์เน็ตแล้วลองอีกครั้ง');retry=true;}
  finally{clearTimeout(timer);options.signal?.removeEventListener('abort',abort);}
  if(options.signal?.aborted)throw new DOMException('Aborted','AbortError');
  if(!retry||attempt>=retries)throw error;
  options.onRetry?.(attempt+1);
  await new Promise<void>((resolve,reject)=>{const abort=()=>{clearTimeout(wait);reject(new DOMException('Aborted','AbortError'));};const wait=setTimeout(()=>{options.signal?.removeEventListener('abort',abort);resolve();},700*2**attempt+Math.random()*300);options.signal?.addEventListener('abort',abort,{once:true});if(options.signal?.aborted)abort();});
 }
}
