/** Bounded, reference-counted cache. Only one expensive conversion runs at once. */
export class RenderPool<T>{
 private entries=new Map<string,{refs:number;promise:Promise<T>;resolve:(v:T)=>void;reject:(e:unknown)=>void;make:()=>Promise<T>;value?:T;state:'queued'|'running'|'done'}>();
 private working=false;
 constructor(private limit:number,private dispose:(value:T)=>void){}
 acquire(key:string,make:()=>Promise<T>){
  let e=this.entries.get(key);
  if(!e){
   this.evict(this.limit-1);
   if(this.entries.size>=this.limit)return {promise:Promise.reject<T>(new Error('Render cache busy')),release:()=>{}};
   let resolve!:(v:T)=>void,reject!:(e:unknown)=>void;const promise=new Promise<T>((a,b)=>{resolve=a;reject=b});
   e={refs:0,promise,resolve,reject,make,state:'queued'};this.entries.set(key,e);
  }else{this.entries.delete(key);this.entries.set(key,e);}
  e.refs++;const entry=e;let released=false;
  // A microtask permits duplicate mounts to share the same work.
  queueMicrotask(()=>this.pump());
  return {promise:entry.promise,release:()=>{if(released)return;released=true;entry.refs--;if(entry.refs===0&&entry.state==='queued'){this.entries.delete(key);entry.reject(new Error('Render cancelled'));}this.evict(this.limit);}};
 }
 private evict(target:number){
  for(const [key,e] of this.entries){if(this.entries.size<=target)break;if(e.refs===0&&e.state==='done'){if(e.value!==undefined)this.dispose(e.value);this.entries.delete(key);}}
 }
 private async pump(){
  if(this.working)return;
  const item=[...this.entries].find(([,e])=>e.state==='queued'&&e.refs>0);if(!item)return;
  const [key,e]=item;this.working=true;e.state='running';
  try{e.value=await e.make();e.state='done';e.make=()=>Promise.resolve(e.value!);e.resolve(e.value);}catch(error){this.entries.delete(key);e.reject(error);}finally{this.working=false;this.evict(this.limit);queueMicrotask(()=>this.pump());}
 }
 get size(){return this.entries.size;}
}
