# คู่มือติดตั้งและส่งต่อให้ผู้ดูแลเว็บ

โค้ดเวอร์ชัน 8 / 28 ตุลาคม 2569

## 1. เตรียมเครื่อง

ติดตั้ง Node.js รุ่นที่รองรับ Node 22.13 ขึ้นไปตาม package.json และติดตั้ง pnpm รุ่นที่ล็อกไว้:

```sh
npm install -g pnpm@11.25.0
```

เปิด Terminal ในโฟลเดอร์ `source/`:

```sh
pnpm install --frozen-lockfile
pnpm run build
```

เก็บ pnpm-lock.yaml ไว้เพื่อใช้ dependency ชุดเดียวกับโครงการ การติดตั้งครั้งแรกต้องใช้อินเทอร์เน็ต หากแพ็กเกจรุ่นที่ล็อกไว้ดาวน์โหลดไม่ได้ ให้ผู้พัฒนาตรวจ registry และรุ่นที่รองรับ ไม่ควรเปลี่ยนรุ่นทั้งหมดพร้อมกัน

ไฟล์ build จะอยู่ที่ `dist/client/` และ `dist/server/`

## 2. ทดลองในเครื่อง

สร้างตารางในฐานข้อมูลจำลองของเครื่อง โดยไม่แตะฐานข้อมูลจริง:

```sh
pnpm exec wrangler d1 migrations apply DB --local --config wrangler.local.example.json --persist-to .wrangler/state
pnpm run dev
```

เปิด URL ที่ Terminal แสดง (ปกติ http://localhost:5173)

- `/studio` ทดลองตกแต่ง วาด แนบรูป และสร้างภาพที่ระลึก
- `/display/demo` จอสาธิตกระทง
- `/admin` ทดลองสร้างห้องงาน โหมด dev ของ Sites plugin ใช้ตัวตนจำลองในเครื่อง

ข้อมูลในเครื่องจะอยู่ใต้ `.wrangler/` ไม่ใช่ฐานข้อมูลของเว็บจริง หากเปิดแอปแล้วแจ้งว่าไม่มีตาราง ให้ตรวจว่าใช้ working directory `source/` และตำแหน่งฐานข้อมูลจำลองตรงกัน

`pnpm run start` ใช้ทดลอง production build ด้วย Wrangler ในเครื่อง แต่ไม่มีบริการเข้าสู่ระบบ ChatGPT แบบ production อย่าใช้การทดสอบตัวตนจำลองเป็นระบบล็อกอินบนเว็บสาธารณะ

## 3. โฮสต์ที่โค้ดนี้ใช้ได้

ฐานโค้ดนี้ผูกกับ Cloudflare Workers + D1 + R2 ผ่าน binding `DB` และ `BUCKET`

- Cloudflare Workers: รันหน้าเว็บและ API
- D1: เก็บห้องงาน ชื่อ คำอวยพร แบบกระทง คิว และสถานะอนุมัติ
- R2: เก็บรูปที่ผู้ร่วมงานแนบ; ใช้ bucket ส่วนตัว ให้ API ตรวจสิทธิ์ก่อนส่งรูป

ถ้าจะลง cPanel/PHP, GitHub Pages หรือ static hosting อย่างเดียว ต้องมีการย้ายส่วน backend และ storage เพิ่ม ไม่สามารถอัปโหลดโค้ดชุดนี้แล้วใช้งานครบทุกฟังก์ชันได้ทันที

## 4. ตั้งค่าบัญชี Cloudflare ของคุณ

คำสั่งในส่วนนี้ให้ผู้ดูแลระบบเป็นผู้รัน การส่งออก ZIP นี้ยังไม่ได้สร้างบริการหรือเผยแพร่ในบัญชี Cloudflare ใด

```sh
pnpm exec wrangler login
pnpm exec wrangler d1 create loy-krathong-db
pnpm exec wrangler r2 bucket create loy-krathong-photos
```

คัดลอก `wrangler.external.example.json` เป็น `wrangler.external.json` แล้วแก้:

- `name`: ชื่อ Worker ในบัญชีของคุณ
- `d1_databases[0].database_id`: UUID จริงที่ได้จากคำสั่งสร้าง D1
- `d1_databases[0].database_name`: ชื่อฐานข้อมูลที่สร้าง
- `r2_buckets[0].bucket_name`: ชื่อ bucket ที่สร้าง
- คงชื่อ binding `DB` และ `BUCKET` ให้ตรงกับโค้ด

ตัวอย่างตั้งค่ามี UUID เลขศูนย์ ใช้แทนฐานข้อมูลจริงไม่ได้ และไม่ใช่การตั้งค่าโฮสต์สำเร็จรูป

สร้างตารางบน D1 ใหม่:

```sh
pnpm exec wrangler d1 migrations apply DB --remote --config wrangler.external.json
```

คำสั่งนี้ใช้ไฟล์ SQL ตามลำดับใน drizzle/ มี migrations 0000–0004 อย่าแก้หรือลบไฟล์เดิมเพื่อหลบข้อผิดพลาด ถ้าย้ายฐานข้อมูลที่มีอยู่แล้ว ต้องตรวจประวัติ migrations ก่อน ไม่ใช่นำคำสั่งสำหรับฐานใหม่ไปรันซ้ำโดยไม่ตรวจ

## 5. ต้องปรับล็อกอินผู้จัดก่อนเผยแพร่นอก Sites

ไฟล์ `app/chatgpt-auth.ts` ของต้นฉบับเชื่อถือ header `oai-authenticated-user-*` ที่แพลตฟอร์ม Sites ใส่ให้ และใช้ URL `/signin-with-chatgpt` กับ `/signout-with-chatgpt`

เมื่อรันนอกแพลตฟอร์มนี้ header ดังกล่าวไม่ได้เป็นหลักฐานล็อกอินที่ตรวจสอบแล้ว และ URL เข้าสู่ระบบไม่มีบริการรองรับโดยอัตโนมัติ จึงต้องเปลี่ยนส่วนนี้ก่อนใช้งานจริง:

1. ให้ `getChatGPTUser()` อ่าน session หรือ JWT ที่เซิร์ฟเวอร์ตรวจสอบแล้ว แทนการอ่าน header ที่ผู้เรียกกำหนดเอง
2. คงรูปแบบผลลัพธ์ userId, displayName, email, fullName เพื่อให้หน้า admin และการแยกเจ้าของห้องใช้ต่อได้
3. ปรับ `chatGPTSignInPath()` / `chatGPTSignOutPath()` และข้อความใน `app/admin/page.tsx` ให้ตรงกับระบบล็อกอินที่เลือก
4. ตรวจสิทธิ์กับ API ทุกครั้ง ไม่ใช่ปิดเฉพาะหน้า `/admin` เพราะการตั้งค่า อนุมัติ คลังคำอวยพร และการนับถอยหลังเรียก API โดยตรง
5. ให้หน้าร่วมงาน `/join/:id`, จอฉาย และ API สาธารณะที่จำเป็นยังเข้าได้โดยไม่ล็อกอิน

หากใช้ Cloudflare Access ต้องตรวจลายเซ็น JWT, issuer, audience และอายุ token ด้วย ไม่ใช่อ่านอีเมลจาก header แล้วเชื่อทันที ดูเอกสารทางการท้ายคู่มือ

ขั้นตอนเชื่อมระบบล็อกอินใหม่นี้ยังไม่ได้ทำใน ZIP; ZIP เก็บ source ต้นฉบับของเว็บปัจจุบันครบชุดสำหรับให้ผู้พัฒนานำไปต่อได้

## 6. Build และเผยแพร่หลังตั้งค่าครบ

เมื่อแก้ระบบล็อกอินและตั้งค่า D1/R2 เรียบร้อยแล้ว:

```sh
pnpm exec tsc --noEmit
pnpm run build
pnpm exec wrangler deploy --config wrangler.external.json --dry-run
pnpm exec wrangler deploy --config wrangler.external.json
```

ใช้ไฟล์ตั้งค่าภายนอกโดยระบุ `--config` ชัดเจน เพราะ build เดิมมีชื่อ binding จำลองใน `dist/server/wrangler.json` ส่วนไฟล์ `.openai/hosting.json` ระบุเว็บ Sites ต้นฉบับ ไม่ใช่บัญชี Cloudflare ของคุณ

หลังเผยแพร่เปิด `/admin` เข้าระบบ สร้างห้องใหม่ และใช้ QR ที่ห้องใหม่นั้นสร้างให้ QR ของเว็บเดิมไม่เปลี่ยนไปตามโฮสต์ใหม่โดยอัตโนมัติ

ถ้าจะใช้โดเมนของหน่วยงาน ให้เชื่อมโดเมนกับ Worker และใช้ HTTPS แล้วสร้าง/ดาวน์โหลด QR จากโดเมนปลายทางนั้น

## 7. การย้ายข้อมูลเดิม

ZIP นี้ไม่มีข้อมูลผู้ร่วมงานจริงหรือรูปอัปโหลด
สร้างห้องใหม่ได้หลังติดตั้งสำเร็จ หากต้องการรักษาห้องเดิม ต้องย้ายข้อมูล D1 พร้อมไฟล์ R2 ที่ key ตรงกัน และจับคู่ events.owner ให้ตรงกับ userId ของผู้จัดในระบบล็อกอินใหม่
ไฟล์ Excel ใช้เก็บรายชื่อและข้อความย้อนหลัง แต่ไม่ใช่ไฟล์สำรองฐานข้อมูลทั้งหมด

## 8. ชุดตรวจในโครงการ

หลัง build ใช้ชุดตรวจด้านล่างกับข้อมูลจำลอง:

```sh
node scripts/integration-check.mjs
node scripts/media-integration-check.mjs
node scripts/media-check.cjs
node scripts/motion-check.cjs
node scripts/performance-check.cjs
node scripts/realism-check.cjs
```

ทดสอบ integration เดิมใช้ identity headers ของ Sites จำลองอยู่ในสภาพแวดล้อมแยก เมื่อเปลี่ยนระบบล็อกอิน ต้องแก้ identity fixtures และเพิ่มการทดสอบ session/JWT ใหม่ด้วย
`souvenir-media-check.cjs` เป็นการตรวจ native Canvas ซึ่งต้องมี runtime เพิ่มเติมของเครื่องพัฒนา ไม่ใช่ dependency ที่เว็บใช้ตอนเปิดงานจริง

ก่อนงาน ให้ตรวจด้วยมือถือจริง: สแกน QR → แต่ง → แนบรูป → ส่ง → อนุมัติ → ขึ้นจอ → ดาวน์โหลดภาพ และทดลองเครือข่าย/เครื่องที่ใช้ฉายจริง

## เอกสารทางการประกอบการย้ายโฮสต์

ตรวจอ้างอิง 28 ตุลาคม 2569:

- Node.js: https://nodejs.org/en/download
- คำสั่ง Wrangler: https://developers.cloudflare.com/workers/wrangler/commands/
- D1 create / migrations apply: https://developers.cloudflare.com/d1/wrangler-commands/
- migrations_dir: https://developers.cloudflare.com/d1/reference/migrations/
- สร้าง R2 bucket: https://developers.cloudflare.com/r2/buckets/create-buckets/
- ตรวจ JWT ของ Cloudflare Access: https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/validating-json/
